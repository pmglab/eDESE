/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.util.stat;

import Jama.Matrix;

import edu.rit.numeric.NonNegativeLeastSquares;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author limx54
 */
public class NNLSSolver {

    /**
     * In case you want to test the solver, there is this handy-dandy testing
     * function. Compare the results with your favorite NNLS solver, and they
     * should be equivalent (or at least they were equivalent to MATLAB's...).
     *
     * @param penguin Not used.
     */
    public static void main(String[] penguin) {
        Matrix A = Matrix.random(1000, 1000);
        //A.print(14, 10);
        Matrix b = Matrix.random(1000, 1);
        //b.print(14, 10);
        Matrix Sigma = new Matrix(1000, 1000);
        for (int i = 0; i < Sigma.getRowDimension(); i++) {
            Sigma.set(i, i, 1);
        }

        long begintime = System.nanoTime();
        Matrix xNNLS = solveNNLS(A, b, Sigma);
        long endtime = System.nanoTime();
        long costTime = (endtime - begintime) / 1000;
        System.out.println("time" + costTime);
        xNNLS.print(7, 7);

        NonNegativeLeastSquares PJ2NNLS = new NonNegativeLeastSquares(A.getRowDimension(), A.getColumnDimension());
        for (int i = 0; i < A.getRowDimension(); i++) {
            PJ2NNLS.b[i] = b.getArray()[i][0];
            for (int j = 0; j < A.getColumnDimension(); j++) {
                PJ2NNLS.a[i][j] = A.getArray()[i][j];
            }
        }
        begintime = System.nanoTime();
        PJ2NNLS.solve();
        endtime = System.nanoTime();
        costTime = (endtime - begintime) / 1000;
        System.out.println("time" + costTime);
        for (int i = 0; i < PJ2NNLS.x.length; i++) {
            System.out.println(PJ2NNLS.x[i]);
        }

    }

    /**
     * Whee!!! This is my own Java implementation of the NNLS algorithm as
     * described in: Lawson and Hanson, "Solving Least Squares Problems",
     * Prentice-Hall, 1974, Chapter 23, p. 161. It not only solves the least
     * squares problem, but does so while also requiring that none of the
     * answers be negative.
     *
     * @param A The A in Ax=b
     * @param b The b in Ax=b
     * @return The x in Ax=b
     */
    public static Matrix solveNNLS(Matrix A, Matrix b, Matrix Sigma) {
        List<Integer> p = new ArrayList<Integer>();
        List<Integer> z = new ArrayList<Integer>();
        int i = 0;
        int xm = A.getColumnDimension();
        int xn = b.getColumnDimension();
        while (i < A.getColumnDimension()) {
            z.add(i++);
        }
        Matrix x = new Matrix(xm, xn);
        /*
		 * You need a finite number of iterations. Without this condition, the finite precision nature
		 * of the math being done almost makes certain that the <1e-15 conditions won't ever hold up.
		 * However, after so many iterations, it should at least be close to the correct answer.
		 * For the intrepid coder, however, one could replace this again with an infinite while
		 * loop and make the <1e-15 conditions into something like c*norm(A) or c*norm(b).
         */
        //for(int iterations = 0; iterations < 300*A.getColumnDimension()*A.getRowDimension(); iterations++)
        for (int iterations = 0; iterations < 1000; iterations++) {
            //System.out.println(z.size() + " " + p.size());
            Matrix w = diag_RightTimes(A.transpose(), Sigma).times(b.minus(A.times(x)));
            //Matrix w = A.transpose().times(Sigma).times(b.minus(A.times(x)));
            //w.print(7, 5);
            if (z.size() == 0 || isAllNegative(w)) {
                //System.out.println("Computation should break");
                //We are done with the computation. Break here!
                break;//Should break out of the outer while loop.
            }
            //Step 4
            int t = z.get(0);
            double max = w.get(t, 0);
            for (i = 1; i < z.size(); i++) {
                if (w.get(z.get(i), 0) > max) {
                    t = z.get(i);
                    max = w.get(z.get(i), 0);
                }
            }
            //Step 5
            p.add(t);
            z.remove((Integer) t);
            boolean allPositive = false;
            while (!allPositive) {
                //Step 6
                Matrix Ep = new Matrix(b.getRowDimension(), p.size());
                for (i = 0; i < p.size(); i++) {
                    for (int j = 0; j < Ep.getRowDimension(); j++) {
                        Ep.set(j, i, A.get(j, p.get(i)));
                    }
                }
                //Matrix Zprime = Ep.solve(b);
                //Matrix Zprime = (Ep.transpose().times(Sigma).times(Ep)).inverse().times(Ep.transpose().times(Sigma).times(b));
                Matrix Zprime = (diag_RightTimes(Ep.transpose(), Sigma).times(Ep)).inverse().times(diag_RightTimes(Ep.transpose(), Sigma).times(b));
                Ep = null;
                Matrix Z = new Matrix(xm, xn);
                for (i = 0; i < p.size(); i++) {
                    Z.set(p.get(i), 0, Zprime.get(i, 0));
                }
                //Step 7
                allPositive = true;
                for (i = 0; i < p.size(); i++) {
                    allPositive &= Z.get(p.get(i), 0) > 0;
                }
                if (allPositive) {
                    x = Z;
                } else {
                    double alpha = Double.MAX_VALUE;
                    for (i = 0; i < p.size(); i++) {
                        int q = p.get(i);
                        if (Z.get(q, 0) <= 0) {
                            double xq = x.get(q, 0);
                            if (xq / (xq - Z.get(q, 0)) < alpha) {
                                alpha = xq / (xq - Z.get(q, 0));
                            }
                        }
                    }
                    //Finished getting alpha. Onto step 10
                    x = x.plus(Z.minus(x).times(alpha));
                    for (i = p.size() - 1; i >= 0; i--) {
                        if (Math.abs(x.get(p.get(i), 0)) < 1e-15)//Close enough to zero, no?
                        {
                            z.add(p.remove(i));
                        }
                    }
                }
            }
        }
        return x;
    }

    private static boolean isAllNegative(Matrix w) {
        boolean result = true;
        int m = w.getRowDimension();
        for (int i = 0; i < m; i++) {
            result &= w.get(i, 0) <= 1e-15;
        }
        return result;
    }

    private static Matrix diag_RightTimes(Matrix A, Matrix B) {
        Matrix C = new Matrix(A.getRowDimension(), B.getColumnDimension());
        for (int j = 0; j < A.getColumnDimension(); j++) {
            for (int i = 0; i < A.getRowDimension(); i++) {
                C.set(i, j, A.get(i, j) * B.get(j, j));
            }
        }

        return C;
    }

    public static Matrix weightedNNLSSolver(Matrix A, Matrix b, Matrix Sigma) {
        Matrix x = new Matrix(A.getRowDimension(), b.getColumnDimension());
        for (int i = 0; i < b.getColumnDimension(); i++) {
            Matrix xi = vectorNNLSSolver(A, Sigma, b.getMatrix(0, b.getRowDimension() - 1, i, i));
            x.setMatrix(0, b.getRowDimension() - 1, i, i, xi);
        }
        return x;
    }

    private static Matrix vectorNNLSSolver(Matrix A, Matrix Sigma, Matrix b) {
        Matrix x = new Matrix(A.getRowDimension(), 1);
        Matrix u = x.minus(diag_RightTimes(A.transpose(), Sigma).times(b));
        Matrix H = diag_RightTimes(A.transpose(), Sigma).times(A);

        while (!KKT(u, x)) {
            for (int i = 0; i < x.getRowDimension(); i++) {
                double x_t = x.get(i, 0);
                double u_i = u.get(i, 0);
                double x_t1 = x_t - (u_i / H.get(i, i));
                x_t1 = x_t1 > 1e-15 ? x_t1 : 0;
                x.set(i, 0, x_t1);
                u = u.plus(H.getMatrix(0, H.getRowDimension() - 1, i, i).times(x_t1 - x_t));
            }
        }
        return x;
    }

    private static boolean KKT(Matrix u, Matrix x) {
        boolean result = true;
        for (int i = 0; i < x.getRowDimension(); i++) {
            if (x.get(i, 0) > 0) {
                result &= u.get(i, 0) <= 1e-15;
            } else {
                result &= u.get(i, 0) >= -1e-15;
            }
        }
        return result;
    }

}
