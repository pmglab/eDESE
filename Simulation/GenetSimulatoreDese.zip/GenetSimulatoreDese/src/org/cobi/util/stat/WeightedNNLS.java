/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.util.stat;

import Jama.Matrix;

/**
 *
 * @author limx54
 */
public class WeightedNNLS {

    private static double F = Double.MAX_VALUE;
    private static Matrix H;

    public static Matrix weightedNNLSSolver(Matrix A, Matrix b, Matrix Sigma) {
        H = diag_RightTimes(A.transpose(), Sigma).times(A);
        Matrix x = new Matrix(A.getRowDimension(), b.getColumnDimension());
        for (int i = 0; i < b.getColumnDimension(); i++) {
            Matrix xi = vectorNNLSSolver(A, Sigma, b.getMatrix(0, b.getRowDimension() - 1, i, i));
            x.setMatrix(0, b.getRowDimension() - 1, i, i, xi);
        }
        return x;
    }

    private static Matrix vectorNNLSSolver(Matrix A, Matrix Sigma, Matrix b) {
        Matrix x = new Matrix(A.getRowDimension(), 1);
        Matrix u = x.minus(diag_RightTimes(A.transpose(), Sigma).times(b));

        while (!StopConditon(x, A, Sigma, b)) {
            for (int i = 0; i < x.getRowDimension(); i++) {
                double x_t = x.get(i, 0);
                double u_i = u.get(i, 0);
                double x_t1 = x_t - (u_i / H.get(i, i));
                x_t1 = x_t1 > 1e-15 ? x_t1 : 0;
                x.set(i, 0, x_t1);
                u = u.plus(H.getMatrix(0, H.getRowDimension() - 1, i, i).times(x_t1 - x_t));
            }
        }
        return x;
    }

    private static boolean StopConditon(Matrix x, Matrix A, Matrix Sigma, Matrix b) {
        double f = diag_RightTimes(x.transpose().times(A.transpose()).times(0.5).minus(b.transpose()),
                Sigma).times(A).times(x).get(0, 0);
        if (Math.abs(f - F) <= 1e-15) {
            F = Double.MAX_VALUE;
            return true;
        } else {
            F = f;
            return false;
        }
    }

    private static boolean KKT(Matrix u, Matrix x) {
        boolean result = true;
        for (int i = 0; i < x.getRowDimension(); i++) {
            if (x.get(i, 0) > 0) {
                result &= u.get(i, 0) <= 1e-15;
            } else {
                result &= u.get(i, 0) >= -1e-15;
            }
        }
        return result;
    }

    private static Matrix diag_RightTimes(Matrix A, Matrix B) {
        Matrix C = new Matrix(A.getRowDimension(), B.getColumnDimension());
        for (int j = 0; j < A.getColumnDimension(); j++) {
            for (int i = 0; i < A.getRowDimension(); i++) {
                C.set(i, j, A.get(i, j) * B.get(j, j));
            }
        }
        return C;
    }
}
