/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.util.stat;

import Jama.Matrix;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.rosuda.REngine.REXP;
import org.rosuda.REngine.Rserve.RConnection;

/**
 *
 * @author limx54
 */
public class WNNLSSolver {

    public static void main(String[] args) {
        Matrix A = Matrix.random(1000, 1000);
        Matrix b = Matrix.random(1000, 2);
        Matrix Sigma = new Matrix(1000, 1000);
        for (int i = 0; i < Sigma.getRowDimension(); i++) {
            Sigma.set(i, i, 1);
        }

//        NonNegativeLeastSquares PJ2NNLS = new NonNegativeLeastSquares(A.getRowDimension(), A.getColumnDimension());
//        for(int i = 0; i < A.getRowDimension(); i++){
//            PJ2NNLS.b[i] = b.getArray()[i][0];
//            for(int j = 0; j < A.getColumnDimension(); j++){
//                PJ2NNLS.a[i][j] = A.getArray()[i][j];
//            }
//        }
//        PJ2NNLS.solve();
//        for(int i = 0; i < PJ2NNLS.x.length; i++) {
//            System.out.println(PJ2NNLS.x[i]);
//        }
        PhysicalStore.Factory<Double, PrimitiveDenseStore> storeFactory
                = PrimitiveDenseStore.FACTORY;
        PrimitiveDenseStore matrixA
                = storeFactory.rows(A.getArray());
        PrimitiveDenseStore matrixB
                = storeFactory.rows(b.getArray());
        PrimitiveDenseStore matrixS
                = storeFactory.rows(Sigma.getArray());

        long begintime = System.nanoTime();
        MatrixStore<Double> matrixC = WNNLSSolver(matrixA, matrixB, matrixS);
        long endtime = System.nanoTime();
        long costTime = (endtime - begintime) / 1000;
        System.out.println("time" + costTime);

//        BasicLogger.debug("MatrixStore MatrixStore#multiply(MatrixStore)", matrixC);
//        begintime = System.nanoTime();
//        Matrix xNNLS = WeightedNNLSSolver.WeightedNNLSSolver(A,Sigma, b);
//        endtime = System.nanoTime();
//        costTime = (endtime - begintime)/1000;
//        System.out.println("time" + costTime);
//
//        for(int i = 0; i < 100; i++){
//                System.out.print(matrixC.get(i, 0) + "	");
//                System.out.print(matrixC.get(i, 1) + "		");
//                System.out.print(xNNLS.get(i, 0) + "	");
//                System.out.println(xNNLS.get(i, 1));
//            }
        try {
            RConnection c = new RConnection();
            REXP matrixa = REXP.createDoubleMatrix(A.getArray());
            REXP matrixb = REXP.createDoubleMatrix(b.getArray());
            c.assign("A", matrixa);
            c.assign("b", matrixb);
            c.eval("library(NNLM)");
            c.eval("x <- nnlm(A, b, loss = 'mse')");
            REXP x = c.eval("x$coefficients");
            double[][] result = x.asDoubleMatrix();
            for (int i = 0; i < result.length; i++) {
                System.out.print(matrixC.get(i, 0) + "	");
                System.out.print(matrixC.get(i, 1) + "		");
                System.out.print(result[i][0] + "	");
                System.out.println(result[i][1]);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private static double F = Double.MAX_VALUE;
    private static MatrixStore<Double> H;

    public static MatrixStore<Double> WNNLSSolver(MatrixStore<Double> A, MatrixStore<Double> b, MatrixStore<Double> Sigma) {
        H = diag_RightTimes(A.transpose(), Sigma).multiply(A);
        PrimitiveDenseStore x = PrimitiveDenseStore.FACTORY.makeZero(A.countRows(), b.countColumns());
        for (int i = 0; i < b.countColumns(); i++) {
            PrimitiveDenseStore bi = PrimitiveDenseStore.FACTORY.makeZero(A.countRows(), 1);
            bi.fillColumn(0, b.sliceColumn(i));
            MatrixStore<Double> xi = VectorWNNLSSolver(A, bi, Sigma);
            x.fillColumn(i, xi.sliceColumn(0));

        }
        return x;
    }

    private static MatrixStore<Double> VectorWNNLSSolver(MatrixStore<Double> A, MatrixStore<Double> b, MatrixStore<Double> Sigma) {
        PrimitiveDenseStore x = PrimitiveDenseStore.FACTORY.makeZero(A.countRows(), 1);
        MatrixStore<Double> u = x.subtract(diag_RightTimes(A.transpose(), Sigma).multiply(b));

        while (!StopCondition(x, A, b, Sigma)) {
            for (int i = 0; i < x.countRows(); i++) {
                double x_t = x.get(i, 0);
                double u_i = u.get(i, 0);
                double x_t1 = x_t - (u_i / H.get(i, i));
                x_t1 = x_t1 > 1e-15 ? x_t1 : 0;
                x.set(i, 0, x_t1);
                PrimitiveDenseStore Hi = PrimitiveDenseStore.FACTORY.makeZero(H.countRows(), 1);
                Hi.fillColumn(0, H.sliceColumn(i));
                u = u.add(Hi.multiply(x_t1 - x_t));
            }
        }
        return x;
    }

    private static boolean StopCondition(MatrixStore<Double> x, MatrixStore<Double> A, MatrixStore<Double> b, MatrixStore<Double> Sigma) {
        double f = diag_RightTimes(x.transpose().multiply(A.transpose().multiply(0.5).subtract(b.transpose())),
                Sigma).multiply(A).multiply(x).get(0, 0);
        if (Math.abs(f - F) <= 1e-15) {
            F = Double.MAX_VALUE;
            return true;
        } else {
            F = f;
            return false;
        }
    }

    private static boolean isAllNegative(MatrixStore<Double> w) {
        boolean result = true;
        int m = (int) w.countRows();
        for (int i = 0; i < m; i++) {
            result &= w.get(i, 0) <= 1e-15;
        }
        return result;
    }

    private static MatrixStore<Double> diag_RightTimes(MatrixStore<Double> A, MatrixStore<Double> B) {
        PrimitiveDenseStore C
                = PrimitiveDenseStore.FACTORY.makeZero(A.countRows(), B.countColumns());
        for (int j = 0; j < (int) A.countColumns(); j++) {
            for (int i = 0; i < (int) A.countRows(); i++) {
                C.set(i, j, A.get(i, j) * B.get(j, j));
            }
        }
        return C;
    }
}
