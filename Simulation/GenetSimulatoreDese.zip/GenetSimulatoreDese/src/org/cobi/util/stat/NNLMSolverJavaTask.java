/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.util.stat;

import java.util.Random;
import org.ejml.data.DMatrixRMaj;
import org.ejml.dense.row.CommonOps_DDRM;
 

/**
 *
 * @author mxli
 */
public class NNLMSolverJavaTask {

    final int MAX_ITER = 1000000;
    final double REL_TOL = 1e-6;
    DMatrixRMaj aA;
    DMatrixRMaj ab1;
    DMatrixRMaj ab2;
    DMatrixRMaj finalX1;
    DMatrixRMaj finalX2;
    int startIndex;
    int endIndex;
    double df;
    double Y;

    private DMatrixRMaj extract(DMatrixRMaj src,
            int srcY0, int srcY1,
            int srcX0, int srcX1) {
        int w = srcX1 - srcX0;
        int h = srcY1 - srcY0;

        DMatrixRMaj dst = new DMatrixRMaj(h, w);

        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                double v = src.get(y + srcY0, x + srcX0);
                dst.set(y, x, v);
            }
        }

        return dst;
    }

    public DMatrixRMaj getFinalX1() {
        return finalX1;
    }

    public DMatrixRMaj getFinalX2() {
        return finalX2;
    }

    public NNLMSolverJavaTask(DMatrixRMaj aA, DMatrixRMaj ab1, DMatrixRMaj ab2, int startIndex, int endIndex) {
        this.aA = aA;
        this.ab1 = ab1;
        this.ab2 = ab2;
        this.startIndex = startIndex;
        this.endIndex = endIndex;
    }

    public double getDf() {
        return df;
    }

    public double getY() {
        return Y;
    }

    public DMatrixRMaj xInitial(int rowNum, int colNum, DMatrixRMaj b) {
        DMatrixRMaj initialX = new DMatrixRMaj(rowNum, colNum);
        double maxValue = 0;
        for (int i = 0; i < b.numRows; i++) {
            if (b.get(i) > maxValue) {
                maxValue = b.get(i);
            }
        }
        Random rand = new Random();
        for (int i = 0; i < rowNum; i++) {
            for (int j = 0; j < colNum; j++) {
                initialX.set(i, j, maxValue * rand.nextDouble());
            }
        }
        return initialX;
    }

    public DMatrixRMaj initialMu(DMatrixRMaj h, DMatrixRMaj A, DMatrixRMaj x, DMatrixRMaj b) {
        DMatrixRMaj hMultX = new DMatrixRMaj(A.numRows, 1);
        DMatrixRMaj ATransMultB = new DMatrixRMaj(A.numRows, 1);
        DMatrixRMaj muX = new DMatrixRMaj(A.numRows, 1);
        CommonOps_DDRM.mult(h, x, hMultX);
        CommonOps_DDRM.multTransA(A, b, ATransMultB);
        CommonOps_DDRM.add(hMultX, -1, ATransMultB, muX);
        return muX;
    }

    public double[] singleSolve(DMatrixRMaj X, DMatrixRMaj mu, DMatrixRMaj h, int max_iter, double rel_tol) {
        int iter = 0;
        double error = rel_tol + 1.;
        double[] arrX = X.getData();
        double[] arrMu = mu.getData();
        double[] arrH = h.getData();
        double afterXi;
        double errorI;
        double errorTemp;
        while ((error > rel_tol) && ((iter++) < max_iter)) {
            error = 0;
            for (int i = 0; i < arrX.length; i++) {

                afterXi = Math.max(0, arrX[i] - arrMu[i] / arrH[i * arrX.length + i]);

                errorI = afterXi - arrX[i];

                if (Math.abs(errorI) > 1e-9) {
                    for (int j = 0; j < mu.numRows; j++) {
                        arrMu[j] += arrH[j * arrX.length + i] * errorI;
                    }
                } else {
                    continue;
                }

                //1e-6 guarantees that the denominator is not zero
                errorTemp = 2 * Math.abs(errorI) / (1e-16 + afterXi + arrX[i]);
                if (errorTemp > error) {
                    error = errorTemp;
                }
                arrX[i] = afterXi;
            }
        }

        return arrX;
    }

    public double elementSum(double[] data) {
        double sum = 0;
        for (int i = 0; i < data.length; i++) {
            sum += data[i];
        }
        return sum;
    }

    public String call() throws Exception {
        int blockLen = endIndex - startIndex;
        DMatrixRMaj A = extract(aA, startIndex, endIndex, startIndex, endIndex);
        DMatrixRMaj b1 = extract(ab1, startIndex, endIndex, 0, 1);
        DMatrixRMaj b2 = extract(ab2, startIndex, endIndex, 0, 1);

        //initial args
        DMatrixRMaj h = new DMatrixRMaj(A.numRows, A.numCols);
        CommonOps_DDRM.multTransA(A, A, h);

        finalX2 = xInitial(A.numRows, 1, b2);
        DMatrixRMaj muFinalX2 = initialMu(h, A, finalX2, b2);
        double[] final_2 = singleSolve(finalX2, muFinalX2, h, MAX_ITER, REL_TOL);
        df = elementSum(final_2);

        finalX1 = xInitial(A.numRows, 1, b1);
        DMatrixRMaj muFinalX1 = initialMu(h, A, finalX1, b1);
        //calculate the solution
        double[] final_1 = singleSolve(finalX1, muFinalX1, h, MAX_ITER, REL_TOL);
        Y = elementSum(final_1);

        /*
        strange! this is less powerful
        finalX1 = new DMatrixRMaj(A.numRows, 1);
        for (int i = 0; i < blockLen; i++) {
            finalX1.set(i, 0, final_2[i] * b1.get(i, 0));
        }
        double[] final_1 = finalX1.data;
                //calculate the sum
        Y = elementSum(final_1);
         */
        // System.out.println(Y + "\t" + Y1);
        if (Y < 0) {
            Y = 0;
        }
        if (df < 0) {
            df = 0.001;
        }
        return startIndex + "-" + endIndex + ":" + df + ":" + Y;
    }
}
