// (c) 2008-2009 Miaoxin Li
// This file is distributed as part of the IGG source code package
// and may not be redistributed in any form, without prior written
// permission from the author. Permission is granted for you to
// modify this file for your own personal use, but modified versions
// must retain this copyright notice and must not be distributed.

// Permission is granted for you to use this file to compile IGG.

// All computer programs have bugs. Use this file at your own risk.
// Saturday, January 17, 2009
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.cobi.util.thread;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author MX Li
 */
public class Task1 {

    protected List<TaskListener> listeners = Collections.synchronizedList(new LinkedList<TaskListener>());

    public void addTaskListener(TaskListener listener) {
        listeners.add(listener);
    }

    /*
    protected void fireAutoCallback(String infor) {
        if (listeners.isEmpty()) {
            return;
        }
        for (TaskListener listener : listeners) {
            listener.autoCallback(infor);
        }
    }
*/
    protected void fireTaskComplete() throws Exception {
        if (listeners.isEmpty()) {
            return;
        }
        for (TaskListener listener : listeners) {
            listener.taskCompleted();
        }
    }
}
