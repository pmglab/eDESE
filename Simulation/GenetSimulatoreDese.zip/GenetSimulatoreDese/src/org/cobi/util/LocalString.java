/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.util;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Locale;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.math.linear.RealMatrix;
import org.apache.commons.math.linear.RealVector;

/**
 *
 * @author Miaoxin Li
 */
public class LocalString {

    /**
     * support Numeric format:<br>
     * "33" "+33" "033.30" "-.33" ".33" " 33." " 000.000 "
     * @param str String
     * @return boolean
     */
    public static boolean isNumeric(String str) {
        int begin = 0;
        boolean once = true;
        if (str == null || str.trim().equals("")) {
            return false;
        }
        str = str.trim();
        if (str.startsWith("+") || str.startsWith("-")) {
            if (str.length() == 1) {
                // "+" "-"
                return false;
            }
            begin = 1;
        }
        for (int i = begin; i < str.length(); i++) {
            if (!Character.isDigit(str.charAt(i))) {
                if (str.charAt(i) == '.' && once) {
                    // '.' can only once
                    once = false;
                } else {
                    return false;
                }
            }
        }
        if (str.length() == (begin + 1) && !once) {
            // "." "+." "-."
            return false;
        }
        return true;
    }

    public static void print2DRealMatrix(RealMatrix items) {
        int rowNum = items.getRowDimension();
        int colNum = items.getColumnDimension() - 1;
        DecimalFormat df = new DecimalFormat("0.0000000", new DecimalFormatSymbols(Locale.US));
        for (int c = 0; c < rowNum; c++) {
            for (int d = 0; d < colNum; d++) {
                System.out.print(df.format(items.getEntry(c, d)) + "\t");
            }
            System.out.print(df.format(items.getEntry(c, colNum)));
            System.out.println();
        }
    }

    public static void printRealVector(RealVector items) {
        int colNum = items.getDimension() - 1;
        DecimalFormat df = new DecimalFormat("0.0000000", new DecimalFormatSymbols(Locale.US));

        for (int d = 0; d < colNum; d++) {
            System.out.print(df.format(items.getEntry(d)) + "\t");
        }
        System.out.print(df.format(items.getEntry(colNum)));
        System.out.println();

    }

    /**
     * support Integer format:<br>
     * "33" "003300" "+33" " -0000 "
     * @param str String
     * @return boolean
     */
    public static boolean isInteger(String str) {
        int begin = 0;
        if (str == null || str.trim().equals("")) {
            return false;
        }
        str = str.trim();
        if (str.startsWith("+") || str.startsWith("-")) {
            if (str.length() == 1) {
                // "+" "-"
                return false;
            }
            begin = 1;
        }
        for (int i = begin; i < str.length(); i++) {
            if (!Character.isDigit(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    /**
     * use Exception
     * support Numeric format:<br>
     * "33" "+33" "033.30" "-.33" ".33" " 33." " 000.000 "
     * @param str String
     * @return boolean
     */
    public static boolean isNumericEx(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException ex) {
            return false;
        }
    }

    /**
     * use Exception
     * support less than 11 digits(<11)<br>
     * support Integer format:<br>
     * "33" "003300" "+33" " -0000 " "+ 000"
     * @param str String
     * @return boolean
     */
    public static boolean isIntegerEx(String str) {
        str = str.trim();
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException ex) {
            if (str.startsWith("+")) {
                return isIntegerEx(str.substring(1));
            }
            return false;
        }
    }

    /**
     * using Regular Expression
     *
     * support Integer format:<br>
     * "33" "003300" " -0000 "
     *
     * Date: Jul 30, 2008
     *
     * @param str
     * @return
     */
    public static boolean isIntegerRegex(String str) {

        Pattern pattern = Pattern.compile("^[+\\-]?\\d+$");
        Matcher matcher = pattern.matcher(str.trim());
        return matcher.matches();
    }

    /**
     * using Regular Expression
     *
     * support Numeric format:<br>
     * "33" "+33" "033.30" "-.33" ".33" " 000.000 "
     * @param str String
     * @return boolean
     */
    public static boolean isNumericRegex(String str) {

        Pattern pattern = Pattern.compile("^[+\\-]?((\\d*\\.\\d+)|(\\d+))$");
        Matcher matcher = pattern.matcher(str.trim());
        return matcher.matches();
    }

    public static boolean isRightSideComplementalSquences(String str1, String str2, int cmpLen) {
        if ((str1.length() == 0) || (str2.length() == 0)) {
            return false;
        }
        boolean isComp = true;
        str1 = str1.toUpperCase();
        str2 = str2.toUpperCase();
        int len1 = str1.length();
        int len2 = str2.length();
        int len = len1 > len2 ? len2 : len1;
        if (len > cmpLen) {
            len = cmpLen;
        }
        for (int i = 1; i <= len; i++) {
            switch (str1.charAt(len1 - i)) {
                case 'A':
                    if (str2.charAt(len2 - i) != 'T') {
                        isComp = false;
                    }
                    break;
                case 'T':
                    if (str2.charAt(len2 - i) != 'A') {
                        isComp = false;
                    }
                    break;
                case 'G':
                    if (str2.charAt(len2 - i) != 'C') {
                        isComp = false;
                    }
                    break;
                case 'C':
                    if (str2.charAt(len2 - i) != 'G') {
                        isComp = false;
                    }
                    break;
            }
            if (!isComp) {
                break;
            }
        }
        return isComp;
    }

    public static boolean isComplementalChar(char a, char b) {
        boolean isComp = false;
        switch (a) {
            case 'A':
                if (b == 'T') {
                    isComp = true;
                }
                break;
            case 'T':
                if (b == 'A') {
                    isComp = true;
                }
                break;
            case 'G':
                if (b == 'C') {
                    isComp = true;
                }
                break;
            case 'C':
                if (b == 'G') {
                    isComp = true;
                }
                break;
        }
        return isComp;

    }

    public static boolean isLeftSideComplementalSquences(String str1, String str2, int cmpLen) {
        if ((str1.length() == 0) || (str2.length() == 0)) {
            return false;
        }
        boolean isComp = true;
        str1 = str1.toUpperCase();
        str2 = str2.toUpperCase();
        int len = str1.length() > str2.length() ? str2.length() : str1.length();
        if (len > cmpLen) {
            len = cmpLen;
        }
        for (int i = 0; i < len; i++) {
            switch (str1.charAt(i)) {
                case 'A':
                    if (str2.charAt(i) != 'T') {
                        isComp = false;
                    }
                    break;
                case 'T':
                    if (str2.charAt(i) != 'A') {
                        isComp = false;
                    }
                    break;
                case 'G':
                    if (str2.charAt(i) != 'C') {
                        isComp = false;
                    }
                    break;
                case 'C':
                    if (str2.charAt(i) != 'G') {
                        isComp = false;
                    }
                    break;
            }
            if (!isComp) {
                break;
            }
        }
        return isComp;
    }

    public static boolean isRightSideSameSequences(String str1, String str2, int cmpLen) {
        if ((str1.length() == 0) || (str2.length() == 0)) {
            return false;
        }
        boolean isSame = true;
        str1 = str1.toUpperCase();
        str2 = str2.toUpperCase();
        int len1 = str1.length();
        int len2 = str2.length();
        int len = len1 > len2 ? len2 : len1;
        if (len > cmpLen) {
            len = cmpLen;
        }
        for (int i = 1; i <= len; i++) {
            if (str1.charAt(len1 - i) != str2.charAt(len2 - i)) {
                isSame = false;
                break;
            }
        }
        return isSame;
    }

    public static boolean isLeftSideSameSequences(String str1, String str2, int cmpLen) {
        if ((str1.length() == 0) || (str2.length() == 0)) {
            return false;
        }
        boolean isSame = true;
        str1 = str1.toUpperCase();
        str2 = str2.toUpperCase();
        int len = str1.length() > str2.length() ? str2.length() : str1.length();
        if (len > cmpLen) {
            len = cmpLen;
        }
        for (int i = 0; i < len; i++) {
            if (str1.charAt(i) != str2.charAt(i)) {
                isSame = false;
                break;
            }
        }
        return isSame;
    }

    public static boolean uniqueSortedArrayList(ArrayList<String[]> list, int index) {
        int len = list.size();
        if (len == 0) {
            return false;
        }
        TreeSet<String> set = new TreeSet<String>();
        ArrayList<String[]> tmpList = new ArrayList<String[]>(list);
        list.clear();
        for (int i = 0; i < len; i++) {
            if (set.contains(tmpList.get(i)[index])) {
                continue;
            }
            list.add(tmpList.get(i));
            set.add(tmpList.get(i)[index]);
        }

        return true;
    }

    public static String getReverseComplementalSquences(String str1) {
        if (str1 == null || (str1.length() == 0)) {
            return null;
        }
        int len = str1.length();
        StringBuffer complement = new StringBuffer();
        complement.setLength(len);
        len--;
        for (int i = len; i >= 0; i--) {
            switch (str1.charAt(i)) {
                case 'A':
                    complement.setCharAt(len - i, 'T');
                    break;
                case 'T':
                    complement.setCharAt(len - i, 'A');
                    break;
                case 'G':
                    complement.setCharAt(len - i, 'C');
                    break;
                case 'C':
                    complement.setCharAt(len - i, 'G');
                    break;
                case '[':
                    complement.setCharAt(len - i, ']');
                    break;
                case ']':
                    complement.setCharAt(len - i, '[');
                    break;
                default:
                    complement.setCharAt(len - i, str1.charAt(i));
            }
        }
        return complement.toString();
    }

    public static char getComplementalChar(char ch1) {
        switch (ch1) {
            case 'A':
                return 'T';
            case 'T':
                return 'A';
            case 'G':
                return 'C';
            case 'C':
                return 'G';
            default:
                return ch1;
        }
    }

    public static void main(String[] args) {
        System.out.println(LocalString.getReverseComplementalSquences("CTCGTGCCT[C/G]GGGGCTGTG"));
    }
}
