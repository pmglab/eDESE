/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.util.matrix;

import cern.colt.matrix.DoubleMatrix2D;
import cern.colt.matrix.impl.DenseDoubleMatrix2D;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.StringTokenizer;

/**
 *
 * @author mxli
 */
public class ColtMatrixBasic {

    public static DoubleMatrix2D readMatrixFromFile(String pathName, int needRowNum, int needColNum) throws Exception {
        File path = new File(pathName);
        BufferedReader br = new BufferedReader(new FileReader(path));
        String line = null;
        String delmilit = ", \t";

        int colNum = -1;
        int rowIndex = 0;

        DoubleMatrix2D mat = new DenseDoubleMatrix2D(needRowNum, needRowNum);
        while ((line = br.readLine()) != null) {
            if (line.trim().length() == 0) {
                continue;
            }

            StringTokenizer tokenizer = new StringTokenizer(line, delmilit);
            if (colNum < 0) {
                colNum = tokenizer.countTokens();
                if (colNum < needColNum) {
                    System.out.println("Read less loci than you need!");
                } else {
                    colNum = needColNum;
                }
            }
            for (int i = 0; i < colNum; i++) {
                mat.setQuick(rowIndex, i, Double.parseDouble(tokenizer.nextToken()));
            }
            rowIndex++;
            if (rowIndex == needRowNum) {
                break;
            }
        }
        br.close();

        if (rowIndex < needRowNum) {
            return mat.viewPart(0, 0, rowIndex, colNum);
        } else {
            return mat;
        }
    }
}
