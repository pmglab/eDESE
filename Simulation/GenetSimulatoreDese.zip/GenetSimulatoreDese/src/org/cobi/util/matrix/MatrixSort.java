/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.util.matrix;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.LinkedList;

 

import cern.colt.matrix.DoubleMatrix2D;
import cern.colt.matrix.impl.DenseDoubleMatrix2D;

public class MatrixSort {

    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        // TODO Auto-generated method stub
        DoubleMatrix2D ldRMatrix = new DenseDoubleMatrix2D(997, 997);
        double threshold = 0.05;
//      -------------------- put your file here ----------------------		
        BufferedReader br = new BufferedReader(new FileReader(new File("E:\\home\\mxli\\MyJava\\GenetSimulator\\corr.txt")));
        String string;
        int row = 0;
        while (br.ready()) {
            string = br.readLine();
            String[] cells = string.trim().split("\\s+");
            for (int i = 0; i < cells.length; i++) {
                ldRMatrix.set(row, i, Float.parseFloat(cells[i]));
            }
            row += 1;
        }
        MatrixSort matrixFunction = new MatrixSort();
        matrixFunction.thisldMatrix = ldRMatrix;
        long startTime = System.currentTimeMillis();
        int[] arr = new int[997];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = i;
        }
        int start = 0;
        int end = arr.length - 1;
        int step = 0;
        LinkedList<Integer[]> resultToShow = new LinkedList<Integer[]>();
        while (step < arr.length) {
            matrixFunction.QuickSort(arr, start, end, step);
            matrixFunction.quickSort(start, end, step);
            int preStart = start;
            while (start < end) {
                if (ldRMatrix.get(step, start) >= threshold) {
                    start++;
                } else {
                    break;
                }
            }
            while (step < start) {
                matrixFunction.QuickSort(arr, start, end, step);
                matrixFunction.quickSort(start, end, step);
                while (start < end) {
                    if (ldRMatrix.get(step, start) >= threshold) {
                        start++;
                    } else {
                        break;
                    }
                }
                step++;
            }
            Integer[] blockList = new Integer[start - 1 - preStart + 1];
            if (preStart == start) {
                System.out.println("block: [" + preStart + " , " + start + "]");
                blockList = new Integer[1];
                blockList[0] = preStart;
                resultToShow.add(blockList);
                break;
            } else {
                System.out.println("block: [" + preStart + " , " + (start - 1) + "]");
                for (int i = preStart; i < start; i++) {
                    blockList[i - preStart] = arr[i];
                }
                resultToShow.add(blockList);
            }

        }
//      -------------------- show results ----------------------
        for (int i = 0; i < resultToShow.size(); i++) {
            String result = "";
            for (int j = 0; j < resultToShow.get(i).length; j++) {
                result += resultToShow.get(i)[j] + ", ";
            }
            System.out.println("Block:" + (i + 1) + " =>" + "[" + result.substring(0, result.length() - 2) + "]");
        }
        long endTime = System.currentTimeMillis();
        long duration = (endTime - startTime);
        System.out.println("That took " + duration / 1000.0 + " seconds");
    }

    int partition(int left, int right, int rowNum) {
        int i = left, j = right;
        double pivot = thisldMatrix.get(rowNum, (left + right) / 2);

        while (i <= j) {
            while (thisldMatrix.get(rowNum, i) > pivot) {
                i++;
            }
            while (thisldMatrix.get(rowNum, j) < pivot) {
                j--;
            }
            if (i <= j) {
                swapMatrix(thisldMatrix, i, j);
                i++;
                j--;
            }
        }

        return i;
    }
    public DoubleMatrix2D thisldMatrix;

    void QuickSort(int arr[], int left, int right, int rowNum) {
        int i = left, j = right;
        int tmp;
        double pivot = thisldMatrix.get(rowNum, arr[(left + right) / 2]);

        /* partition */
        while (i <= j) {
            while (thisldMatrix.get(rowNum, arr[i]) > pivot) {
                i++;
            }
            while (thisldMatrix.get(rowNum, arr[j]) < pivot) {
                j--;
            }
            if (i <= j) {
                tmp = arr[i];
                arr[i] = arr[j];
                arr[j] = tmp;
                i++;
                j--;
            }
        };

        /* recursion */
        if (left < j) {
            QuickSort(arr, left, j, rowNum);
        }
        if (i < right) {
            QuickSort(arr, i, right, rowNum);
        }
    }

    void quickSort(int left, int right, int rowNum) {
        int index = partition(left, right, rowNum);
        if (left < index - 1) {
            quickSort(left, index - 1, rowNum);
        }
        if (index < right) {
            quickSort(index, right, rowNum);
        }
    }

    public void swapMatrix(DoubleMatrix2D matrix, int columOne, int columTwo) {
        int romNum = matrix.rows();
        int columNum = matrix.columns();
        for (int i = 0; i < romNum; i++) {
            double tmp = matrix.get(i, columOne);
            matrix.set(i, columOne, matrix.get(i, columTwo));
            matrix.set(i, columTwo, tmp);
        }
        for (int i = 0; i < columNum; i++) {
            double tmp = matrix.get(columOne, i);
            matrix.set(columOne, i, matrix.get(columTwo, i));
            matrix.set(columTwo, i, tmp);
        }
    }
}
