/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.util.matrix;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.StringTokenizer;
import org.apache.commons.math.linear.Array2DRowRealMatrix;
import org.apache.commons.math.linear.ArrayRealVector;
import org.apache.commons.math.linear.CholeskyDecomposition;
import org.apache.commons.math.linear.CholeskyDecompositionImpl;
import org.apache.commons.math.linear.MatrixUtils;
import org.apache.commons.math.linear.NotPositiveDefiniteMatrixException;
import org.apache.commons.math.linear.NotSymmetricMatrixException;
import org.apache.commons.math.linear.RealMatrix;
import org.apache.commons.math.linear.RealVector;

/**
 *
 * @author mxli
 */
public class ApacheMatrixBasic {

    public static RealVector getDiagonalVector(RealMatrix mat) {

        if (mat == null) {
            return null;
        }
        int shorterDim = Math.min(mat.getRowDimension(), mat.getColumnDimension());
        RealVector vector = new ArrayRealVector(shorterDim);
        for (int i = 0; i < shorterDim; i++) {
            vector.setEntry(i, mat.getEntry(i, i));
        }
        return vector;
    }

    public static RealMatrix getDiagonal(RealMatrix mat) {

        if (mat == null) {
            return null;
        }
        int shorterDim = Math.min(mat.getRowDimension(), mat.getColumnDimension());
        double[] data = new double[shorterDim];

        for (int i = 0; i < shorterDim; i++) {
            data[i] = mat.getEntry(i, i);
        }
        return MatrixUtils.createRealDiagonalMatrix(data);
    }

    public static RealMatrix mapSqrt(RealMatrix mat) {

        if (mat == null) {
            return null;
        }
        int rowNum = mat.getRowDimension();
        int colNum = mat.getRowDimension();
        RealMatrix result = new Array2DRowRealMatrix(rowNum, colNum);
        for (int i = 0; i < rowNum; i++) {
            result.setRowVector(i, mat.getRowVector(i).mapSqrt());
        }
        return result;
    }

    public static RealMatrix mapInv(RealMatrix mat) {

        if (mat == null) {
            return null;
        }
        int rowNum = mat.getRowDimension();
        int colNum = mat.getRowDimension();
        RealMatrix result = new Array2DRowRealMatrix(rowNum, colNum);
        for (int i = 0; i < rowNum; i++) {
            result.setRowVector(i, mat.getRowVector(i).mapInv());
        }
        return result;
    }

    public static RealMatrix ebeMultiply(RealMatrix mat1, RealMatrix mat2) {
        if (mat1 == null || mat2 == null) {
            return null;
        }
        int rowNum = mat1.getRowDimension();
        int colNum = mat1.getColumnDimension();
        RealMatrix result = new Array2DRowRealMatrix(rowNum, colNum);
        for (int i = 0; i < rowNum; i++) {
            result.setRowVector(i, mat1.getRowVector(i).ebeMultiply(mat2.getRowVector(i)));
        }
        return result;
    }

    public static RealMatrix mapSignum(RealMatrix mat) {
        if (mat == null) {
            return null;
        }
        int rowNum = mat.getRowDimension();
        int colNum = mat.getRowDimension();
        RealMatrix result = new Array2DRowRealMatrix(rowNum, colNum);
        for (int i = 0; i < rowNum; i++) {
            result.setRowVector(i, mat.getRowVector(i).mapSignum());
        }
        return result;
    }

    public static RealMatrix mapPow(RealMatrix mat, double factor) {
        if (mat == null) {
            return null;
        }
        int rowNum = mat.getRowDimension();
        int colNum = mat.getRowDimension();
        RealMatrix result = new Array2DRowRealMatrix(rowNum, colNum);
        for (int i = 0; i < rowNum; i++) {
            result.setRowVector(i, mat.getRowVector(i).mapPow(factor));
        }
        return result;
    }

    public static RealVector sumColumn(RealMatrix mat) {
        if (mat == null) {
            return null;
        }
        int colNum = mat.getRowDimension();
        int rowNum = mat.getRowDimension();
        RealVector rv = new ArrayRealVector(colNum);

        for (int i = 0; i < colNum; i++) {
            RealVector v1 = mat.getColumnVector(i);

            double sum = 0;
            for (int j = 0; j < rowNum; j++) {
                sum += v1.getEntry(j);
            }
            rv.setEntry(i, sum);
        }
        return rv;
    }

    public static boolean isPositiveDefinite(RealMatrix mat) {
        try {
            CholeskyDecomposition cd = new CholeskyDecompositionImpl(mat);
        } catch (NotPositiveDefiniteMatrixException e) {
            // expected behavior
            return false;
        } catch (NotSymmetricMatrixException e) {
            System.err.println("not symmetric exception caught");
            return false;
        } catch (Exception e) {
            System.err.println("wrong exception caught");
            return false;
        }
        return true;
    }

    public static RealMatrix readMatrixFromFile(String pathName, int needRowNum, int needColNum) throws Exception {
        File path = new File(pathName);
        BufferedReader br = new BufferedReader(new FileReader(path));
        String line = null;
        String delmilit = ", \t";

        int colNum = -1;
        int rowIndex = 0;
        RealMatrix mat = new Array2DRowRealMatrix(needRowNum, needRowNum);
        while ((line = br.readLine()) != null) {
            if (line.trim().length() == 0) {
                continue;
            }

            StringTokenizer tokenizer = new StringTokenizer(line, delmilit);
            if (colNum < 0) {
                colNum = tokenizer.countTokens();
                if (colNum < needColNum) {
                    System.out.println("Read less loci than you need!");
                } else {
                    colNum = needColNum;
                }
            }
            for (int i = 0; i < colNum; i++) {
                mat.setEntry(rowIndex, i, Double.parseDouble(tokenizer.nextToken()));
            }
            rowIndex++;
            if (rowIndex == needRowNum) {
                break;
            }
        }
        br.close();

        if (rowIndex < needRowNum) {
            return mat.getSubMatrix(0, rowIndex, 0, colNum);
        } else {
            return mat;
        }
    }

    public static RealMatrix readUpperTriangleMatrixFromFile(String pathName, int needRowNum, int needColNum) throws Exception {
        File path = new File(pathName);
        BufferedReader br = new BufferedReader(new FileReader(path));
        String line = null;
        String delmilit = ", \t";

        int colNum = -1;
        int rowIndex = 0;
        RealMatrix mat = new Array2DRowRealMatrix(needRowNum, needRowNum);
        while ((line = br.readLine()) != null) {
            if (line.trim().length() == 0) {
                continue;
            }

            StringTokenizer tokenizer = new StringTokenizer(line, delmilit);
            if (colNum < 0) {
                colNum = tokenizer.countTokens();
                if (colNum < needColNum) {
                    System.out.println("Read less loci than you need!");
                } else {
                    colNum = needColNum;
                }
            }
            for (int i = 0; i < rowIndex; i++) {
                tokenizer.nextToken();
            }

            for (int i = rowIndex; i < colNum; i++) {
                mat.setEntry(rowIndex, i, Double.parseDouble(tokenizer.nextToken()));
                mat.setEntry(i, rowIndex, mat.getEntry(rowIndex, i));
            }
            rowIndex++;
            if (rowIndex == needRowNum) {
                break;
            }
        }
        br.close();

        if (rowIndex < needRowNum) {
            return mat.getSubMatrix(0, rowIndex, 0, colNum);
        } else {
            return mat;
        }
    }

    public static String formatMatrix(RealMatrix mat) {
        int rowNum = mat.getRowDimension();
        int colNum = mat.getColumnDimension() - 1;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < rowNum; i++) {
            for (int j = 0; j < colNum; j++) {
                sb.append(mat.getEntry(i, j));
                sb.append('\t');
            }
            sb.append(mat.getEntry(i, colNum));
            sb.append('\n');
        }
        return sb.toString();
    }
}
