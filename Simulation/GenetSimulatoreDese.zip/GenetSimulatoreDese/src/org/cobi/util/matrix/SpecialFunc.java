/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.util.matrix;

import cern.colt.list.DoubleArrayList;
import cern.colt.matrix.DoubleMatrix1D;
import cern.colt.matrix.DoubleMatrix2D;
import cern.colt.matrix.impl.DenseDoubleMatrix2D;
import cern.colt.matrix.linalg.EigenvalueDecomposition;
import cern.jet.stat.Descriptive;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.commons.math.linear.Array2DRowRealMatrix;
import org.apache.commons.math.linear.EigenDecomposition;
import org.apache.commons.math.linear.EigenDecompositionImpl;
import org.apache.commons.math.linear.RealMatrix;
import org.apache.commons.math.util.MathUtils;

/**
 *
 * @author MX Li
 */
public class SpecialFunc {

    public static double calculateEffectSampleSizeApacheMatrix() throws Exception {
        //http://gump.qimr.edu.au/general/daleN/SNPSpD/KeavneyResultsNew.pdf
        int originalSampleSize = 10;
        int newSampleSize = originalSampleSize;

        RealMatrix corMat = ApacheMatrixBasic.readMatrixFromFile("test.txt", originalSampleSize, originalSampleSize);
        originalSampleSize = corMat.getRowDimension();
        originalSampleSize = corMat.getColumnDimension();

        Set<Integer> highlyCorrIndexes = new HashSet<Integer>();
        double maxCorr = 1;
        for (int i = 0; i < originalSampleSize; i++) {
            for (int j = i + 1; j < originalSampleSize; j++) {
                if (Math.abs(corMat.getEntry(i, j)) >= maxCorr) {
                    if (!highlyCorrIndexes.contains(j) && !highlyCorrIndexes.contains(i)) {
                        highlyCorrIndexes.add(j);
                        System.out.println(i + " <-> " + j);
                    }
                }
            }
        }
        if (highlyCorrIndexes.size() > 0) {
            System.out.println("Removed columns and rows: " + highlyCorrIndexes.toString());
            newSampleSize = originalSampleSize - highlyCorrIndexes.size();

            RealMatrix tmpCorMat = new Array2DRowRealMatrix(newSampleSize, newSampleSize);
            int incRow = 0;
            int incCol = 0;
            for (int i = 0; i < originalSampleSize; i++) {
                if (highlyCorrIndexes.contains(i)) {
                    continue;
                }
                incCol = 0;
                for (int j = 0; j < originalSampleSize; j++) {
                    if (highlyCorrIndexes.contains(j)) {
                        continue;
                    }
                    tmpCorMat.setEntry(incRow, incCol, corMat.getEntry(i, j));
                    incCol++;
                }
                incRow++;
            }
            corMat = tmpCorMat;
            System.out.println(ApacheMatrixBasic.formatMatrix(corMat));
        }

        EigenDecomposition eigenDeco = new EigenDecompositionImpl(corMat, MathUtils.SAFE_MIN);
        double[] eigenValues = eigenDeco.getRealEigenvalues();
        DoubleArrayList eigenValueList = new DoubleArrayList(eigenValues.length);
        for (int i = 0; i < eigenValues.length; i++) {
            System.out.println(eigenValues[i]);
            eigenValueList.add(eigenValues[i]);
        }
        double var = Descriptive.sampleVariance(eigenValueList, Descriptive.mean(eigenValueList));
        System.out.println(var);
        double effectSampleSize = 1 + (newSampleSize - 1) * (1 - var / newSampleSize);
        System.out.println(effectSampleSize);
        return effectSampleSize;
    }

    public static double calculateEffectSampleSizeColtMatrixMyMethod(DoubleMatrix2D corrMat, List<Integer> selectedSampleIndex) throws Exception {
        //http://gump.qimr.edu.au/general/daleN/SNPSpD/KeavneyResultsNew.pdf

        // DoubleMatrix2D corrMat = ColtMatrixBasic.readMatrixFromFile("test.txt", originalSampleSize, originalSampleSize);
        int newSampleSize = 0;
        DoubleMatrix2D poweredcorrMat = null;

        if (selectedSampleIndex == null) {
            poweredcorrMat = corrMat;
            newSampleSize = corrMat.rows();

        } else if (selectedSampleIndex.isEmpty()) {
            return 0;
        } else {
            newSampleSize = selectedSampleIndex.size();
            poweredcorrMat = new DenseDoubleMatrix2D(newSampleSize, newSampleSize);
            // System.out.println("Removed columns and rows: " + highlyCorrIndexes.toString()); 
            for (int i = 0; i < newSampleSize; i++) {
                poweredcorrMat.setQuick(i, i, corrMat.getQuick(selectedSampleIndex.get(i), selectedSampleIndex.get(i)));
                for (int j = i + 1; j < newSampleSize; j++) {
                    poweredcorrMat.setQuick(i, j, corrMat.getQuick(selectedSampleIndex.get(i), selectedSampleIndex.get(j)));
                    poweredcorrMat.setQuick(j, i, corrMat.getQuick(selectedSampleIndex.get(j), selectedSampleIndex.get(i)));
                }
            }
            // System.out.println(corrMat.toString());
        }


        /*
        originalSampleSize = corrMat.columns();
        Set<Integer> highlyCorrIndexes = new HashSet<Integer>();
        double maxCorr = 1;
        for (int j = 0; j < originalSampleSize; j++) {
        for (int j = j + 1; j < originalSampleSize; j++) {
        if (Math.abs(corrMat.getQuick(j, j)) >= maxCorr) {
        if (!highlyCorrIndexes.contains(j) && !highlyCorrIndexes.contains(j)) {
        highlyCorrIndexes.add(j);
        System.out.println(j + " <-> " + j);
        }
        }
        }
        }
        if (highlyCorrIndexes.size() > 0) {
        System.out.println("Removed columns and rows: " + highlyCorrIndexes.toString());
        newSampleSize = originalSampleSize - highlyCorrIndexes.size();
        
        DoubleMatrix2D tmpCorMat = new DenseDoubleMatrix2D(newSampleSize, newSampleSize);
        int incRow = 0;
        int incCol = 0;
        for (int j = 0; j < originalSampleSize; j++) {
        if (highlyCorrIndexes.contains(j)) {
        continue;
        }
        incCol = 0;
        for (int j = 0; j < originalSampleSize; j++) {
        if (highlyCorrIndexes.contains(j)) {
        continue;
        }
        tmpCorMat.setQuick(incRow, incCol, corrMat.getQuick(j, j));
        incCol++;
        }
        incRow++;
        }
        corrMat = tmpCorMat;
        // System.out.println(corrMat.toString());
        }
         */
        EigenvalueDecomposition ed = new EigenvalueDecomposition(poweredcorrMat);
        DoubleMatrix1D eVR = ed.getRealEigenvalues();
        DoubleMatrix1D eVI = ed.getImagEigenvalues();
        // System.out.println(eVR.toString());
        // System.out.println(eVI.toString());
        //double effectSampleSize = newSampleSize;

        double effectSampleSize = newSampleSize;
        //System.out.println(poweredcorrMat.toString());
        for (int i = 0; i < newSampleSize; i++) {
            if (eVR.getQuick(i) < 0) {
               // System.out.println(poweredcorrMat.toString());
               // System.out.println(eVR.toString());
            }
            if (eVR.getQuick(i) > 1) {
                effectSampleSize -= (eVR.getQuick(i) - 1);//(eVR.getQuick(j));
            }
        }

        /*
        double effectSampleSize = 0;
        for (int j = 0; j < newSampleSize; j++) {
        if (eVR.getQuick(j) > 1) {
        effectSampleSize += (1);//(eVR.getQuick(j));
        } else {
        effectSampleSize += eVR.getQuick(j);
        }
        }
         *
         */
 /*
        DoubleArrayList eigenValueList = new DoubleArrayList(newSampleSize);
        for (int j = 0; j < newSampleSize; j++) {
        eigenValueList.add(eVR.getQuick(j));
        }
        double var = Descriptive.sampleVariance(eigenValueList, Descriptive.mean(eigenValueList));
        // System.out.println(var);
        effectSampleSize = 1 + (newSampleSize - 1) * (1 - var / newSampleSize);
        //System.out.println(effectSampleSize);
         */
        return effectSampleSize;
    }

    public static double calculateEffectSampleSizeColtMatrixNyholt(DoubleMatrix2D corrMat) throws Exception {
        //http://gump.qimr.edu.au/general/daleN/SNPSpD/KeavneyResultsNew.pdf
        int originalSampleSize = corrMat.columns();
        // DoubleMatrix2D corrMat = ColtMatrixBasic.readMatrixFromFile("test.txt", originalSampleSize, originalSampleSize);
        int newSampleSize = originalSampleSize;

        DoubleMatrix2D poweredcorrMat = new DenseDoubleMatrix2D(newSampleSize, newSampleSize);
        for (int i = 0; i < originalSampleSize; i++) {
            for (int j = 0; j < originalSampleSize; j++) {
                poweredcorrMat.setQuick(i, j, corrMat.getQuick(i, j));
            }
        }

        EigenvalueDecomposition ed = new EigenvalueDecomposition(poweredcorrMat);
        DoubleMatrix1D eVR = ed.getRealEigenvalues();
        DoubleMatrix1D eVI = ed.getImagEigenvalues();
        // System.out.println(eVR.toString());
        // System.out.println(eVI.toString());
        //double effectSampleSize = newSampleSize;

        double effectSampleSize = newSampleSize;
        DoubleArrayList eigenValueList = new DoubleArrayList(newSampleSize);
        for (int i = 0; i < newSampleSize; i++) {
            eigenValueList.add(eVR.getQuick(i));
        }
        double var = Descriptive.sampleVariance(eigenValueList, Descriptive.mean(eigenValueList));
        // System.out.println(var);
        effectSampleSize = 1 + (newSampleSize - 1) * (1 - var / newSampleSize);
        //System.out.println(effectSampleSize);       

        return effectSampleSize;
    }

    public static double calculateEffectSampleSizeColtMatrixLiJi(DoubleMatrix2D corrMat, Set<Integer> selectedSampleIndex) throws Exception {
        //http://gump.qimr.edu.au/general/daleN/SNPSpD/KeavneyResultsNew.pdf
        int originalSampleSize = corrMat.columns();
        // DoubleMatrix2D corrMat = ColtMatrixBasic.readMatrixFromFile("test.txt", originalSampleSize, originalSampleSize);
        int newSampleSize = originalSampleSize;
        if (selectedSampleIndex != null && selectedSampleIndex.size() > 0) {
            // System.out.println("Removed columns and rows: " + highlyCorrIndexes.toString());
            newSampleSize = selectedSampleIndex.size();

            DoubleMatrix2D tmpCorMat = new DenseDoubleMatrix2D(newSampleSize, newSampleSize);
            int incRow = 0;
            int incCol = 0;
            for (int i = 0; i < originalSampleSize; i++) {
                if (!selectedSampleIndex.contains(i)) {
                    continue;
                }
                incCol = 0;
                for (int j = 0; j < originalSampleSize; j++) {
                    if (!selectedSampleIndex.contains(j)) {
                        continue;
                    }
                    tmpCorMat.setQuick(incRow, incCol, corrMat.getQuick(i, j));
                    incCol++;
                }
                incRow++;
            }
            corrMat = tmpCorMat;
            // System.out.println(corrMat.toString());
        } else if (selectedSampleIndex != null && selectedSampleIndex.isEmpty()) {
            return 0;
        }

        EigenvalueDecomposition ed = new EigenvalueDecomposition(corrMat);
        DoubleMatrix1D eVR = ed.getRealEigenvalues();
        DoubleMatrix1D eVI = ed.getImagEigenvalues();
        // System.out.println(eVR.toString());
        // System.out.println(eVI.toString());
        //double effectSampleSize = newSampleSize;
        double effectSampleSize = 0;
        double abs = 0;

        for (int i = 0; i < newSampleSize; i++) {
            abs = Math.abs(eVR.getQuick(i));
            if (abs >= 1) {
                effectSampleSize += (1);//(eVR.getQuick(j));
            }

            effectSampleSize += (abs - Math.floor(abs));
        }
        return (effectSampleSize);

    }

    public static double calculateEffectSampleSizeColtMatrixGalwey(DoubleMatrix2D corrMat, Set<Integer> selectedSampleIndex) throws Exception {
        //http://gump.qimr.edu.au/general/daleN/SNPSpD/KeavneyResultsNew.pdf
        int originalSampleSize = corrMat.columns();
        // DoubleMatrix2D corrMat = ColtMatrixBasic.readMatrixFromFile("test.txt", originalSampleSize, originalSampleSize);
        int newSampleSize = originalSampleSize;
        if (selectedSampleIndex != null && selectedSampleIndex.size() > 0) {
            // System.out.println("Removed columns and rows: " + highlyCorrIndexes.toString());
            newSampleSize = selectedSampleIndex.size();

            DoubleMatrix2D tmpCorMat = new DenseDoubleMatrix2D(newSampleSize, newSampleSize);
            int incRow = 0;
            int incCol = 0;
            for (int i = 0; i < originalSampleSize; i++) {
                if (!selectedSampleIndex.contains(i)) {
                    continue;
                }
                incCol = 0;
                for (int j = 0; j < originalSampleSize; j++) {
                    if (!selectedSampleIndex.contains(j)) {
                        continue;
                    }
                    tmpCorMat.setQuick(incRow, incCol, corrMat.getQuick(i, j));
                    incCol++;
                }
                incRow++;
            }
            corrMat = tmpCorMat;
            // System.out.println(corrMat.toString());
        } else if (selectedSampleIndex != null && selectedSampleIndex.isEmpty()) {
            return 0;
        }

        EigenvalueDecomposition ed = new EigenvalueDecomposition(corrMat);
        DoubleMatrix1D eVR = ed.getRealEigenvalues();
        DoubleMatrix1D eVI = ed.getImagEigenvalues();
        // System.out.println(eVR.toString());
        // System.out.println(eVI.toString());
        //double effectSampleSize = newSampleSize;
        double effectSampleSize = 0;
        double accu1 = 0;
        double accu2 = 0;

        for (int i = 0; i < newSampleSize; i++) {
            if (eVR.getQuick(i) > 0) {
                accu1 += Math.sqrt(eVR.getQuick(i));
                accu2 += eVR.getQuick(i);
            }

        }
        effectSampleSize = accu1 * accu1 / accu2;
        return (effectSampleSize);

    }

    public static double calculateEffectSampleSizeColtMatrixMoskvinaSchmidt(DoubleMatrix2D corrMat,
            Set<Integer> selectedSampleIndex, double alpha) throws Exception {
        //reference http://www.ncbi.nlm.nih.gov/pubmed/18425821
        int originalSampleSize = corrMat.columns();
        int newSampleSize = originalSampleSize;
        if (selectedSampleIndex != null && selectedSampleIndex.size() > 0) {
            // System.out.println("Removed columns and rows: " + highlyCorrIndexes.toString());
            newSampleSize = selectedSampleIndex.size();

            DoubleMatrix2D tmpCorMat = new DenseDoubleMatrix2D(newSampleSize, newSampleSize);
            int incRow = 0;
            int incCol = 0;
            for (int i = 0; i < originalSampleSize; i++) {
                if (!selectedSampleIndex.contains(i)) {
                    continue;
                }
                incCol = 0;
                for (int j = 0; j < originalSampleSize; j++) {
                    if (!selectedSampleIndex.contains(j)) {
                        continue;
                    }
                    tmpCorMat.setQuick(incRow, incCol, corrMat.getQuick(i, j));
                    incCol++;
                }
                incRow++;
            }
            corrMat = tmpCorMat;
            // System.out.println(corrMat.toString());
        } else if (selectedSampleIndex != null && selectedSampleIndex.isEmpty()) {
            return 0;
        }
        double max = 0;
        double effectSampleSize = 1;
        for (int j = 1; j < newSampleSize; j++) {
            max = Math.abs(corrMat.getQuick(0, j));
            for (int k = 1; k < j; k++) {
                if (Math.abs(corrMat.getQuick(k, j)) > max) {
                    max = Math.abs(corrMat.getQuick(k, j));
                }
            }
            if (max < 1) {
                effectSampleSize += Math.sqrt(1 - Math.pow(max, -1.31 * Math.log10(alpha)));
            }
        }

        return effectSampleSize;
    }

    public static double calculateEffectSampleSizeColtMatrixByPak(DoubleMatrix2D corrMat,
            Set<Integer> selectedSampleIndex, double alpha) throws Exception {
        //reference http://www.ncbi.nlm.nih.gov/pubmed/18425821
        int originalSampleSize = corrMat.columns();
        int newSampleSize = originalSampleSize;
        if (selectedSampleIndex != null && selectedSampleIndex.size() > 0) {
            // System.out.println("Removed columns and rows: " + highlyCorrIndexes.toString());
            newSampleSize = selectedSampleIndex.size();

            DoubleMatrix2D tmpCorMat = new DenseDoubleMatrix2D(newSampleSize, newSampleSize);
            int incRow = 0;
            int incCol = 0;
            for (int i = 0; i < originalSampleSize; i++) {
                if (!selectedSampleIndex.contains(i)) {
                    continue;
                }
                incCol = 0;
                for (int j = 0; j < originalSampleSize; j++) {
                    if (!selectedSampleIndex.contains(j)) {
                        continue;
                    }
                    tmpCorMat.setQuick(incRow, incCol, corrMat.getQuick(i, j));
                    incCol++;
                }
                incRow++;
            }
            corrMat = tmpCorMat;
            // System.out.println(corrMat.toString());
        } else if (selectedSampleIndex != null && selectedSampleIndex.isEmpty()) {
            return 0;
        }
        double max = 0;
        double effectSampleSize = 1;
        for (int j = 1; j < newSampleSize; j++) {
            max = Math.abs(corrMat.getQuick(0, j));
            for (int k = 1; k < j; k++) {
                if (Math.abs(corrMat.getQuick(k, j)) > max) {
                    max = Math.abs(corrMat.getQuick(k, j));
                }
            }
            if (max < 1) {
                effectSampleSize += (1 - alpha * effectSampleSize) * (1 - max);
            }
            System.out.println(max + " " + effectSampleSize);
        }

        return effectSampleSize;
    }

    public static double calculateEffectSampleSizeColtGao(DoubleMatrix2D corrMat,
            Set<Integer> selectedSampleIndex, double threshold) throws Exception {
        //reference http://www.ncbi.nlm.nih.gov/pubmed/18425821
        int originalSampleSize = corrMat.columns();
        int newSampleSize = originalSampleSize;
        if (selectedSampleIndex != null && selectedSampleIndex.size() > 0) {
            // System.out.println("Removed columns and rows: " + highlyCorrIndexes.toString());
            newSampleSize = selectedSampleIndex.size();

            DoubleMatrix2D tmpCorMat = new DenseDoubleMatrix2D(newSampleSize, newSampleSize);
            int incRow = 0;
            int incCol = 0;
            for (int i = 0; i < originalSampleSize; i++) {
                if (!selectedSampleIndex.contains(i)) {
                    continue;
                }
                incCol = 0;
                for (int j = 0; j < originalSampleSize; j++) {
                    if (!selectedSampleIndex.contains(j)) {
                        continue;
                    }
                    tmpCorMat.setQuick(incRow, incCol, corrMat.getQuick(i, j));
                    incCol++;
                }
                incRow++;
            }
            corrMat = tmpCorMat;
            // System.out.println(corrMat.toString());
        } else if (selectedSampleIndex != null && selectedSampleIndex.isEmpty()) {
            return 0;
        }

        EigenvalueDecomposition ed = new EigenvalueDecomposition(corrMat);
        DoubleMatrix1D eVR = ed.getRealEigenvalues();
        DoubleMatrix1D eVI = ed.getImagEigenvalues();
        // System.out.println(eVR.toString());
        // System.out.println(eVI.toString());
        //double effectSampleSize = newSampleSize;

        double totalThreshold = threshold * newSampleSize;
        double accum = eVR.get(newSampleSize - 1);
        int index = newSampleSize - 2;
        int effectSampleSize = 1;
        while (index >= 0 && accum < totalThreshold) {
            accum += eVR.getQuick(index);
            index--;
            effectSampleSize++;
        }

        return (effectSampleSize);

    }

    public static void main(String[] args) {
        try {
            SpecialFunc sf = new SpecialFunc();
            // sf.calculateEffectSampleSizeApacheMatrix();
            // sf.calculateEffectSampleSizeColtMatrixMyMethod();
            DoubleMatrix2D corrMat = new DenseDoubleMatrix2D(2, 2);
            corrMat.setQuick(0, 0, 1);
            corrMat.setQuick(1, 1, 1);
            corrMat.setQuick(0, 1, 0.5);
            corrMat.setQuick(1, 0, 0.5);
            EigenvalueDecomposition ed = new EigenvalueDecomposition(corrMat);
            DoubleMatrix1D eVR = ed.getRealEigenvalues();
            System.out.println(eVR.toString());

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
