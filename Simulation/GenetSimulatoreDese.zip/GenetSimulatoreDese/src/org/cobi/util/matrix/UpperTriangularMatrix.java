/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.util.matrix;

/**
 *
 * @author mxli
 */
public class UpperTriangularMatrix {
    double[] data;
    int rowNum, colNum;

    public UpperTriangularMatrix(int rowNum, int colNum) {
        this.rowNum = rowNum;
        this.colNum = colNum;
    }
    
}
