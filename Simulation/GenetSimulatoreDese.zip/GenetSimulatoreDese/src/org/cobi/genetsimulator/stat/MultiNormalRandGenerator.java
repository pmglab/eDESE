/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.genetsimulator.stat;

import cern.colt.bitvector.BitVector;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;
import org.apache.commons.math.distribution.NormalDistribution;
import org.apache.commons.math.distribution.NormalDistributionImpl;
import org.apache.commons.math.linear.Array2DRowRealMatrix;
import org.apache.commons.math.linear.EigenDecomposition;
import org.apache.commons.math.linear.EigenDecompositionImpl;
import org.apache.commons.math.linear.RealMatrix;
import org.apache.commons.math.linear.RealVector;
import org.apache.commons.math.random.CorrelatedRandomVectorGenerator;
import org.apache.commons.math.random.GaussianRandomGenerator;
import org.apache.commons.math.random.MersenneTwister;
import org.apache.commons.math.util.MathUtils;
import org.cobi.util.matrix.ApacheMatrixBasic;
import umontreal.ssj.probdistmulti.BiNormalDist;
 

/**
 *
 * @author MX Li
 */
public class MultiNormalRandGenerator {

    final double PRECISION = 1.0e-8;
    RealMatrix jointProb = null;
    RealMatrix covarianceMatrix = null;
    double[] quantileProb = null;

    public RealMatrix getJointProb() {
        return jointProb;
    }

    public void setJointProb(RealMatrix jointProb) {
        this.jointProb = jointProb;
    }

    public RealMatrix getCovarianceMatrix() {
        return covarianceMatrix;
    }

    public void setCovarianceMatrix(RealMatrix covarianceMatrix) {
        this.covarianceMatrix = covarianceMatrix;
    }

    public double[] getQuantileProb() {
        return quantileProb;
    }

    public void setQuantileProb(double[] quantileProb) {
        this.quantileProb = quantileProb;
    }

    public MultiNormalRandGenerator() {
    }

    void stat(BitVector[] s) {
        RealMatrix testJointProb = new Array2DRowRealMatrix(3, 3);
        int size = 0;
        double conditionalProb12 = 0.0;
        double conditionalProb1 = 0.0;
        double conditionalProb2 = 0.0;
        double count = 0.0;
        for (int r = 0; r < s.length; r++) {
            size = s[r].size();
            for (int c = 0; c < size; c++) {
                for (int d = c; d < size; d++) {
                    if (s[r].getQuick(c) && s[r].getQuick(d)) {
                        testJointProb.setEntry(c, d, testJointProb.getEntry(c, d) + 1);
                    }
                }
            }
            if (s[r].getQuick(0)) {
                if (s[r].getQuick(1) && s[r].getQuick(2)) {
                    conditionalProb12 += 1.0;
                }
                if (s[r].getQuick(1)) {
                    conditionalProb1 += 1.0;
                }
                if (s[r].getQuick(2)) {
                    conditionalProb2 += 1.0;
                }
                count += 1.0;
            }
        }

        for (int c = 0; c < size; c++) {
            for (int d = c; d < size; d++) {
                testJointProb.multiplyEntry(c, d, 1.0 / s.length);
            }
        }
      
        System.out.println(conditionalProb12 / count - conditionalProb1 * conditionalProb2 / count / count);
        System.out.println(testJointProb.getEntry(1, 2) - testJointProb.getEntry(1, 1) * testJointProb.getEntry(2, 2));

    }

    public void generateMultiNormalRandomVector() throws Exception {
        double[] mean = new double[3];
        Arrays.fill(mean, 0.0);
        int num = 1000000;
        BitVector[] genotypes = new BitVector[num];

        try {
            CorrelatedRandomVectorGenerator sg = new CorrelatedRandomVectorGenerator(mean, covarianceMatrix, PRECISION, new GaussianRandomGenerator(new MersenneTwister()));
            for (int i = 0; i < num; i++) {
                double[] samples = sg.nextVector();
                genotypes[i] = new BitVector(3);
                for (int j = 0; j < 3; j++) {
                    if (samples[j] <= quantileProb[j]) {
                        genotypes[i].putQuick(j, true);
                    }
                }
            }
            stat(genotypes);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(-1);
        }
    }

    public void readJointProb(String filePath) throws Exception {
        String delmiliter = "\t  ,";
        BufferedReader br = new BufferedReader(new FileReader(filePath));
        String line = null;
        int rowNum = 0;
        int colNum = -1;
        List<Double> tmpVector = new ArrayList<Double>();
        while ((line = br.readLine()) != null) {
            StringTokenizer tokenizer = new StringTokenizer(line, delmiliter);
            if (colNum < 0) {
                colNum = tokenizer.countTokens();
            }
            while (tokenizer.hasMoreTokens()) {
                tmpVector.add(new Double(tokenizer.nextToken().trim()));
            }
            rowNum++;
        }
        br.close();
        int i = 0;
        int len = tmpVector.size();
        jointProb = new Array2DRowRealMatrix(rowNum, colNum);
        for (i = 0; i < len; i++) {
            jointProb.setEntry(i / colNum, i % colNum, tmpVector.get(i));
        }

        tmpVector.clear();
        tmpVector = null;
        System.out.println(" A matrix with " + rowNum + " rows and " + colNum + " columns has been read from " + filePath);
        

    }

    public void exploreCovarMatrix() throws Exception {
        int rowNum = jointProb.getRowDimension();
        if (rowNum != jointProb.getColumnDimension()) {
            throw (new Exception("unequal number of row and column for the joint probability matrix!"));
        }
        covarianceMatrix = new Array2DRowRealMatrix(rowNum, rowNum);
        NormalDistribution normalDis = new NormalDistributionImpl();
        quantileProb = new double[rowNum];
        for (int i = 0; i < rowNum; i++) {
            covarianceMatrix.setEntry(i, i, 1.0);
            quantileProb[i] = normalDis.inverseCumulativeProbability(jointProb.getEntry(i, i));
        }

        for (int i = 0; i < rowNum; i++) {
            for (int j = i + 1; j < rowNum; j++) {
                double element = findRho(quantileProb[i], quantileProb[j], jointProb.getEntry(i, j));
                covarianceMatrix.setEntry(i, j, element);
                covarianceMatrix.setEntry(j, i, element);
            }
        }
        System.out.println("The covariance matrix with " + rowNum + " rows and " + rowNum + " columns has been generated!");
//        if (!ApacheMatrixBasic.isPositiveDefinite(covarianceMatrix)) {
//           // LocalString.print2DRealMatrix(covarianceMatrix);
//            System.out.println("covarianceMatrix is not PositiveDefinite! Approximating an PositiveDefinite Matrix!");
//            covarianceMatrix = approximatePositiveDefiniteMatrix(covarianceMatrix);
//        }
       //  LocalString.print2DRealMatrix(covarianceMatrix);
         //System.out.println();
    }

    
     
     
    private RealMatrix covarianceMat2correlationMat(final RealMatrix covMat, RealMatrix sd) throws Exception {
        /*
        "covarianceMat2correlationMat" <-
        function(cov.mat){
        dc <- diag(cov.mat)
        So <- sqrt(dc)
        ds <- diag(1/So)
        Mo <- ds %*% cov.mat %*% ds
        Mo <- Mo - 0.5*(Mo-t(Mo)) # Correct any round-off error
        return(list(mat=Mo,sd=So))
        }
         */
        RealMatrix dc = ApacheMatrixBasic.getDiagonal(covMat);
        int rowNum = dc.getRowDimension();
        for (int i = 0; i < rowNum; i++) {
            sd.setRowVector(i, dc.getRowVector(i).mapSqrt());
        }
        RealMatrix ds = ApacheMatrixBasic.getDiagonal(ApacheMatrixBasic.mapInv(sd));
        RealMatrix mO = ds.multiply(covMat).multiply(ds);
        mO = mO.subtract((mO.subtract(mO.transpose())).scalarMultiply(0.5));
        return mO;
    }

    private RealMatrix sumsqscale(final RealMatrix mat) throws Exception {
        /*
        "sumsqscale" <-
        function(mat){
        s <- sign(mat)
        sq <- mat^2
        ssq <- apply(sq, 2, sum)
        for (i in 1:ncol(mat)) sq[,i] <- sq[,i] / ssq[i]
        return (s*sqrt(sq))
        }
         */

        RealMatrix s = ApacheMatrixBasic.mapSignum(mat);
        RealMatrix sq = ApacheMatrixBasic.mapPow(mat, 2);
        RealVector ssq = ApacheMatrixBasic.sumColumn(sq);
        int num = sq.getColumnDimension();
        for (int i = 0; i < num; i++) {
            sq.setColumnVector(i, sq.getColumnVector(i).mapDivide(ssq.getEntry(i)));
        }
        RealMatrix sumsqscale = ApacheMatrixBasic.ebeMultiply(s, ApacheMatrixBasic.mapSqrt(sq));
        return sumsqscale;
    }

    private RealMatrix correlationMat2covarianceMat(final RealMatrix covMat, final RealMatrix sd) throws Exception {
        /*
        "correlationMat2covarianceMat" <-
        function(cor.mat, sd){
        dc <- diag(cor.mat)
        ds <- diag(sd)
        Mo <- ds %*% cor.mat %*% ds
        Mo <- Mo - 0.5 * (Mo-t(Mo)) # Correct any round-off error
        Mo <- Mo - diag(diag(Mo)-sd * sd)
        return(Mo)
        }
         */
        // RealMatrix dc = ApacheMatrixBasic.getDiagonal(covMat);
        RealMatrix ds = ApacheMatrixBasic.getDiagonal(sd);

        RealMatrix mO = ds.multiply(covMat).multiply(ds);
        mO = mO.subtract((mO.subtract(mO.transpose())).scalarMultiply(0.5));
        mO = mO.subtract(ApacheMatrixBasic.getDiagonal(ApacheMatrixBasic.getDiagonal(mO).subtract(ApacheMatrixBasic.ebeMultiply(sd, sd))));
        return mO;
    }

    public RealMatrix approximatePositiveDefiniteMatrix(RealMatrix mat) throws Exception {
        /*
        "makepd" <-
        function(mat, eig.tol=1.0000e-06){
        cor.mat <- covarianceMat2correlationMat(mat)
        mat <- cor.mat$mat
        eig <- eigenValues(mat,sym = TRUE, EISPACK = TRUE)
        D <- sort(eig$values)
        S <- eig$vectors[,order(sort(D, decreasing=TRUE ))]
        D[which(D<eig.tol)] <- eig.tol
        for (i in 1:ncol(S)) S[,i] <- S[,i] * D[i]
        B <- t(sumsqscale(t(S)))
        A <- B %*% t(B)
        return (correlationMat2covarianceMat(A, cor.mat$sd))
        }
         */
        
        int minDim = Math.min(mat.getRowDimension(), mat.getColumnDimension());
        RealMatrix sd = new Array2DRowRealMatrix(minDim, minDim);
        RealMatrix corMat = covarianceMat2correlationMat(mat, sd);

//eigenValues
        EigenDecomposition eigenDeco = new EigenDecompositionImpl(corMat, MathUtils.SAFE_MIN);
        double[] eigenValues = eigenDeco.getRealEigenvalues();
        //sort eigenValues value and vectors
        double tmpMax = 0;
        int tmpMaxIndex = 0;
        int num = eigenValues.length;
        RealMatrix eigenVectors = new Array2DRowRealMatrix(num, num);
        for (int i = 0; i < num; i++) {
            eigenVectors.setColumnVector(i, eigenDeco.getEigenvector(i));
        }
        eigenDeco = null;
        for (int i = num - 1; i >= 0; i--) {
            tmpMax = eigenValues[i];
            tmpMaxIndex = i;
            for (int j = i - 1; j >= 0; j--) {
                if (eigenValues[j] > tmpMax) {
                    tmpMax = eigenValues[j];
                    tmpMaxIndex = j;
                }
            }
            if (tmpMaxIndex != i) {
                eigenValues[tmpMaxIndex] = eigenValues[i];
                eigenValues[i] = tmpMax;
                RealMatrix tmpMatrix = eigenVectors.getColumnMatrix(i);
                eigenVectors.setColumnMatrix(i, eigenVectors.getColumnMatrix(tmpMaxIndex));
                eigenVectors.setColumnMatrix(tmpMaxIndex, tmpMatrix);
            }
            if (eigenValues[i] < PRECISION) {
                eigenValues[i] = PRECISION;
            }
            for (int k = 0; k < num; k++) {
                eigenVectors.multiplyEntry(k, i, eigenValues[i]);
            }
        }

        RealMatrix B = sumsqscale(eigenVectors.transpose()).transpose();
        RealMatrix A = B.multiply(B.transpose());
        //LocalString.print2DRealMatrix(A);
        //System.out.println();

        RealMatrix result = correlationMat2covarianceMat(A, sd);
        //LocalString.print2DRealMatrix(result);
        //System.out.println();
        return result;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        try {
            double[][] data = {{1.0000000, 0.0569067, -0.0504999, 0.0612860},
                {0.0569067, 1.0000000, 0.9999990, 0.9993868},
                {-0.0504999, 0.9999990, 1.0000000, 0.9999990},
                {0.0612860, 0.9993868, 0.9999990, 1.0000000}};
            RealMatrix mat = new Array2DRowRealMatrix(data);
            EigenDecomposition eigenDeco = new EigenDecompositionImpl(mat, MathUtils.SAFE_MIN);
            double[][] d = {{1, 0, 0, 0},
                {0, 1, 0, 0},
                {0, 0, 1, 0},
                {0, 0, 0, 1}};

            RealMatrix E = new Array2DRowRealMatrix(d);

            double[] eigenValues = eigenDeco.getRealEigenvalues();
            RealMatrix eigenVector = new Array2DRowRealMatrix(eigenDeco.getEigenvector(0).getData());
            
            //eigenVector = ApacheMatrixBasic.mapMultiply(eigenVector, -1);
           
            RealMatrix re = E.scalarMultiply(eigenValues[0]).subtract(mat).multiply(eigenVector);
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    /* solves the equation for rho */
    double findRho(double x, double y, double c) throws Exception {
        double a = -1;
        double b = 1;
        double m = 0;
        BiNormalDist biNormDist = new BiNormalDist(0.0);
        double  w=biNormDist.cdf(x, y, 1);
        while ((b - a) > PRECISION) {
            m = (a + b) / 2;
            if (biNormDist.cdf(x, y, m) == c) {
                break;
            }
            if (biNormDist.cdf(x, y, m) < c) {
                a = m;
            } else {
                b = m;
            }
        }
        return m;
    }
}
