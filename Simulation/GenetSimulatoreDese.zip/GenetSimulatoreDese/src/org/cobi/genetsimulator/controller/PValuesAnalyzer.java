/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.genetsimulator.controller;

import Jama.Matrix;
import cern.colt.list.DoubleArrayList;
import cern.colt.list.IntArrayList;
import cern.colt.matrix.DoubleMatrix1D;
import cern.colt.matrix.DoubleMatrix2D;
import cern.colt.matrix.impl.DenseDoubleMatrix1D;
import cern.colt.matrix.impl.DenseDoubleMatrix2D;
import cern.colt.matrix.linalg.Algebra;
import cern.colt.matrix.linalg.CholeskyDecomposition;
import cern.colt.matrix.linalg.EigenvalueDecomposition;
import cern.jet.stat.Descriptive;
import cern.jet.stat.Gamma;
import cern.jet.stat.Probability;
import com.sun.corba.se.spi.orbutil.threadpool.ThreadPool;
import genetsimulatoredese.Constants;
import static genetsimulatoredese.Constants.FILE_READER_BUFFER_SIZE;
import static genetsimulatoredese.Constants.MAX_THREAD_NUM;
import genetsimulatoredese.GlobalVariables;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import org.apache.commons.math.distribution.ChiSquaredDistributionImpl;
import org.apache.commons.math.distribution.GammaDistribution;
import org.apache.commons.math.distribution.GammaDistributionImpl;
import org.apache.commons.math.linear.Array2DRowRealMatrix;
import org.apache.commons.math.linear.RealMatrix;
import org.apache.commons.math.random.CorrelatedRandomVectorGenerator;
import org.apache.commons.math.random.GaussianRandomGenerator;
import org.apache.commons.math.random.MersenneTwister;

import org.cobi.genetsimulator.entity.AnnotSNP;
import org.cobi.genetsimulator.entity.Individual;
import org.cobi.genetsimulator.entity.PValueSet;
import org.cobi.genetsimulator.entity.PValueWeight;
import org.cobi.genetsimulator.entity.PValueWeightPComparator;
import org.cobi.genetsimulator.entity.PedFileSet;

import org.cobi.util.matrix.SpecialFunc;
import org.cobi.util.stat.MultipleTestingMethod;
import org.cobi.util.stat.NNLMSolverJavaTask;
import org.cobi.util.stat.NNLSSolver;
import org.cobi.util.stat.WNNLSSolver;
import org.cobi.util.stat.WeightedNNLS;
import org.cobi.util.thread.TaskQueue;

import org.ejml.data.DMatrixRMaj;
import org.ejml.dense.row.CommonOps_DDRM;

import org.ejml.dense.row.decomposition.svd.SvdImplicitQrDecompose_DDRM;

import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.rosuda.REngine.Rserve.RConnection;
import umontreal.ssj.probdist.ChiSquareDist;
import umontreal.ssj.probdistmulti.BiNormalDist;
import umontreal.ssj.randvar.NormalGen;
import umontreal.ssj.randvarmulti.MultinormalCholeskyGen;
import umontreal.ssj.rng.MT19937;
import umontreal.ssj.rng.WELL607;

/**
 *
 * @author mxli
 */
public class PValuesAnalyzer implements Constants {

    private static List<Individual> indList = Collections.synchronizedList(new ArrayList<Individual>());
    private static List<PValueSet[]> permuHistogramSets = Collections.synchronizedList(new ArrayList<PValueSet[]>());

    public PValueSet[] histogram(double[] pValues, double[][] range) {
        int rowNum = range.length;
        int pNum = pValues.length;
        double effectiveNum = 0;
        int count = 0;
        for (int j = 0; j < pNum; j++) {
            if (pValues[j] >= 0 && pValues[j] <= 1.0) {
                effectiveNum += 1.0;
            } else {
                System.err.println(pValues[j]);
            }

        }
        PValueSet[] pvalueCount = new PValueSet[rowNum];

        for (int i = 0; i < rowNum; i++) {
            count = 0;
            for (int j = 0; j < pNum; j++) {
                if (pValues[j] >= range[i][0] && pValues[j] < range[i][1]) {
                    count++;
                }
            }

            pvalueCount[i] = new PValueSet(count, count / effectiveNum);
        }
        return pvalueCount;
    }

    public double[] readPValues(String pValueFileName) throws Exception {
        File pValueFile = new File(pValueFileName);
        BufferedReader br = new BufferedReader(new FileReader(pValueFile), FILE_READER_BUFFER_SIZE);
        String line = null;
        String delmilit = ", \t";
        int pValueIndex = 8;

        DoubleArrayList pValueList = new DoubleArrayList();

        //skip the head line
        br.readLine();
        String tmpStr;
        int index;
        int lineCounter = -1;
        StringBuffer tmpBuffer = new StringBuffer();
        try {
            while ((line = br.readLine()) != null) {
                if (line.trim().length() == 0) {
                    continue;
                }
                lineCounter++;
                StringTokenizer tokenizer = new StringTokenizer(line, delmilit);
                index = 0;

                while (tokenizer.hasMoreTokens()) {
                    tmpBuffer.delete(0, tmpBuffer.length());
                    tmpBuffer.append(tokenizer.nextToken().trim());
                    tmpStr = tmpBuffer.toString();
                    if (index == pValueIndex) {
                        double p = Double.parseDouble(tmpStr);
                        pValueList.add(p);
                    }
                    if (index == pValueIndex) {
                        break;
                    }
                    index++;
                }
            }

            StringBuffer runningInfo = new StringBuffer();
            runningInfo.append("The number of SNPs  in map file ");
            runningInfo.append(pValueFile.getName());
            runningInfo.append(" is ");
            runningInfo.append(pValueList.size());
            runningInfo.append(".");

            GlobalVariables.addInforLog(runningInfo.toString());
            int size = pValueList.size();
            double[] pValues = new double[size];
            for (int i = 0; i < size; i++) {
                pValues[i] = pValueList.get(i);
            }
            return (pValues);
        } finally {
            br.close();
        }

    }

    public void pValueDistribution(double[] pValues) throws Exception {
        double[][] thresholds = {{0, 0.01}, {0, 0.05}, {0, 0.1}, {0, 0.2}, {0, 0.3}, {0, 0.4}, {0, 0.5}, {0.01, 0.2}, {0.05, 0.2}, {0.05, 0.5}, {0.2, 0.5}};
        //double[][] thresholds = {{0, 0.01}, {0.01, 0.02}, {0.02, 0.03}, {0.03, 0.04}, {0.04, 0.05}, {0.05, 0.06}, {0.06, 0.07}, {0.07, 0.08}, {0.08, 0.09}, {0.09, 0.1}, {0.1, 0.11}, {0.11, 0.12}, {0.12, 0.13}, {0.13, 0.14}, {0.14, 0.15}, {0.15, 0.16}, {0.16, 0.17}, {0.17, 0.18}, {0.18, 0.19}, {0.19, 0.2}, {0.2, 0.21}, {0.21, 0.22}, {0.22, 0.23}, {0.23, 0.24}, {0.24, 0.25}, {0.25, 0.26}, {0.26, 0.27}, {0.27, 0.28}, {0.28, 0.29}, {0.29, 0.3}, {0.3, 0.31}, {0.31, 0.32}, {0.32, 0.33}, {0.33, 0.34}, {0.34, 0.35}, {0.35, 0.36}, {0.36, 0.37}, {0.37, 0.38}, {0.38, 0.39}, {0.39, 0.4}, {0.4, 0.41}, {0.41, 0.42}, {0.42, 0.43}, {0.43, 0.44}, {0.44, 0.45}, {0.45, 0.46}, {0.46, 0.47}, {0.47, 0.48}, {0.48, 0.49}, {0.49, 0.5}, {0.5, 0.51}, {0.51, 0.52}, {0.52, 0.53}, {0.53, 0.54}, {0.54, 0.55}, {0.55, 0.56}, {0.56, 0.57}, {0.57, 0.58}, {0.58, 0.59}, {0.59, 0.6}, {0.6, 0.61}, {0.61, 0.62}, {0.62, 0.63}, {0.63, 0.64}, {0.64, 0.65}, {0.65, 0.66}, {0.66, 0.67}, {0.67, 0.68}, {0.68, 0.69}, {0.69, 0.7}, {0.7, 0.71}, {0.71, 0.72}, {0.72, 0.73}, {0.73, 0.74}, {0.74, 0.75}, {0.75, 0.76}, {0.76, 0.77}, {0.77, 0.78}, {0.78, 0.79}, {0.79, 0.8}, {0.8, 0.81}, {0.81, 0.82}, {0.82, 0.83}, {0.83, 0.84}, {0.84, 0.85}, {0.85, 0.86}, {0.86, 0.87}, {0.87, 0.88}, {0.88, 0.89}, {0.89, 0.9}, {0.9, 0.91}, {0.91, 0.92}, {0.92, 0.93}, {0.93, 0.94}, {0.94, 0.95}, {0.95, 0.96}, {0.96, 0.97}, {0.97, 0.98}, {0.98, 0.99}, {0.99, 1}};

        PValueSet[] observedSet = histogram(pValues, thresholds);
        for (int j = 0; j < thresholds.length; j++) {
            System.out.println(observedSet[j].getCount() + " " + observedSet[j].getProportion());
        }
    }

    // a method proposed by Zaykin et al (2007) Combining minP-values in large-scale genomics experiments.
    public double combinePValuebyGammaMethod(double[] pValueArray) throws Exception {

        double a = 0.0137;
        double b = 1;
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }
        GammaDistribution gameDis = new GammaDistributionImpl(a, b);

        int testNum = 0;
        double Y = 0;
        for (int i = 0; i < snpSize; i++) {
            double p = pValueArray[i];
            if (p < 1e-16) {
                p = 1e-16;
                Y += gameDis.inverseCumulativeProbability(1 - p);
                testNum++;
            } else if (p < 1.0) {
                Y += gameDis.inverseCumulativeProbability(1 - p);
                testNum++;
            }
        }
        if (testNum > 0) {
            double p = 1 - gameDis.cumulativeProbability(Y);
            if (p < 0.0) {
                p = 0.0;
            }
            return p;
        } else {
            return 1.0;
        }
    }

    public double combinePValuebyFisherCombinationTest(double[] pValueArray) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }

        double Y = 0;
        for (int i = 0; i < snpSize; i++) {
            double p = pValueArray[i];
            Y += (-2 * Math.log(p));
        }
        double p = Probability.chiSquareComplemented(snpSize * 2, Y);
        if (p < 0.0) {
            p = 0.0;
        }
        return p;

    }

    public double combinePValuebyFisherCombinationTest(double[] pValueArray, int snpSize) throws Exception {
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }

        double Y = 0;
        for (int i = 0; i < snpSize; i++) {
            double p = pValueArray[i];
            Y += (-2 * Math.log(p));
        }
        double p = Probability.chiSquareComplemented(snpSize * 2, Y);
        if (p < 0.0) {
            p = 0.0;
        }
        return p;
    }

    public double combinePValuebyScaleedFisherCombinationTest(double[] pValueArray, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }

        double Y = 0;
        for (int i = 0; i < snpSize; i++) {
            double p = pValueArray[i];
            Y += (-2 * Math.log(p));
        }
        //calcualte the scalled chi
        double varTD = 4 * snpSize;
        double a1 = 3.263119, a2 = 0.709866, a3 = 0.026589, a4 = 0.709866;
        //double a1 = 3.263, a2 = 0.710, a3 = 0.027, a4 = 0.709866;
        for (int i = 0; i < snpSize; i++) {
            for (int j = i + 1; j < snpSize; j++) {
                varTD += 2 * (a1 * ldCorr.get(i, j) + a2 * ldCorr.get(i, j) * ldCorr.get(i, j) + a3 * ldCorr.get(i, j) * ldCorr.get(i, j) * ldCorr.get(i, j));
            }
        }
        // varTD = 8 + 2 * 0.98;
        double c = varTD / (4 * snpSize);
        double f = 8 * snpSize * snpSize / varTD;
        double p = Probability.chiSquareComplemented(f, Y / c);
        if (p < 0.0) {
            p = 0.0;
        }
        return p;

    }

    public double combinePValuebyStouffer(PValueWeight[] pValueArray, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0].pValue;
        }

        Set<Integer> selectedIndex = new HashSet<Integer>();

        DoubleMatrix2D covP = new DenseDoubleMatrix2D(snpSize, snpSize);
        for (int i = 0; i < snpSize; i++) {
            covP.setQuick(i, i, 1);
            selectedIndex.add(pValueArray[i].index);
            for (int j = i + 1; j < snpSize; j++) {
                if (i == j) {
                    continue;
                }
                //poweredcorrMat.setQuick(j, j, Math.pow(corrMat.getQuick(j, j), power));
                double x = ldCorr.getQuick(pValueArray[i].index, pValueArray[j].index);
                x = x * x;
                //when r2                 
                //I do not know why it seems if I use x1=x1*x1  it woks better in terms of type 1 error
                x = (((((0.7723 * x - 1.5659) * x + 1.201) * x - 0.2355) * x + 0.2184) * x + 0.6086) * x;
                //x = x1 * x1;
                covP.setQuick(pValueArray[i].index, pValueArray[j].index, x);
                covP.setQuick(pValueArray[j].index, pValueArray[i].index, x);
            }
        }

        DoubleMatrix1D pvs = new DenseDoubleMatrix1D(snpSize);
        CholeskyDecomposition cd = new CholeskyDecomposition(covP);

        Algebra algb = new Algebra();

        DoubleMatrix2D lowInversTriangle = algb.inverse(cd.getL());

        // System.out.println(cd.getL().zMult(lowInversTriangle,null).toString());
        double q = 0;
        for (int i = 0; i < snpSize; i++) {
            if (pValueArray[i].pValue > 0.5) {
                if (pValueArray[i].pValue >= 1) {
                    //the Probability.normalInverse could handle 1E-323 but cannot handle 1-(1E-323)
                    q = Probability.normalInverse(1E-323);
                } else {
                    q = Probability.normalInverse(1 - pValueArray[i].pValue);
                }
            } else {
                if (pValueArray[i].pValue < 1E-320) {
                    pValueArray[i].pValue = 1E-320;
                }
                q = -Probability.normalInverse(pValueArray[i].pValue);
            }
            pvs.setQuick(i, q);
        }

        DoubleMatrix1D transvertP = lowInversTriangle.zMult(pvs, null);
        double Y = 0;
        for (int i = 0; i < snpSize; i++) {
            Y += transvertP.getQuick(i);
        }

        Y /= Math.sqrt(snpSize);
        double p = 1 - Probability.normal(Y);
        if (p < 0.0) {
            p = 0.0;
        }
        return p;
    }

    public double combinePValuebyStoufferTwo(PValueWeight[] pValueArray, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0].pValue;
        }

        double x = ldCorr.getQuick(pValueArray[0].index, pValueArray[1].index);
        x = x * x;
        //when r2                 
        //I do not know why it seems if I use x1=x1*x1  it woks better in terms of type 1 error
        x = (((((0.7723 * x - 1.5659) * x + 1.201) * x - 0.2355) * x + 0.2184) * x + 0.6086) * x;

        double p1 = pValueArray[0].pValue;
        double p2 = pValueArray[1].pValue;

        double q1 = 0, q2 = 0;

        if (p1 > 0.5) {
            if (p1 >= 1) {
                //the Probability.normalInverse could handle 1E-323 but cannot handle 1-(1E-323)
                q1 = Probability.normalInverse(1E-323);
            } else {
                q1 = Probability.normalInverse(1 - p1);
            }
        } else {
            if (p1 < 1E-320) {
                q1 = 1E-320;
            }
            q1 = -Probability.normalInverse(p1);
        }
        if (p2 > 0.5) {
            if (p2 >= 1) {
                //the Probability.normalInverse could handle 1E-323 but cannot handle 1-(1E-323)
                q2 = Probability.normalInverse(1E-323);
            } else {
                q2 = Probability.normalInverse(1 - p2);
            }
        } else {
            if (p2 < 1E-320) {
                q2 = 1E-320;
            }
            q2 = -Probability.normalInverse(p2);
        }

        p2 = q2 - x * q1;
        p2 = p2 / Math.sqrt(1 - x * x);
        //p2 = 1 - Probability.normal(p2);
        double Y = 0;
        Y = pValueArray[0].var * q1 + pValueArray[1].var * p2;
        Y /= Math.sqrt(pValueArray[0].var * pValueArray[0].var + pValueArray[1].var * pValueArray[1].var);
        double p = 1 - Probability.normal(Y);

        if (p < 0.0) {
            p = 0.0;
        }
        return p;
    }

    public double combinePValuebyScaleedFisherCombinationTestCovLogP(double[] pValueArray, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }

        DoubleMatrix2D covLogP = new DenseDoubleMatrix2D(snpSize, snpSize);
        for (int i = 0; i < snpSize; i++) {
            for (int j = i + 1; j < snpSize; j++) {
                if (i == j) {
                    continue;
                }
                double x1 = ldCorr.getQuick(i, j);

                //for r
                //y = 0.0079x3 + 3.9459x2 - 0.0024x ; y = 0.0331x3 + 3.9551x2 - 0.0156x
                //x = 0.0331 * (Math.pow(x1, 3)) + 3.9551 * (Math.pow(x1, 2)) - 0.0156 * x1;
                if (x1 < 0) {
                    x1 = -x1;
                }
                x1 = (0.75 * x1 + 3.25) * x1;

                /*
                 //the formular I used in KGG
                 if (x > 0.5) {
                 x = 0.75 * x + 3.25 * Math.sqrt(x);
                 } else {
                 x = 8.6 * x;
                 //  x1 = 0.75 * x1 + 3.25 * Math.sqrt(x1);
                 }
                 */
                //for r2
                // x1 = x1 * x1;
                // x1 = 3.9471 * x1;
                // x1 = 4 * x1;
                covLogP.setQuick(i, j, x1);
            }
        }

        double Y = 0;
        for (int i = 0; i < snpSize; i++) {
            double p = pValueArray[i];
            Y += (-2 * Math.log(p));
        }
        //calcualte the scalled chi
        double varTD = 4 * snpSize;
        for (int i = 0; i < snpSize; i++) {
            for (int j = i + 1; j < snpSize; j++) {
                varTD += 2 * covLogP.get(i, j);
            }
        }
        double c = varTD / (4 * snpSize);
        double f = 8 * snpSize * snpSize / varTD;
        double p = Probability.chiSquareComplemented(f, Y / c);
        if (p < 0.0) {
            p = 0.0;
        }
        return p;
    }

    public double combinePValuebyCorrectedChiFisherCombinationTestMXLi(double[] pValueArray, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }

        double[] chisquares1 = new double[snpSize];
        for (int i = 0; i < snpSize; i++) {
            chisquares1[i] = pValueArray[i] / 2;
        }
        double[] chisquares = MultipleTestingMethod.zScores(chisquares1);
        DoubleMatrix2D A = new DenseDoubleMatrix2D(snpSize, snpSize);
        for (int i = 0; i < snpSize; i++) {
            A.set(i, i, 1);
            for (int j = i + 1; j < snpSize; j++) {
                double r = ldCorr.getQuick(i, j);
                r = r * r;
                r = Math.pow(r, 0.75);
                A.set(i, j, r);
                A.set(j, i, r);
            }
        }

        double threshold = 0.05;
        int columnNum = 997;
        double scale = 10;
        double pairThreshold = 0.3;
        int maxBlock = 5;

        //  System.out.println(A.toString());
        /// ArrayList<Integer[]> blockCluster = new MarixDensity().getCluster(A, threshold, maxBlock, scale, pairThreshold);
        return mySudoSVDSolver(A, chisquares);

    }

    //http://math.stackexchange.com/questions/442472/sum-of-squares-of-dependent-gaussian-random-variables
    public double combinePValuebyQuadraticFormJohnny(double[] z, DoubleMatrix2D ldCorr, RConnection rcon) throws Exception {
        int snpSize = z.length;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return z[0];
        }

        // double[] chisquares = MultipleTestingMethod.zScores(z);
        double[] chisquares = new double[z.length];

        /*
        for (int i = 0; i < snpSize; i++) {
            for (int j = i + 1; j < snpSize; j++) {
                ldCorr.setQuick(i, j, Math.abs(ldCorr.getQuick(i, j)));
                ldCorr.setQuick(j, i, (ldCorr.getQuick(i, j)));
            }
        }
         */
        EigenvalueDecomposition ed = new EigenvalueDecomposition(ldCorr);
        DoubleMatrix1D eVR = ed.getRealEigenvalues();
        DoubleMatrix2D vectors = ed.getV();
        DoubleMatrix2D values = new DenseDoubleMatrix2D(snpSize, snpSize);
        double[] weights = eVR.toArray();
        boolean hasNeg = false;
        double deg = 0, chi = 0;
        DoubleMatrix2D y = new DenseDoubleMatrix2D(snpSize, snpSize);
        DoubleMatrix2D zs = new DenseDoubleMatrix2D(snpSize, 1);
        DoubleMatrix2D y1 = new DenseDoubleMatrix2D(snpSize, 1);
        for (int i = 0; i < weights.length; i++) {
            values.setQuick(i, i, weights[i] <= 0 ? 0 : 1 / Math.sqrt(weights[i]));
            zs.setQuick(i, 0, z[i]);
        }
        // zs.viewDice().zMult(vectors, y1);
        //y1.zMult(vectors.viewDice(), y1);

        values.zMult(vectors.viewDice(), y);
        y.zMult(zs, y1);
        for (int i = 0; i < weights.length; i++) {
            //if (weights[i] < 0) 
            {
                hasNeg = true;
                // weights[i] = 0;
                deg += weights[i];
                chi += (weights[i] * y1.getQuick(i, 0) * y1.getQuick(i, 0));
            }
        }
        //https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4726509/
        double p = Gamma.incompleteGammaComplement(deg / 2, chi / 2);
        if (hasNeg) {
            int sss = 0;
            // System.out.println(ed.getD().toString());
        }
        // rcon.assign("weights", weights);

        /*
        double p = rcon.eval("pchisqsum(" + Y + ",df=rep(1," + snpSize + "),method=\"int\",lower=FALSE,a=weights)").asDouble();//This step will cost a lot of time. 
        if (p < 1E-8) {
            int sss = 0;
            //  System.out.println(eVR.toString());
            //  System.out.println(ed.getImagEigenvalues());
        }
         */
        return p;
    }

    //http://math.stackexchange.com/questions/442472/sum-of-squares-of-dependent-gaussian-random-variables
    public double combinePValuebyQuadraticFormCondition(double[] pValues, DoubleMatrix2D ldCorr, RConnection rcon) throws Exception {
        int snpSize = pValues.length;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValues[0];
        }

        double[] chisquares = MultipleTestingMethod.zScores(pValues);
        double Y = 0;
        for (int i = 0; i < snpSize; i++) {
            Y += (chisquares[i] * chisquares[i]);
            for (int j = i + 1; j < snpSize; j++) {
                ldCorr.setQuick(i, j, Math.abs(ldCorr.getQuick(i, j)));
                ldCorr.setQuick(j, i, (ldCorr.getQuick(i, j)));
            }
        }
        EigenvalueDecomposition ed = new EigenvalueDecomposition(ldCorr);
        DoubleMatrix1D eVR = ed.getRealEigenvalues();
        double[] weights = eVR.toArray();
        boolean hasNeg = false;
        for (int i = 0; i < weights.length; i++) {
            if (weights[i] < 0) {
                hasNeg = true;
                //  weights[j] = 0;
            }
        }
        if (hasNeg) {
            int sss = 0;
            // System.out.println(ed.getD().toString());
        }
        rcon.assign("weights", weights);

        double p1 = rcon.eval("pchisqsum(" + Y + ",df=rep(1," + snpSize + "),method=\"int\",lower=FALSE,a=weights)").asDouble();//This step will cost a lot of time. 
        if (p1 < 1E-8) {
            int sss = 0;
            //  System.out.println(eVR.toString());
            //  System.out.println(ed.getImagEigenvalues());
        }
        int cutIndex = 12;
        DoubleMatrix2D ldCorr1 = new DenseDoubleMatrix2D(cutIndex, cutIndex);
        Y = 0;
        for (int i = 0; i < cutIndex; i++) {
            Y += (chisquares[i] * chisquares[i]);
            ldCorr1.setQuick(i, i, 1);
            for (int j = i + 1; j < cutIndex; j++) {
                ldCorr1.setQuick(i, j, ldCorr.getQuick(i, j));
                ldCorr1.setQuick(j, i, (ldCorr.getQuick(i, j)));
            }
        }

        ed = new EigenvalueDecomposition(ldCorr1);
        eVR = ed.getRealEigenvalues();
        weights = eVR.toArray();
        hasNeg = false;
        for (int i = 0; i < weights.length; i++) {
            if (weights[i] < 0) {
                hasNeg = true;
                // weights[j] = 0;
            }
        }

        if (hasNeg) {
            int sss = 0;
            // System.out.println(ed.getD().toString());
        }
        rcon.assign("weights", weights);

        double p2 = rcon.eval("pchisqsum(" + Y + ",df=rep(1," + cutIndex + "),method=\"int\",lower=FALSE,a=weights)").asDouble();//This step will cost a lot of time. 
        if (p2 < 1E-8) {
            int sss = 0;
            //  System.out.println(eVR.toString());
            //  System.out.println(ed.getImagEigenvalues());
        }

        double chi1 = 0;
        if (p1 < 1E-0) {
            chi1 = MultipleTestingMethod.iterativeChisquareInverse(2, p1);
        } else {
            chi1 = ChiSquareDist.inverseF(2, 1 - p1);
        }
        double chi2 = 1;
        if (p2 < 1E-0) {
            chi2 = MultipleTestingMethod.iterativeChisquareInverse(1, p2);
        } else {
            chi2 = ChiSquareDist.inverseF(1, 1 - p2);
        }
        double px = Probability.chiSquareComplemented(1, (chi1 - chi2) <= 0 ? 0 : chi1 - chi2);

        /*
         //This function has inflation
         double z1 = Probability.normalInverse(p1 < 0.5 ? p1 : 1 - p1);
         z1 = p1 < 0.5 ? -z1 : z1;
         double z2 = Probability.normalInverse(p2 < 0.5 ? p2 : 1 - p2);
         z2 = p2 < 0.5 ? -z2 : z2;
         double z3 = Math.sqrt(2) * z1 - z2;

         p1 = Probability.normal(z3 < 0 ? z3 : -z3);
         p1 = z3 < 0 ? 1 - p1 : p1;
         if (p1 < 1e-4) {
         int sss = 0;
         }
         */
        return px;
    }

    public void nnlmSolver(RConnection rcon, double[] A, double[] b, DMatrixRMaj finalX1, DMatrixRMaj finalX2) throws Exception {
        int size = b.length / 2;
        rcon.assign("A", A);
        rcon.voidEval("A<-matrix(A, nrow=" + size + ", ncol=" + size + ", byrow = TRUE)");
        rcon.assign("b", b);
        rcon.voidEval("b<-matrix(b, nrow=" + size + ", ncol=" + 2 + ", byrow = TRUE)");
        //rcon.voidEval("beta <- nnlm(A, b, loss = 'mkl')");
        rcon.voidEval("beta <- nnlm(A, b, max.iter=1000000, n.threads=4 )"); //
        double[][] coeffs = rcon.eval("beta$coefficients").asDoubleMatrix();
        for (int i = 0; i < size; i++) {
            finalX1.set(i, 0, coeffs[i][0]);
            finalX2.set(i, 0, coeffs[i][1]);
            /*
      for (int j = 0; j < size; j++) {
        System.out.print(A[i * size + j] + "\t");
      }
      System.out.println();
             */
        }

    }

    public void nnlsSolver(RConnection rcon, double[] A, double[] b, DMatrixRMaj finalX1, DMatrixRMaj finalX2) throws Exception {
        int size = b.length / 2;
        rcon.assign("A", A);
        rcon.voidEval("A<-matrix(A, nrow=" + size + ", ncol=" + size + ", byrow = TRUE)");
        double[] bb = new double[size];
        for (int t = 0; t < size; t++) {
            bb[t] = b[t + t];
        }
        rcon.assign("b", b);
        rcon.voidEval("b<-matrix(b, nrow=" + size + ", ncol=" + 1 + ", byrow = TRUE)");
        //rcon.voidEval("beta <- nnlm(A, b, loss = 'mkl')");
        rcon.voidEval("beta <- nnls(A, b)");
        double[] coeffs = rcon.eval("beta$x").asDoubles();
        for (int i = 0; i < size; i++) {
            finalX1.set(i, 0, coeffs[i]);

        }

        for (int t = 0; t < size; t++) {
            bb[t] = b[t + t + 1];
        }

        rcon.assign("b", bb);
        rcon.voidEval("b<-matrix(b, nrow=" + size + ", ncol=" + 1 + ", byrow = TRUE)");
        rcon.voidEval("beta <- nnls(A,b)");
        coeffs = rcon.eval("beta$x").asDoubles();
        for (int i = 0; i < size; i++) {
            finalX2.set(i, 0, coeffs[i]);
        }

    }

    public void nnlsSolver(double[][] A, double[][] b, double[] w, DMatrixRMaj finalX1, DMatrixRMaj finalX2) throws Exception {
        int dim = A.length;
        Matrix AA = Matrix.constructWithCopy(A);
        Matrix bb = Matrix.constructWithCopy(b);
        Matrix Sigma = new Matrix(dim, dim);
        for (int i = 0; i < Sigma.getRowDimension(); i++) {
            Sigma.set(i, i, w[i]);
        }
        Matrix xNNLS = WeightedNNLS.weightedNNLSSolver(AA, bb, Sigma);

        for (int i = 0; i < dim; i++) {
            finalX1.set(i, 0, xNNLS.get(i, 0));
            finalX2.set(i, 0, xNNLS.get(i, 1));
        }

    }

    public void nnlsSolver1(double[][] A, double[][] b, double[] w, DMatrixRMaj finalX1, DMatrixRMaj finalX2) throws Exception {

        PhysicalStore.Factory<Double, PrimitiveDenseStore> storeFactory = PrimitiveDenseStore.FACTORY;
        PrimitiveDenseStore matrixA = storeFactory.rows(A);
        PrimitiveDenseStore matrixB = storeFactory.rows(b);

        int dim = A.length;

        double[][] Sigma = new double[dim][dim];
        for (int i = 0; i < dim; i++) {
            Sigma[i][i] = w[i];
        }
        PrimitiveDenseStore matrixS = storeFactory.rows(Sigma);
        MatrixStore<Double> xNNLS = WNNLSSolver.WNNLSSolver(matrixA, matrixB, matrixS);

        for (int i = 0; i < dim; i++) {
            finalX1.set(i, 0, xNNLS.get(i, 0));
            finalX2.set(i, 0, xNNLS.get(i, 1));
        }

    }

    public void nnlsSolver(double[][] A, double[][] b, double[] w, DMatrixRMaj finalX1) throws Exception {
        int dim = A.length;
        Matrix AA = Matrix.constructWithCopy(A);
        Matrix bb = Matrix.constructWithCopy(b);
        Matrix Sigma = new Matrix(dim, dim);
        for (int i = 0; i < Sigma.getRowDimension(); i++) {
            Sigma.set(i, i, Math.pow(b[i][0], w[i]));
        }

        Matrix xNNLS = NNLSSolver.solveNNLS(AA, bb, Sigma);

        for (int i = 0; i < dim; i++) {
            finalX1.set(i, 0, xNNLS.get(i, 0));
        }
    }

    public void mySudoSVDSolverEJML(DMatrixRMaj A, DMatrixRMaj b1, DMatrixRMaj b2, DMatrixRMaj finalX1, DMatrixRMaj finalX2) throws Exception {

        SvdImplicitQrDecompose_DDRM svd = new SvdImplicitQrDecompose_DDRM(true, true, true, true);
        svd.decompose(A);
        DMatrixRMaj U = svd.getU(null, true);
        DMatrixRMaj W = svd.getW(null);
        // System.out.println(W.toString());
        DMatrixRMaj V = svd.getV(null, false);
        DMatrixRMaj W1 = CommonOps_DDRM.identity(A.numRows);
        DMatrixRMaj T1 = CommonOps_DDRM.identity(A.numRows);
        double threshlod = 1e-6;
        double maxX1 = 0, maxB1 = 0;
        double maxX2 = 0, maxB2 = 0;
        int trancatedID = A.numRows;
        DMatrixRMaj tb1 = new DMatrixRMaj(A.numRows, 1);
        DMatrixRMaj tb2 = new DMatrixRMaj(A.numRows, 1);
        for (int t = 0; t < A.numRows; t++) {
            if (maxB1 < Math.abs(b1.get(t, 0))) {
                maxB1 = Math.abs(b1.get(t, 0));
            }
            if (maxB2 < Math.abs(b2.get(t, 0))) {
                maxB2 = Math.abs(b2.get(t, 0));
            }
            if (W.get(t, t) < threshlod) {
                W.set(t, t, 0);
            } else {
                W.set(t, t, 1 / W.get(t, t));
            }
        }
        double diffCutoff = (1E-5) * A.numRows;
        double diff1, diff2 = Double.MAX_VALUE;
        double minDiff1 = Integer.MAX_VALUE, minDiff2 = Integer.MAX_VALUE;
        int minDiffNum = trancatedID;
        DMatrixRMaj x1 = new DMatrixRMaj(A.numRows, 1);
        DMatrixRMaj x2 = new DMatrixRMaj(A.numRows, 1);
        maxB1 = maxB1 * 10;
        maxB2 = maxB2 * 10;
        trancatedID--;
        double sum = 0;
        boolean needContinue = true;
        do {

            CommonOps_DDRM.mult(V, W, T1);
            CommonOps_DDRM.mult(T1, U, W1);
            CommonOps_DDRM.mult(W1, b1, x1);

            maxX1 = 0;
            maxX2 = 0;
            for (int t = 0; t < A.numRows; t++) {
                if (maxX1 < Math.abs(x1.get(t, 0))) {
                    maxX1 = Math.abs(x1.get(t, 0));
                }
            }
            if (maxX1 <= maxB1) {
                CommonOps_DDRM.mult(W1, b2, x2);
                for (int t = 0; t < A.numRows; t++) {
                    if (maxX2 < Math.abs(x2.get(t, 0))) {
                        maxX2 = Math.abs(x2.get(t, 0));
                    }
                }
                if (maxX2 <= maxB2) {
                    CommonOps_DDRM.mult(A, x1, tb1);
                    CommonOps_DDRM.changeSign(tb1);
                    CommonOps_DDRM.add(b1, tb1, tb1);
                    diff1 = CommonOps_DDRM.elementSumAbs(tb1);

                    CommonOps_DDRM.mult(A, x2, tb2);
                    CommonOps_DDRM.changeSign(tb2);
                    CommonOps_DDRM.add(b2, tb2, tb2);
                    sum = CommonOps_DDRM.elementSum(x2);
                    if (sum >= 1) {
                        diff2 = CommonOps_DDRM.elementSumAbs(tb2);

                        /*
                     if (diff1 < minDiff1) {
                     minDiff1 = diff1;
                     for (int t = 0; t < A.numRows; t++) {
                     finalX1.set(t, 0, x1.get(t, 0));
                     finalX2.set(t, 0, x2.get(t, 0));
                     }
                     }
                         */
                        if (diff2 < minDiff2) {
                            minDiff2 = diff2;
                            for (int t = 0; t < A.numRows; t++) {
                                finalX1.set(t, 0, x1.get(t, 0));
                                finalX2.set(t, 0, x2.get(t, 0));
                            }
                            minDiffNum = trancatedID;
                        }
                    }
                    if (diff1 <= diffCutoff && diff2 <= diffCutoff) {
                        needContinue = false;
                        break;
                    }
                }
            }

            // W.set(trancatedID, trancatedID, W.get(trancatedID, trancatedID) / 1E6);
            // if (W.get(trancatedID, trancatedID) <= threshlod) 
            {
                W.set(trancatedID, trancatedID, 0);
                trancatedID--;
                if (trancatedID < 0) {
                    break;
                }
            }
        } while (needContinue);

    }

    public void mySudoSVDSolver(DMatrixRMaj A, DMatrixRMaj b1, DMatrixRMaj b2, DMatrixRMaj finalX1, DMatrixRMaj finalX2) throws Exception {
        SvdImplicitQrDecompose_DDRM svd = new SvdImplicitQrDecompose_DDRM(true, true, true, true);
        svd.decompose(A);
        DMatrixRMaj U = svd.getU(null, true);
        DMatrixRMaj W = svd.getW(null);
        // System.out.println(W.toString());
        DMatrixRMaj V = svd.getV(null, false);
        DMatrixRMaj W1 = CommonOps_DDRM.identity(A.numRows);
        DMatrixRMaj T1 = CommonOps_DDRM.identity(A.numRows);
        double threshlod = 1e-6;
        double maxX1 = 0, maxB1 = 0;
        double maxX2 = 0, maxB2 = 0;
        int trancatedID = A.numRows;
        DMatrixRMaj tb1 = new DMatrixRMaj(A.numRows, 1);
        DMatrixRMaj tb2 = new DMatrixRMaj(A.numRows, 1);
        for (int t = 0; t < A.numRows; t++) {
            if (maxB1 < Math.abs(b1.get(t, 0))) {
                maxB1 = Math.abs(b1.get(t, 0));
            }
            if (maxB2 < Math.abs(b2.get(t, 0))) {
                maxB2 = Math.abs(b2.get(t, 0));
            }
            if (W.get(t, t) < threshlod) {
                W.set(t, t, 0);
            } else {
                W.set(t, t, 1 / W.get(t, t));
            }
        }
        double minDiff = 1E-8 * A.numRows;
        maxB1 = maxB1 * 5;
        maxB2 = maxB2 * 5;
        trancatedID--;
        boolean needContinue = true;
        do {
            CommonOps_DDRM.mult(V, W, T1);
            CommonOps_DDRM.mult(T1, U, W1);
            CommonOps_DDRM.mult(W1, b1, finalX1);

            maxX1 = 0;
            maxX2 = 0;
            for (int t = 0; t < A.numRows; t++) {
                if (maxX1 < Math.abs(finalX1.get(t, 0))) {
                    maxX1 = Math.abs(finalX1.get(t, 0));
                }
            }
            if (maxX1 <= maxB1) {
                CommonOps_DDRM.mult(W1, b2, finalX2);
                for (int t = 0; t < A.numRows; t++) {
                    if (maxX2 < Math.abs(finalX2.get(t, 0))) {
                        maxX2 = Math.abs(finalX2.get(t, 0));
                    }
                }
                if (maxX2 <= maxB2) {
                    CommonOps_DDRM.mult(A, finalX1, tb1);
                    CommonOps_DDRM.changeSign(tb1);
                    CommonOps_DDRM.add(b1, tb1, tb1);
                    if (CommonOps_DDRM.elementSumAbs(tb1) < minDiff) {
                        CommonOps_DDRM.mult(A, finalX2, tb2);
                        CommonOps_DDRM.changeSign(tb2);
                        CommonOps_DDRM.add(b2, tb2, tb2);
                        if (CommonOps_DDRM.elementSumAbs(tb2) < minDiff) {
                            needContinue = false;
                            break;
                        }
                    }
                }
            }

            W.set(trancatedID, trancatedID, W.get(trancatedID, trancatedID) / 1E6);
            if (W.get(trancatedID, trancatedID) <= threshlod) {
                W.set(trancatedID, trancatedID, 0);
                trancatedID--;
                if (trancatedID < 0) {
                    break;
                }
            }
        } while (needContinue);

        /*
         System.out.println("x1 " + finalX1.toString());
         DMatrixRMaj finalB1 = new DMatrixRMaj(snpNum, 1);
         CommonOps_DDRM.mult(A, finalX1, finalB1);
         System.out.println("x1 " + finalB1.toString());
         */
    }

    public void mySudoSVDSolver(DMatrixRMaj A, DMatrixRMaj Ad, DMatrixRMaj b1, DMatrixRMaj b2, DMatrixRMaj finalX1, DMatrixRMaj finalX2) throws Exception {

        SvdImplicitQrDecompose_DDRM svd = new SvdImplicitQrDecompose_DDRM(true, true, true, true);
        svd.decompose(A);

        DMatrixRMaj U = svd.getU(null, true);
        DMatrixRMaj W = svd.getW(null);

        SvdImplicitQrDecompose_DDRM svdd = new SvdImplicitQrDecompose_DDRM(true, true, true, true);
        svd.decompose(A);

        DMatrixRMaj Ud = svdd.getU(null, true);
        DMatrixRMaj Wd = svdd.getW(null);

        // System.out.println(W.toString());
        DMatrixRMaj V = svd.getV(null, false);
        DMatrixRMaj W1 = CommonOps_DDRM.identity(A.numRows);
        DMatrixRMaj T1 = CommonOps_DDRM.identity(A.numRows);

        DMatrixRMaj Vd = svd.getV(null, false);
        DMatrixRMaj W1d = CommonOps_DDRM.identity(A.numRows);
        DMatrixRMaj T1d = CommonOps_DDRM.identity(A.numRows);
        double threshlod = 1e-6;
        double maxX1 = 0, maxB1 = 0;
        double maxX2 = 0, maxB2 = 0;
        int trancatedID = A.numRows;
        int trancatedIDd = A.numRows;
        DMatrixRMaj tb1 = new DMatrixRMaj(A.numRows, 1);
        DMatrixRMaj tb2 = new DMatrixRMaj(A.numRows, 1);
        for (int t = 0; t < A.numRows; t++) {
            if (maxB1 < Math.abs(b1.get(t, 0))) {
                maxB1 = Math.abs(b1.get(t, 0));
            }
            if (maxB2 < Math.abs(b2.get(t, 0))) {
                maxB2 = Math.abs(b2.get(t, 0));
            }
            if (W.get(t, t) < threshlod) {
                W.set(t, t, 0);
            } else {
                W.set(t, t, 1 / W.get(t, t));
            }

            if (Wd.get(t, t) < threshlod) {
                Wd.set(t, t, 0);
            } else {
                Wd.set(t, t, 1 / Wd.get(t, t));
            }
        }
        double minDiff = 0.000001 * A.numRows;
        maxB1 = maxB1 * 5;
        maxB2 = maxB2 * 5;
        trancatedID--;
        trancatedIDd--;
        boolean needContinue = true;
        do {
            CommonOps_DDRM.mult(V, W, T1);
            CommonOps_DDRM.mult(T1, U, W1);
            CommonOps_DDRM.mult(W1, b1, finalX1);

            maxX1 = 0;
            maxX2 = 0;
            for (int t = 0; t < A.numRows; t++) {
                if (maxX1 < Math.abs(finalX1.get(t, 0))) {
                    maxX1 = Math.abs(finalX1.get(t, 0));
                }
            }
            if (maxX1 <= maxB1) {
                CommonOps_DDRM.mult(Vd, Wd, T1d);
                CommonOps_DDRM.mult(T1d, Ud, W1d);
                CommonOps_DDRM.mult(W1d, b2, finalX2);
                for (int t = 0; t < A.numRows; t++) {
                    if (maxX2 < Math.abs(finalX2.get(t, 0))) {
                        maxX2 = Math.abs(finalX2.get(t, 0));
                    }
                }
                if (maxX2 <= maxB2) {
                    CommonOps_DDRM.mult(A, finalX1, tb1);
                    CommonOps_DDRM.changeSign(tb1);
                    CommonOps_DDRM.add(b1, tb1, tb1);
                    if (CommonOps_DDRM.elementSumAbs(tb1) < minDiff) {
                        CommonOps_DDRM.mult(Ad, finalX2, tb2);
                        CommonOps_DDRM.changeSign(tb2);
                        CommonOps_DDRM.add(b2, tb2, tb2);
                        if (CommonOps_DDRM.elementSumAbs(tb2) < minDiff) {
                            needContinue = false;
                            break;
                        }
                    }
                }
            }

            W.set(trancatedID, trancatedID, W.get(trancatedID, trancatedID) / 1E6);
            if (W.get(trancatedID, trancatedID) <= threshlod) {
                W.set(trancatedID, trancatedID, 0);
                trancatedID--;
                if (trancatedID < 0) {
                    break;
                }
            }

            Wd.set(trancatedIDd, trancatedIDd, Wd.get(trancatedIDd, trancatedIDd) / 1E6);
            if (W.get(trancatedIDd, trancatedIDd) <= threshlod) {
                W.set(trancatedIDd, trancatedIDd, 0);
                trancatedIDd--;
                if (trancatedIDd < 0) {
                    break;
                }
            }

        } while (needContinue);

        /*
         System.out.println("x1 " + finalX1.toString());
         DMatrixRMaj finalB1 = new DMatrixRMaj(snpNum, 1);
         CommonOps_DDRM.mult(A, finalX1, finalB1);
         System.out.println("x1 " + finalB1.toString());
         */
    }

    public double mySudoSVDSolver(DoubleMatrix2D A, double[] chisquares) throws Exception {
        cern.colt.matrix.linalg.SingularValueDecomposition svd = new cern.colt.matrix.linalg.SingularValueDecomposition(A);
        int size = A.columns();
        DoubleMatrix2D x1 = null;
        DoubleMatrix2D x2 = null;
        DoubleMatrix2D b1 = new DenseDoubleMatrix2D(size, 1);
        DoubleMatrix2D b2 = new DenseDoubleMatrix2D(size, 1);

        for (int i = 0; i < size; i++) {
            b1.set(i, 0, chisquares[i] * chisquares[i]);
            b2.set(i, 0, 1);
        }

        Algebra alg = new Algebra();
        DoubleMatrix2D U = alg.transpose(svd.getU());
        DoubleMatrix2D W = svd.getS();
        // System.out.println(W.toString());
        DoubleMatrix2D V = svd.getV();

        double threshlod = 1e-6;
        double maxX1 = 0, maxB1 = 0;
        double maxX2 = 0, maxB2 = 0;
        int trancatedID = size;

        DoubleMatrix2D W1 = null;
        DoubleMatrix2D tb1 = null;
        DoubleMatrix2D tb2 = null;
        for (int t = 0; t < size; t++) {
            if (maxB1 < Math.abs(b1.get(t, 0))) {
                maxB1 = Math.abs(b1.get(t, 0));
            }
            if (maxB2 < Math.abs(b2.get(t, 0))) {
                maxB2 = Math.abs(b2.get(t, 0));
            }
            if (W.get(t, t) < threshlod) {
                W.set(t, t, 0);
            } else {
                W.set(t, t, 1 / W.get(t, t));
            }
        }
        double minDiff = 0.001 * size;
        maxB1 = maxB1 * 5;
        maxB2 = maxB2 * 5;
        trancatedID--;
        boolean needContinue = true;
        double diff = 0;
        do {
            W1 = alg.mult(alg.mult(V, W), U);
            x1 = alg.mult(W1, b1);
            maxX1 = 0;
            maxX2 = 0;
            for (int t = 0; t < size; t++) {
                if (maxX1 < Math.abs(x1.get(t, 0))) {
                    maxX1 = Math.abs(x1.get(t, 0));
                }
            }
            if (maxX1 <= maxB1) {
                x2 = alg.mult(W1, b2);
                for (int t = 0; t < size; t++) {
                    if (maxX2 < Math.abs(x2.get(t, 0))) {
                        maxX2 = Math.abs(x2.get(t, 0));
                    }
                }
                if (maxX2 <= maxB2) {
                    tb1 = alg.mult(A, x1);
                    diff = 0;
                    for (int t = 0; t < size; t++) {
                        diff += Math.abs(tb1.getQuick(t, 0) - b1.getQuick(t, 0));
                    }
                    if (diff < minDiff) {
                        tb2 = alg.mult(A, x2);
                        diff = 0;
                        for (int t = 0; t < size; t++) {
                            diff += Math.abs(tb2.getQuick(t, 0) - b2.getQuick(t, 0));
                        }
                        if (diff < minDiff) {
                            needContinue = false;
                            break;
                        }
                    }
                }
            }
            W.set(trancatedID, trancatedID, W.get(trancatedID, trancatedID) / 2);
            if (W.get(trancatedID, trancatedID) <= threshlod) {
                W.set(trancatedID, trancatedID, 0);
                trancatedID--;
                if (trancatedID < 0) {
                    break;
                }
            }
        } while (needContinue);

        double df = 0;
        double Y = 0;
        for (int i = 0; i < size; i++) {
            Y += (x1.get(i, 0));
            df += (x2.get(i, 0));
        }
        if (Y <= 0 || df <= 0) {
            return 1;
        }
        if (df < 1) {
            df = 1;
        }
        double p1 = Gamma.incompleteGammaComplement(df / 2, Y / 2);
        if (p1 < 1E-8) {
            int sss = 0;
        }
        return p1;
    }

    public double combinePValuebyCorrectedChiFisherCombinationTestMXLiEJML(double[] pValueArray, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }

        double[] chisquares1 = new double[snpSize];
        for (int i = 0; i < snpSize; i++) {
            chisquares1[i] = pValueArray[i] / 2;
        }
        double[] chisquares = MultipleTestingMethod.zScores(chisquares1);

        DMatrixRMaj A = new DMatrixRMaj(snpSize, snpSize);
        DMatrixRMaj x1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj x2 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj b1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj b2 = new DMatrixRMaj(snpSize, 1);
        double c;
        for (int i = 0; i < snpSize; i++) {
            b1.set(i, 0, chisquares[i] * chisquares[i]);
            b2.set(i, 0, 1);
            A.set(i, i, 1);
            for (int j = i + 1; j < snpSize; j++) {
                double r = ldCorr.getQuick(i, j);

                /*
                 r = Math.abs(r);
                 //for R
                 c = (0.6065 * r - 1.033) * r + 1.7351;
                 if (c > 2) {
                 c = 2;
                 }*/
                r = r * r;
                /*
                //R2
                c = 1.2719 * Math.pow(r, -0.054);
                c = c / 2;
                if (c > 1) {
                    c = 1;
                }

                r = Math.pow(r, c);
                 */
                A.set(i, j, r);
                A.set(j, i, r);
            }
        }

        double df = 0;
        double Y = 0;

        mySudoSVDSolver(A, b1, b2, x1, x2);
        df = 0;
        Y = 0;
        for (int i = 0; i < snpSize; i++) {
            Y += (x1.get(i, 0));
            //  Y1 += chisquareArray[t][0];
            //   pValueArray[t].var *
            df += (x2.get(i, 0));
        }
        if (Y <= 0 || df <= 0) {
            return 1;
        }

        double p1 = Gamma.incompleteGammaComplement(df / 2, Y / 2);
        //  double p1 = Probability.chiSquareComplemented(df, Y);
        if (p1 < 1E-8) {
            int sss = 0;
        }
        return p1;

    }

    public double combinePValuebyCorrectedChiFisherCombinationTestMXLiEJMLCondition(double[] pValueArray, int cutIndex, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }

        double[] chisquares1 = new double[snpSize];
        for (int i = 0; i < snpSize; i++) {
            chisquares1[i] = pValueArray[i] / 2;
        }
        double[] chisquares = MultipleTestingMethod.zScores(chisquares1);

        DMatrixRMaj A = new DMatrixRMaj(snpSize, snpSize);
        DMatrixRMaj x1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj x2 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj b1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj b2 = new DMatrixRMaj(snpSize, 1);

        for (int i = 0; i < snpSize; i++) {
            b1.set(i, 0, chisquares[i] * chisquares[i]);
            b2.set(i, 0, 1);
            A.set(i, i, 1);
            for (int j = i + 1; j < snpSize; j++) {
                double r = ldCorr.getQuick(i, j);
                r = r * r;
                r = Math.pow(r, 0.75);
                A.set(i, j, r);
                A.set(j, i, r);
            }
        }

        mySudoSVDSolver(A, b1, b2, x1, x2);
        double df = 0;
        double Y = 0;
        for (int i = 0; i < snpSize; i++) {
            Y += (x1.get(i, 0));
            //  Y1 += chisquareArray[t][0];
            //   pValueArray[t].var *
            df += (x2.get(i, 0));
        }

        DMatrixRMaj As = new DMatrixRMaj(cutIndex, cutIndex);
        DMatrixRMaj x1s = new DMatrixRMaj(cutIndex, 1);
        DMatrixRMaj x2s = new DMatrixRMaj(cutIndex, 1);
        DMatrixRMaj b1s = new DMatrixRMaj(cutIndex, 1);
        DMatrixRMaj b2s = new DMatrixRMaj(cutIndex, 1);

        for (int i = 0; i < cutIndex; i++) {
            b1s.set(i, 0, chisquares[i] * chisquares[i]);
            b2s.set(i, 0, 1);
            As.set(i, i, 1);
            for (int j = i + 1; j < cutIndex; j++) {
                As.set(i, j, A.get(i, j));
                As.set(j, i, (A.get(i, j)));
            }
        }

        mySudoSVDSolver(As, b1s, b2s, x1s, x2s);
        double dfs = 0;
        double Ys = 0;
        for (int i = 0; i < cutIndex; i++) {
            Ys += (x1s.get(i, 0));
            //  Y1 += chisquareArray[t][0];
            //   pValueArray[t].var *
            dfs += (x2s.get(i, 0));
        }
        Y -= Ys;
        df -= dfs;
        if (Y < 0) {
            Y = 0;
        }
        if (df < 1) {
            df = 1;
        }
        double p1 = Probability.chiSquareComplemented(df, Y);
        if (p1 < 1E-8) {
            int sss = 0;
        }
        return p1;

    }

    public double combinePValuebyCorrectedChiFisherCombinationTestMXLiEJMLSubset(PValueWeight[] pValueArray, int startIndex, int endIndex, DoubleMatrix2D ldCorr, double[] re) throws Exception {
        int snpSize = endIndex - startIndex;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0].pValue;
        }

        double[] chisquares1 = new double[snpSize];
        for (int i = startIndex; i < endIndex; i++) {
            chisquares1[i - startIndex] = pValueArray[i].pValue / 2;
        }
        double[] chisquares = MultipleTestingMethod.zScores(chisquares1);

        DMatrixRMaj A = new DMatrixRMaj(snpSize, snpSize);
        DMatrixRMaj Ad = new DMatrixRMaj(snpSize, snpSize);
        DMatrixRMaj x1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj x2 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj b1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj b2 = new DMatrixRMaj(snpSize, 1);
        double c = 1, r;
        int adjIndivSize = 5000;
        for (int i = 0; i < snpSize; i++) {
            b1.set(i, 0, chisquares[i] * chisquares[i]);
            b2.set(i, 0, 1);
            A.set(i, i, 1);
            Ad.set(i, i, 1);
            for (int j = i + 1; j < snpSize; j++) {
                r = ldCorr.getQuick(pValueArray[i + startIndex].index, pValueArray[j + startIndex].index);
                r = r * r;
                //R2
                //johny's correction                
                // r = 1 - (adjIndivSize - 3.0) / (adjIndivSize - 2.0) * (1.0 - r) * (1 + 2.0 * (1 - r) / (adjIndivSize - 3.3));                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
                //if (r > 0) 
                {
                    //r2n=5
                    //y = 41.773x6 - 128.05x5 + 151.17x4 - 86.321x3 + 24.67x2 - 3.3787x + 0.9174
                    //c = (((((41.773 * r - 128.05) * r + 151.17) * r - 86.321) * r + 24.67) * r - 3.3787) * r + 0.9174;
                    //n=2
                    //y = -35.741x6 + 111.16x5 - 128.42x4 + 66.906x3 - 14.641x2 + 0.6075x + 0.8596
                    // c = (((((-35.741 * r + 111.16) * r - 128.42) * r + 66.906) * r - 14.641) * r + 0.6075) * r + 0.8596;
                    // c = 0.85;
                    r = Math.pow(r, c);
                }
                A.set(i, j, r);
                A.set(j, i, r);

                /*
                r = ldCorr.getQuick(j + startIndex, j + startIndex);
                r = Math.abs(r);
                //r=Math.sqrt(Math.abs(r));
                //c = 0.75;
                r = Math.pow(r, 2.1);
                Ad.set(j, j, r);
                Ad.set(j, j, r);
                 */
            }
        }
        // System.out.println(A.toString());
        mySudoSVDSolver(A, b1, b2, x1, x2);
        // mySudoSVDSolver(A, Ad, b1, b2, x1, x2);
        double df = 0;
        double Y = 0;
        for (int i = 0; i < snpSize; i++) {
            Y += (x1.get(i, 0));
            //  Y1 += chisquareArray[t][0];
            //   pValueArray[t].var *
            df += (x2.get(i, 0));
        }

        re[0] = df;
        re[1] = Y;

        if (Y < 0) {
            Y = 0;
        }

        // mySudoSVDSolverOverlappedWindow(10, A, b1, b2, re);
        //mySudoSVDSolverOverlappedWindow(6, A, b1, b2, re);
        double p1 = Gamma.incompleteGammaComplement(re[0] / 2, re[1] / 2);
        if (p1 < 1E-4) {
            int sss = 0;
        }

        return p1;

    }

    public double combinePValuebyCorrectedChiFisherCombinationTestMXLiEJMLSubset(RConnection rcon, double[] pValueArray,
            int startIndex, int endIndex, DoubleMatrix2D ldCorr, int ldSampleSize, double[] re) throws Exception {
        int snpSize = endIndex - startIndex;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }

        double[] chisquares1 = new double[snpSize];
        for (int i = startIndex; i < endIndex; i++) {
            chisquares1[i - startIndex] = pValueArray[i] / 2;
        }
        double[] chisquares = MultipleTestingMethod.zScores(chisquares1);

        DMatrixRMaj A = new DMatrixRMaj(snpSize, snpSize);
        DMatrixRMaj Ad = new DMatrixRMaj(snpSize, snpSize);
        DMatrixRMaj x1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj x2 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj b1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj b2 = new DMatrixRMaj(snpSize, 1);
        double r;
        int adjIndivSize = 5000;
        double[] arrayA = new double[snpSize * snpSize];
        double[] arrayB = new double[snpSize * 2];
        double[][] arrayAA = new double[snpSize][snpSize];
        double[][] arrayBB1 = new double[snpSize][1];
        double[][] arrayBB2 = new double[snpSize][1];
        double[][] arrayBB3 = new double[snpSize][2];
        double[] arrayW = new double[snpSize];
        DMatrixRMaj xx1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj xx2 = new DMatrixRMaj(snpSize, 1);

        DMatrixRMaj xx11 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj xx22 = new DMatrixRMaj(snpSize, 1);

        Arrays.fill(arrayW, 1);
        // arrayW[0] = 10;
        // arrayW[10] = 10;
        // arrayW[20] = 10;

        double c = 0.000002 * snpSize * snpSize - 0.0017 * snpSize + 1.5361;

        //double c = -0.084 * Math.log(snpSize) + 1.7423;
        c = 1.432;

        for (int i = 0; i < snpSize; i++) {
            b1.set(i, 0, chisquares[i] * chisquares[i]);
            b2.set(i, 0, 1);

            arrayB[i * 2] = chisquares[i] * chisquares[i];
            arrayB[i * 2 + 1] = 1;
            arrayA[i * snpSize + i] = 1;

            arrayAA[i][i] = 1;
            arrayBB1[i][0] = arrayB[i * 2];
            arrayBB2[i][0] = 1;

            arrayBB3[i][0] = arrayB[i * 2];
            arrayBB3[i][1] = 1;
        }
        double chi, c2;

        for (int i = 0; i < snpSize; i++) {
            A.set(i, i, 1);
            Ad.set(i, i, 1);
            for (int j = i + 1; j < snpSize; j++) {
                r = ldCorr.getQuick(i + startIndex, j + startIndex);
                r = Math.abs(r);

                r = Math.pow(r, c);

                A.set(i, j, r);
                A.set(j, i, r);
                arrayA[i * snpSize + j] = r;
                arrayA[j * snpSize + i] = r;
                /*
                r = ldCorr.getQuick(j + startIndex, j + startIndex);
                r = Math.abs(r);
                //r=Math.sqrt(Math.abs(r));
                //c = 0.75;
                r = Math.pow(r, 2.1);
                Ad.set(j, j, r);
                Ad.set(j, j, r);
                 */

                arrayAA[i][j] = r;
                arrayAA[j][i] = r;
            }
        }

        DoubleMatrix2D subCovMat = new DenseDoubleMatrix2D(arrayAA);

        //System.out.println(A.toString());
        boolean useR = true;

        if (useR) {
            double df1 = 0;
            double Y1 = 0;
            double total = 0;

            // nnlmSolver(rcon, arrayA, arrayB, xx1, xx2);
            myNNLMSolver(A, b1, b2, xx1, xx2);
            // eigenValueSolver(subCovMat, b1, b2, xx1, xx2);
            for (int i = 0; i < snpSize; i++) {
                Y1 += (xx1.get(i, 0));
                //  Y1 += chisquareArray[t][0];
                //   pValueArray[t].var *                               
                df1 += (xx2.get(i, 0));
                total += arrayB[i * 2];
                //  System.out.println(i + "\t" + pValueArray[i] + "\t" + arrayB[i * 2] + "\t" + xx2.get(i, 0) + "\t" + xx1.get(i, 0) + "\t" + Gamma.incompleteGammaComplement(xx2.get(i, 0) / 2, xx1.get(i, 0) / 2));
            }

            re[0] = df1;
            re[1] = Y1;

            // System.out.println(df1 + "\t" + Y1 + "\t");
            /*
            nnlmSolver(arrayAA, arrayBB1, arrayW, xx11);
            nnlmSolver(arrayAA, arrayBB2, arrayW, xx22);

            df1 = 0;
            Y1 = 0;
            total = 0;
            for (int j = 0; j < snpSize; j++) {
                Y1 += (xx11.get(j, 0));
                //  Y1 += chisquareArray[t][0];
                //   pValueArray[t].var *
                df1 += (xx22.get(j, 0));
                total += arrayB[j * 2];
                // System.out.println(j+ "\t" + pValueArray[j] + "\t" + arrayB[j * 2] + "\t" + xx22.get(j, 0) + "\t" + xx11.get(j, 0) + "\t" + Gamma.incompleteGammaComplement(xx22.get(j, 0) / 2, xx11.get(j, 0) / 2));
            }
            re[0] = df1;
            re[1] = Y1;
            System.out.print(df1 + "\t" + Y1+ "\t");
             */
 /*
      nnlmSolver(arrayAA, arrayBB3, arrayW, xx11, xx22);
      //nnlsSolver1(arrayAA, arrayBB3, arrayW, xx11, xx22);
      df1 = 0;
      Y1 = 0;
      total = 0;
      double df11 = 0;
      for (int j = 0; j < snpSize; j++) {
        Y1 += (xx11.get(j, 0));
        //  Y1 += chisquareArray[t][0];
        //   pValueArray[t].var *
        df1 += (xx22.get(j, 0));
        total += arrayB[j * 2];

        xx22.set(j, 0, xx11.get(j, 0) / arrayB[j * 2]);
        df11 += (xx22.get(j, 0));
      }

      for (int j = 0; j < snpSize; j++) {
        xx22.set(j, 0, df1 * xx22.get(j, 0) / df11);
        System.out.println(j + "\t" + pValueArray[j] + "\t" + arrayB[j * 2] + "\t" + xx22.get(j, 0) + "\t" + xx11.get(j, 0) + "\t" + Gamma.incompleteGammaComplement(xx22.get(j, 0) / 2, xx11.get(j, 0) / 2));
      }
      re[0] = df1;
      re[1] = Y1;
             */
            // System.out.println(df1 + "\t" + Y1);
            //System.out.println(xx1.toString());
            //System.out.println(xx11.toString());
            //System.out.println(df1 / snpSize + "\t" + Y1 / total + "\n");
            int sss = 0;
        } else {
            // System.out.println(A.toString());
            mySudoSVDSolver(A, b1, b2, x1, x2);
            // mySudoSVDSolver(A, Ad, b1, b2, x1, x2);
            double df = 0;
            double Y = 0;
            double total = 0;
            for (int i = 0; i < snpSize; i++) {
                Y += (x1.get(i, 0));
                //  Y1 += chisquareArray[t][0];
                //   pValueArray[t].var *
                df += (x2.get(i, 0));
                total += arrayB[i * 2];
            }

            re[0] = df;
            re[1] = Y;

            if (Y < 0) {
                Y = 0;
            }
            // System.out.println("\n" + df / snpSize + "\t" + Y / total + "\n");
            int sss = 0;
        }

        double p1 = Gamma.incompleteGammaComplement(re[0] / 2, re[1] / 2);
        if (p1 < 1E-4) {
            int sss = 0;
        }

        return p1;

    }

    public double combinePValuebyCorrectedChiFisherCombinationTestMXLiEJMLSubset(double[] pValueArray,
            int startIndex, int endIndex, DoubleMatrix2D ldCorr, int ldSampleSize, double[] re) throws Exception {
        int snpSize = endIndex - startIndex;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }

        double[] chisquares1 = new double[snpSize];
        for (int i = startIndex; i < endIndex; i++) {
            chisquares1[i - startIndex] = pValueArray[i] / 2;
        }
        double[] chisquares = MultipleTestingMethod.zScores(chisquares1);

        DMatrixRMaj A = new DMatrixRMaj(snpSize, snpSize);
        DMatrixRMaj Ad = new DMatrixRMaj(snpSize, snpSize);
        DMatrixRMaj x1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj x2 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj b1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj b2 = new DMatrixRMaj(snpSize, 1);
        double r;
        int adjIndivSize = 5000;
        double[] arrayA = new double[snpSize * snpSize];
        double[] arrayB = new double[snpSize * 2];
        double[][] arrayAA = new double[snpSize][snpSize];
        double[][] arrayBB1 = new double[snpSize][1];
        double[][] arrayBB2 = new double[snpSize][1];
        double[][] arrayBB3 = new double[snpSize][2];
        double[] arrayW = new double[snpSize];
        DMatrixRMaj xx1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj xx2 = new DMatrixRMaj(snpSize, 1);

        DMatrixRMaj xx11 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj xx22 = new DMatrixRMaj(snpSize, 1);

        Arrays.fill(arrayW, 1);
        // arrayW[0] = 10;
        // arrayW[10] = 10;
        // arrayW[20] = 10;

        double c = 0.000002 * snpSize * snpSize - 0.0017 * snpSize + 1.5361;

        //double c = -0.084 * Math.log(snpSize) + 1.7423;
        if (c < 1.2) {
            c = 1.2;
        }
        c = 1.432;

        for (int i = 0; i < snpSize; i++) {
            b1.set(i, 0, chisquares[i] * chisquares[i]);
            b2.set(i, 0, 1);

            arrayB[i * 2] = chisquares[i] * chisquares[i];
            arrayB[i * 2 + 1] = 1;
            arrayA[i * snpSize + i] = 1;

            arrayAA[i][i] = 1;
            arrayBB1[i][0] = arrayB[i * 2];
            arrayBB2[i][0] = 1;

            arrayBB3[i][0] = arrayB[i * 2];
            arrayBB3[i][1] = 1;
        }
        double chi, c2;

        for (int i = 0; i < snpSize; i++) {
            A.set(i, i, 1);
            Ad.set(i, i, 1);
            for (int j = i + 1; j < snpSize; j++) {
                r = ldCorr.getQuick(i + startIndex, j + startIndex);
                r = Math.abs(r);
                r = r * r;
                //3.8415
                chi = Math.min(b1.get(i, 0), b1.get(j, 0));
                //5.023886187
                if (chi > 17) {
                    c = Math.sqrt(2 * chi - 1);
                    c2 = 2 * r * (chi - 1) + 1;
                    if (c2 > 0) {
                        c = c / Math.sqrt(c2);
                        r = r * c;
                    }

                }
                // r A= Math.pow(r, c);
                //r = r * r;                
                // r = r - ((1 - r) / (ldSampleSize - 2));
//                if (r < 0) {
//                    r = 0;
//                }
                // r=Math.abs(r);
                //R2
                //johny's correction                
                // r = 1 - (adjIndivSize - 3.0) / (adjIndivSize - 2.0) * (1.0 - r) * (1 + 2.0 * (1 - r) / (adjIndivSize - 3.3));                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
                //if (r > 0) 
                {
                    //r2n=5
                    //y = 41.773x6 - 128.05x5 + 151.17x4 - 86.321x3 + 24.67x2 - 3.3787x + 0.9174
                    //c = (((((41.773 * r - 128.05) * r + 151.17) * r - 86.321) * r + 24.67) * r - 3.3787) * r + 0.9174;
                    //n=2
                    //y = -35.741x6 + 111.16x5 - 128.42x4 + 66.906x3 - 14.641x2 + 0.6075x + 0.8596
                    // c = (((((-35.741 * r + 111.16) * r - 128.42) * r + 66.906) * r - 14.641) * r + 0.6075) * r + 0.8596;
                    // c = 0.85;
                    // r = Math.pow(r, c);
                }
                A.set(i, j, r);
                A.set(j, i, r);
                arrayA[i * snpSize + j] = r;
                arrayA[j * snpSize + i] = r;
                /*
                r = ldCorr.getQuick(j + startIndex, j + startIndex);
                r = Math.abs(r);
                //r=Math.sqrt(Math.abs(r));
                //c = 0.75;
                r = Math.pow(r, 2.1);
                Ad.set(j, j, r);
                Ad.set(j, j, r);
                 */

                arrayAA[i][j] = r;
                arrayAA[j][i] = r;
            }
        }

        DoubleMatrix2D subCovMat = new DenseDoubleMatrix2D(arrayAA);

        //System.out.println(A.toString());
        boolean useR = true;

        if (useR) {
            double df1 = 0;
            double Y1 = 0;
            double total = 0;

            // nnlmSolver(rcon, arrayA, arrayB, xx1, xx2);
            myNNLMSolver(A, b1, b2, xx1, xx2);
            // eigenValueSolver(subCovMat, b1, b2, xx1, xx2);
            for (int i = 0; i < snpSize; i++) {
                Y1 += (xx1.get(i, 0));
                //  Y1 += chisquareArray[t][0];
                //   pValueArray[t].var *                               
                df1 += (xx2.get(i, 0));
                total += arrayB[i * 2];
                //  System.out.println(i + "\t" + pValueArray[i] + "\t" + arrayB[i * 2] + "\t" + xx2.get(i, 0) + "\t" + xx1.get(i, 0) + "\t" + Gamma.incompleteGammaComplement(xx2.get(i, 0) / 2, xx1.get(i, 0) / 2));
            }

            re[0] = df1;
            re[1] = Y1;

            // System.out.println(df1 + "\t" + Y1 + "\t");
            /*
            nnlmSolver(arrayAA, arrayBB1, arrayW, xx11);
            nnlmSolver(arrayAA, arrayBB2, arrayW, xx22);

            df1 = 0;
            Y1 = 0;
            total = 0;
            for (int j = 0; j < snpSize; j++) {
                Y1 += (xx11.get(j, 0));
                //  Y1 += chisquareArray[t][0];
                //   pValueArray[t].var *
                df1 += (xx22.get(j, 0));
                total += arrayB[j * 2];
                // System.out.println(j+ "\t" + pValueArray[j] + "\t" + arrayB[j * 2] + "\t" + xx22.get(j, 0) + "\t" + xx11.get(j, 0) + "\t" + Gamma.incompleteGammaComplement(xx22.get(j, 0) / 2, xx11.get(j, 0) / 2));
            }
            re[0] = df1;
            re[1] = Y1;
            System.out.print(df1 + "\t" + Y1+ "\t");
             */
 /*
      nnlmSolver(arrayAA, arrayBB3, arrayW, xx11, xx22);
      //nnlsSolver1(arrayAA, arrayBB3, arrayW, xx11, xx22);
      df1 = 0;
      Y1 = 0;
      total = 0;
      double df11 = 0;
      for (int j = 0; j < snpSize; j++) {
        Y1 += (xx11.get(j, 0));
        //  Y1 += chisquareArray[t][0];
        //   pValueArray[t].var *
        df1 += (xx22.get(j, 0));
        total += arrayB[j * 2];

        xx22.set(j, 0, xx11.get(j, 0) / arrayB[j * 2]);
        df11 += (xx22.get(j, 0));
      }

      for (int j = 0; j < snpSize; j++) {
        xx22.set(j, 0, df1 * xx22.get(j, 0) / df11);
        System.out.println(j + "\t" + pValueArray[j] + "\t" + arrayB[j * 2] + "\t" + xx22.get(j, 0) + "\t" + xx11.get(j, 0) + "\t" + Gamma.incompleteGammaComplement(xx22.get(j, 0) / 2, xx11.get(j, 0) / 2));
      }
      re[0] = df1;
      re[1] = Y1;
             */
            // System.out.println(df1 + "\t" + Y1);
            //System.out.println(xx1.toString());
            //System.out.println(xx11.toString());
            //System.out.println(df1 / snpSize + "\t" + Y1 / total + "\n");
            int sss = 0;
        } else {
            // System.out.println(A.toString());
            mySudoSVDSolver(A, b1, b2, x1, x2);
            // mySudoSVDSolver(A, Ad, b1, b2, x1, x2);
            double df = 0;
            double Y = 0;
            double total = 0;
            for (int i = 0; i < snpSize; i++) {
                Y += (x1.get(i, 0));
                //  Y1 += chisquareArray[t][0];
                //   pValueArray[t].var *
                df += (x2.get(i, 0));
                total += arrayB[i * 2];
            }

            re[0] = df;
            re[1] = Y;

            if (Y < 0) {
                Y = 0;
            }
            // System.out.println("\n" + df / snpSize + "\t" + Y / total + "\n");
            int sss = 0;
        }

        double p1 = Gamma.incompleteGammaComplement(re[0] / 2, re[1] / 2);
        if (p1 < 1E-4) {
            int sss = 0;
        }

        return p1;

    }

    public double combinePValuebyCorrectedChiHeritabilitySubset(double[] pValueArray,
            int startIndex, int endIndex, DoubleMatrix2D ldCorr, int ldSampleSize, double[] re) throws Exception {
        int snpSize = endIndex - startIndex;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }

        double[] chisquares1 = new double[snpSize];
        for (int i = startIndex; i < endIndex; i++) {
            chisquares1[i - startIndex] = pValueArray[i] / 2;
        }
        double[] chisquares = MultipleTestingMethod.zScores(chisquares1);

        DMatrixRMaj A = new DMatrixRMaj(snpSize, snpSize);
        DMatrixRMaj Ad = new DMatrixRMaj(snpSize, snpSize);
        DMatrixRMaj x1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj x2 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj b1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj b2 = new DMatrixRMaj(snpSize, 1);
        double r;
        int adjIndivSize = 5000;
        double[] arrayA = new double[snpSize * snpSize];
        double[] arrayB = new double[snpSize * 2];
        double[][] arrayAA = new double[snpSize][snpSize];
        double[][] arrayBB1 = new double[snpSize][1];
        double[][] arrayBB2 = new double[snpSize][1];
        double[][] arrayBB3 = new double[snpSize][2];
        double[] arrayW = new double[snpSize];
        DMatrixRMaj xx1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj xx2 = new DMatrixRMaj(snpSize, 1);

        DMatrixRMaj xx11 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj xx22 = new DMatrixRMaj(snpSize, 1);

        Arrays.fill(arrayW, 1);
        // arrayW[0] = 10;
        // arrayW[10] = 10;
        // arrayW[20] = 10;

        double c = 0.000002 * snpSize * snpSize - 0.0017 * snpSize + 1.5361;

        //double c = -0.084 * Math.log(snpSize) + 1.7423;
        if (c < 1.2) {
            c = 1.2;
        }
        c = 1.432;

        for (int i = 0; i < snpSize; i++) {
            b1.set(i, 0, chisquares[i] * chisquares[i]);
            b2.set(i, 0, 1);

            arrayB[i * 2] = chisquares[i] * chisquares[i];
            arrayB[i * 2 + 1] = 1;
            arrayA[i * snpSize + i] = 1;

            arrayAA[i][i] = 1;
            arrayBB1[i][0] = arrayB[i * 2];
            arrayBB2[i][0] = 1;

            arrayBB3[i][0] = arrayB[i * 2];
            arrayBB3[i][1] = 1;
        }
        double chi, c2;

        for (int i = 0; i < snpSize; i++) {
            A.set(i, i, 1);
            Ad.set(i, i, 1);
            for (int j = i + 1; j < snpSize; j++) {
                r = ldCorr.getQuick(i + startIndex, j + startIndex);
                r = Math.abs(r);
                r = r * r;
                //3.8415
                chi = Math.min(b1.get(i, 0), b1.get(j, 0)) - 2.7055;
                if (chi <= 0.5) {
                    c = 1;
                } else {
                    c = Math.sqrt(2 * chi - 1);
                    c2 = 2 * r * (chi - 1) + 1;
                    if (c2 > 0) {
                        c = c / Math.sqrt(c2);
                        r = r * c;
                    }
                }
                // r A= Math.pow(r, c);
                //r = r * r;                
                // r = r - ((1 - r) / (ldSampleSize - 2));
//                if (r < 0) {
//                    r = 0;
//                }
                // r=Math.abs(r);
                //R2
                //johny's correction                
                // r = 1 - (adjIndivSize - 3.0) / (adjIndivSize - 2.0) * (1.0 - r) * (1 + 2.0 * (1 - r) / (adjIndivSize - 3.3));                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
                //if (r > 0) 
                {
                    //r2n=5
                    //y = 41.773x6 - 128.05x5 + 151.17x4 - 86.321x3 + 24.67x2 - 3.3787x + 0.9174
                    //c = (((((41.773 * r - 128.05) * r + 151.17) * r - 86.321) * r + 24.67) * r - 3.3787) * r + 0.9174;
                    //n=2
                    //y = -35.741x6 + 111.16x5 - 128.42x4 + 66.906x3 - 14.641x2 + 0.6075x + 0.8596
                    // c = (((((-35.741 * r + 111.16) * r - 128.42) * r + 66.906) * r - 14.641) * r + 0.6075) * r + 0.8596;
                    // c = 0.85;
                    // r = Math.pow(r, c);
                }
                A.set(i, j, r);
                A.set(j, i, r);
                arrayA[i * snpSize + j] = r;
                arrayA[j * snpSize + i] = r;
                /*
                r = ldCorr.getQuick(j + startIndex, j + startIndex);
                r = Math.abs(r);
                //r=Math.sqrt(Math.abs(r));
                //c = 0.75;
                r = Math.pow(r, 2.1);
                Ad.set(j, j, r);
                Ad.set(j, j, r);
                 */

                arrayAA[i][j] = r;
                arrayAA[j][i] = r;
            }
        }

        DoubleMatrix2D subCovMat = new DenseDoubleMatrix2D(arrayAA);

        //System.out.println(A.toString());
        boolean useR = true;
        double df1 = 0;
        double Y1 = 0;
        if (useR) {

            // nnlmSolver(rcon, arrayA, arrayB, xx1, xx2);
            myNNLMSolver(A, b1, b2, xx1, xx2);
            // eigenValueSolver(subCovMat, b1, b2, xx1, xx2);
            for (int i = 0; i < snpSize; i++) {
                Y1 += (xx1.get(i, 0));
                //  Y1 += chisquareArray[t][0];
                //   pValueArray[t].var *                               
                df1 += (xx2.get(i, 0));
                // total += arrayB[i * 2];
                //  System.out.println(i + "\t" + pValueArray[i] + "\t" + arrayB[i * 2] + "\t" + xx2.get(i, 0) + "\t" + xx1.get(i, 0) + "\t" + Gamma.incompleteGammaComplement(xx2.get(i, 0) / 2, xx1.get(i, 0) / 2));
            }

            re[0] = df1;
            re[1] = Y1;
        } else {
            // System.out.println(A.toString());
            mySudoSVDSolver(A, b1, b2, x1, x2);
            // mySudoSVDSolver(A, Ad, b1, b2, x1, x2);
            double df = 0;
            double Y = 0;
            double total = 0;
            for (int i = 0; i < snpSize; i++) {
                Y += (x1.get(i, 0));
                //  Y1 += chisquareArray[t][0];
                //   pValueArray[t].var *
                df += (x2.get(i, 0));
                total += arrayB[i * 2];
            }

            re[0] = df;
            re[1] = Y;

            if (Y < 0) {
                Y = 0;
            }
            // System.out.println("\n" + df / snpSize + "\t" + Y / total + "\n");
            int sss = 0;
        }

        double p1 = Gamma.incompleteGammaComplement(df1 / 2, Y1 / 2);

        double heri = (Y1 - df1) / ldSampleSize;
        // se = (4 * re1[1] - 2) / n / n;
        double se1 = MultipleTestingMethod.zScore(p1 / 2);
        se1 = Math.abs(heri / se1);
        re[0] = heri;
        re[1] = se1;
        return p1;

    }

    public void myNNLMSolver(DMatrixRMaj A, DMatrixRMaj b1, DMatrixRMaj b2, DMatrixRMaj finalX1, DMatrixRMaj finalX2) throws Exception {
        int n = b1.numRows;
        NNLMSolverJavaTask task = new NNLMSolverJavaTask(A, b1, b2, 0, n);
        task.call();
        DMatrixRMaj finalX1tmp = task.getFinalX1();
        DMatrixRMaj finalX2tmp = task.getFinalX2();
        for (int i = 0; i < n; i++) {
            finalX1.set(i, 0, finalX1tmp.get(i, 0));
            finalX2.set(i, 0, finalX2tmp.get(i, 0));
        }

    }

    class twovalue {

        double a;
        int b;
    }

    class CmpTwoValue implements Comparator<twovalue> {

        public int compare(twovalue e1, twovalue e2) {
            if (e1.a < e2.a)//�����Ƚ��ǽ���,�����-1�ĳ�1��������.
            {
                return 1;
            } else if (e1.a > e2.a) {
                return -1;
            } else {
                return 0;
            }
        }
    }

    void sortbyone(double[] a, int[] b) {
        List<twovalue> c = new LinkedList<twovalue>();
        for (int i = 0; i < a.length; i++) {
            twovalue t = new twovalue();
            t.a = a[i];
            t.b = b[i];
            c.add(t);
        }
        Collections.sort(c, new CmpTwoValue());
        for (int i = 0; i < a.length; i++) {
            a[i] = c.get(i).a;
            b[i] = c.get(i).b;
        }
    }

    public void eigenValueSolver(DoubleMatrix2D A, DMatrixRMaj b1, DMatrixRMaj b2, DMatrixRMaj finalX1, DMatrixRMaj finalX2) throws Exception {
        int n = b1.numRows;
        EffectiveNumberEstimator estimator = new EffectiveNumberEstimator();
        double[] values = new double[n];
        System.arraycopy(b1.data, 0, values, 0, n);
        int[] indexSorted = new int[n];
        for (int i = 0; i < indexSorted.length; i++) {
            indexSorted[i] = i;
        }
        sortbyone(values, indexSorted);
        double[] effIndexes = estimator.calculateEffectiveIndexesDiff(A, indexSorted);
        double sum = 0;
        //we must use R not R2 does not work for alternative hypothesis for condtional test
        for (int i = 0; i < indexSorted.length; i++) {
            values[i] = values[i] * effIndexes[i] * effIndexes[i];
            sum += values[i];
            finalX1.set(i, 0, values[i]);
            finalX2.set(i, 0, effIndexes[i]);
        }

    }

    public double combinePValuebyCorrectedChiFisherCombinationTestMXLiEJMLSubset(RConnection rcon, double[] pValueArray, int startIndex,
            int endIndex, DoubleMatrix2D ldCorr, double[] re, boolean useR2, boolean useZ) throws Exception {
        int snpSize = endIndex - startIndex;
        if (snpSize == 0) {
            return -1;
        }

        double[] chisquares1 = new double[snpSize];
        for (int i = startIndex; i < endIndex; i++) {
            chisquares1[i - startIndex] = pValueArray[i] / 2;
        }
        double[] chisquares = MultipleTestingMethod.zScores(chisquares1);
        if (snpSize == 1) {
            re[0] = 1;
            if (useZ) {
                re[1] = chisquares[0];
            } else {
                re[1] = chisquares[0] * chisquares[0];
            }
            return pValueArray[0];
        }
        DMatrixRMaj A = new DMatrixRMaj(snpSize, snpSize);
        DMatrixRMaj Ad = new DMatrixRMaj(snpSize, snpSize);
        DMatrixRMaj x1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj x2 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj b1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj b2 = new DMatrixRMaj(snpSize, 1);
        double c = 1, r;
        int adjIndivSize = 5000;
        double[] arrayA = new double[snpSize * snpSize];
        double[] arrayB = new double[snpSize * 2];
        double[][] arrayAA = new double[snpSize][snpSize];
        double[][] arrayBB1 = new double[snpSize][1];
        double[][] arrayBB2 = new double[snpSize][1];
        double[][] arrayBB3 = new double[snpSize][2];
        double[] arrayW = new double[snpSize];
        DMatrixRMaj xx1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj xx2 = new DMatrixRMaj(snpSize, 1);

        DMatrixRMaj xx11 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj xx22 = new DMatrixRMaj(snpSize, 1);

        Arrays.fill(arrayW, 1);
        // arrayW[0] = 10;
        // arrayW[10] = 10;
        // arrayW[20] = 10;
        for (int i = 0; i < snpSize; i++) {
            if (useZ) {
                b1.set(i, 0, chisquares[i]);
            } else {
                b1.set(i, 0, chisquares[i] * chisquares[i]);
            }
            b2.set(i, 0, 1);
            A.set(i, i, 1);
            Ad.set(i, i, 1);
            if (useZ) {
                arrayB[i * 2] = chisquares[i];
            } else {
                arrayB[i * 2] = chisquares[i] * chisquares[i];
            }
            arrayB[i * 2 + 1] = 1;
            arrayA[i * snpSize + i] = 1;

            arrayAA[i][i] = 1;
            arrayBB1[i][0] = arrayB[i * 2];
            arrayBB2[i][0] = 1;

            arrayBB3[i][0] = arrayB[i * 2];
            arrayBB3[i][1] = 1;

            for (int j = i + 1; j < snpSize; j++) {
                r = ldCorr.getQuick(i + startIndex, j + startIndex);
                if (useR2) {
                    // r = r * r * r * r * r * r * r * r * r * r;
                    r = r * r;

                } else {
                    r = Math.abs(r);
                }
                //R2
                //johny's correction                
                // r = 1 - (adjIndivSize - 3.0) / (adjIndivSize - 2.0) * (1.0 - r) * (1 + 2.0 * (1 - r) / (adjIndivSize - 3.3));                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
                //if (r > 0) 
                {
                    //r2n=5
                    //y = 41.773x6 - 128.05x5 + 151.17x4 - 86.321x3 + 24.67x2 - 3.3787x + 0.9174
                    //c = (((((41.773 * r - 128.05) * r + 151.17) * r - 86.321) * r + 24.67) * r - 3.3787) * r + 0.9174;
                    //n=2
                    //y = -35.741x6 + 111.16x5 - 128.42x4 + 66.906x3 - 14.641x2 + 0.6075x + 0.8596
                    // c = (((((-35.741 * r + 111.16) * r - 128.42) * r + 66.906) * r - 14.641) * r + 0.6075) * r + 0.8596;
                    // c = 0.85;
                    // r = Math.pow(r, c);
                }
                A.set(i, j, r);
                A.set(j, i, r);
                arrayA[i * snpSize + j] = r;
                arrayA[j * snpSize + i] = r;
                /*
                r = ldCorr.getQuick(j + startIndex, j + startIndex);
                r = Math.abs(r);
                //r=Math.sqrt(Math.abs(r));
                //c = 0.75;
                r = Math.pow(r, 2.1);
                Ad.set(j, j, r);
                Ad.set(j, j, r);
                 */

                arrayAA[i][j] = r;
                arrayAA[j][i] = r;
            }
        }

        //System.out.println(A.toString());
        boolean useR = true;

        if (useR) {
            double df1 = 0;
            double Y1 = 0;
            double total = 0;

            nnlmSolver(rcon, arrayA, arrayB, xx1, xx2);
            for (int i = 0; i < snpSize; i++) {
                Y1 += (xx1.get(i, 0));
                //  Y1 += chisquareArray[t][0];
                //   pValueArray[t].var *                               
                df1 += (xx2.get(i, 0));
                total += arrayB[i * 2];
                //System.out.println(i + "\t" + pValueArray[i] + "\t" + arrayB[i * 2] + "\t" + xx2.get(i, 0) + "\t" + xx1.get(i, 0) + "\t" + Gamma.incompleteGammaComplement(xx2.get(i, 0) / 2, xx1.get(i, 0) / 2));
            }

            re[0] = df1;
            re[1] = Y1;

            // System.out.println(df1 + "\t" + Y1 + "\t");
            /*
            nnlmSolver(arrayAA, arrayBB1, arrayW, xx11);
            nnlmSolver(arrayAA, arrayBB2, arrayW, xx22);

            df1 = 0;
            Y1 = 0;
            total = 0;
            for (int j = 0; j < snpSize; j++) {
                Y1 += (xx11.get(j, 0));
                //  Y1 += chisquareArray[t][0];
                //   pValueArray[t].var *
                df1 += (xx22.get(j, 0));
                total += arrayB[j * 2];
                // System.out.println(j+ "\t" + pValueArray[j] + "\t" + arrayB[j * 2] + "\t" + xx22.get(j, 0) + "\t" + xx11.get(j, 0) + "\t" + Gamma.incompleteGammaComplement(xx22.get(j, 0) / 2, xx11.get(j, 0) / 2));
            }
            re[0] = df1;
            re[1] = Y1;
            System.out.print(df1 + "\t" + Y1+ "\t");
             */
 /*
      nnlmSolver(arrayAA, arrayBB3, arrayW, xx11, xx22);
      //nnlsSolver1(arrayAA, arrayBB3, arrayW, xx11, xx22);
      df1 = 0;
      Y1 = 0;
      total = 0;
      double df11 = 0;
      for (int j = 0; j < snpSize; j++) {
        Y1 += (xx11.get(j, 0));
        //  Y1 += chisquareArray[t][0];
        //   pValueArray[t].var *
        df1 += (xx22.get(j, 0));
        total += arrayB[j * 2];

        xx22.set(j, 0, xx11.get(j, 0) / arrayB[j * 2]);
        df11 += (xx22.get(j, 0));
      }

      for (int j = 0; j < snpSize; j++) {
        xx22.set(j, 0, df1 * xx22.get(j, 0) / df11);
        System.out.println(j + "\t" + pValueArray[j] + "\t" + arrayB[j * 2] + "\t" + xx22.get(j, 0) + "\t" + xx11.get(j, 0) + "\t" + Gamma.incompleteGammaComplement(xx22.get(j, 0) / 2, xx11.get(j, 0) / 2));
      }
      re[0] = df1;
      re[1] = Y1;
             */
            // System.out.println(df1 + "\t" + Y1);
            //System.out.println(xx1.toString());
            //System.out.println(xx11.toString());
            //System.out.println(df1 / snpSize + "\t" + Y1 / total + "\n");
            int sss = 0;
        } else {
            // System.out.println(A.toString());
            mySudoSVDSolver(A, b1, b2, x1, x2);
            // mySudoSVDSolver(A, Ad, b1, b2, x1, x2);
            double df = 0;
            double Y = 0;
            double total = 0;
            for (int i = 0; i < snpSize; i++) {
                Y += (x1.get(i, 0));
                //  Y1 += chisquareArray[t][0];
                //   pValueArray[t].var *
                df += (x2.get(i, 0));
                total += arrayB[i * 2];
            }

            re[0] = df;
            re[1] = Y;

            if (Y < 0) {
                Y = 0;
            }
            // System.out.println("\n" + df / snpSize + "\t" + Y / total + "\n");
            int sss = 0;
        }

        double p1 = Gamma.incompleteGammaComplement(re[0] / 2, re[1] / 2);
        if (p1 < 1E-4) {
            int sss = 0;
        }

        return p1;

    }

    public double reduceRedundantChiByECS(RConnection rcon, DoubleMatrix2D ldCorr, PValueWeight[] keyVars, PValueWeight[] pValueArray) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return -1;
        }

        int subSize = keyVars.length + 1;
        double r;
        PValueWeight pw;
        double[] arrayA = new double[subSize * subSize];
        double[] arrayB = new double[subSize * 2];
        int lessSubSize = subSize - 1;
        double[] arrayA0 = new double[lessSubSize * lessSubSize];
        double[] arrayB0 = new double[lessSubSize * 2];
        DMatrixRMaj A0 = new DMatrixRMaj(lessSubSize, lessSubSize);
        DMatrixRMaj b10 = new DMatrixRMaj(lessSubSize, 1);
        DMatrixRMaj b20 = new DMatrixRMaj(lessSubSize, 1);

        DMatrixRMaj A = new DMatrixRMaj(subSize, subSize);
        DMatrixRMaj b1 = new DMatrixRMaj(subSize, 1);
        DMatrixRMaj b2 = new DMatrixRMaj(subSize, 1);

        for (int i = 0; i < lessSubSize; i++) {
            keyVars[i].chi = MultipleTestingMethod.zScore(keyVars[i].pValue / 2);
            keyVars[i].chi = keyVars[i].chi * keyVars[i].chi;
            arrayB[i * 2] = keyVars[i].chi;
            arrayB[i * 2 + 1] = 1;
            arrayA[i * subSize + i] = 1;

            arrayB0[i * 2] = keyVars[i].chi;
            arrayB0[i * 2 + 1] = 1;
            arrayA0[i * lessSubSize + i] = 1;
            A0.set(i, i, 1);
            b10.set(i, 0, keyVars[i].chi);
            b20.set(i, 0, 1);

            A.set(i, i, 1);
            b1.set(i, 0, keyVars[i].chi);
            b2.set(i, 0, 1);

            for (int j = i + 1; j < lessSubSize; j++) {
                r = ldCorr.getQuick(keyVars[i].index, keyVars[j].index);
                r = Math.abs(r);
                //r = Math.pow(r, 0.25);
                arrayA[i * subSize + j] = r;
                arrayA[j * subSize + i] = r;
                arrayA0[i * lessSubSize + j] = r;
                arrayA0[j * lessSubSize + i] = r;
                A0.set(i, j, r);
                A0.set(j, i, r);
                A.set(i, j, r);
                A.set(j, i, r);
            }
        }
        arrayA[lessSubSize * subSize + lessSubSize] = 1;
        arrayB[subSize * 2 - 1] = 1;

        A.set(lessSubSize, lessSubSize, 1);
        b2.set(lessSubSize, 0, 1);

        DMatrixRMaj xx10 = new DMatrixRMaj(lessSubSize, 1);
        DMatrixRMaj xx20 = new DMatrixRMaj(lessSubSize, 1);

        boolean useR = true;
        double Y0 = 0, df0 = 0;

        if (useR) {
            nnlmSolver(rcon, arrayA0, arrayB0, xx10, xx20);
            // nnlsSolver(rcon, arrayA0, arrayB0, xx10, xx20);
        } else {
            mySudoSVDSolver(A0, b10, b20, xx10, xx20);
        }
        for (int j = 0; j < lessSubSize; j++) {
            Y0 += (xx10.get(j, 0));
            //  Y1 += chisquareArray[t][0];
            //   pValueArray[t].chi *                               
            df0 += (xx20.get(j, 0));
            // System.out.println(j + "\t" + pValueArray[j] + "\t" + arrayB[j * 2] + "\t" + xx2.get(j, 0) + "\t" + xx1.get(j, 0) + "\t" + Gamma.incompleteGammaComplement(xx2.get(j, 0) / 2, xx1.get(j, 0) / 2));
        }

        DMatrixRMaj xx1 = new DMatrixRMaj(subSize, 1);
        DMatrixRMaj xx2 = new DMatrixRMaj(subSize, 1);

        double Y1, df1;
        for (int i = 0; i < snpSize; i++) {
            pw = pValueArray[i];
            pw.chi = MultipleTestingMethod.zScore(pw.pValue / 2);
            pw.chi = pw.chi * pw.chi;
            for (int j = 0; j < lessSubSize; j++) {
                r = ldCorr.getQuick(keyVars[j].index, pw.index);
                r = Math.abs(r);
                //r = Math.pow(r, 0.25);
                arrayA[j * subSize + lessSubSize] = r;
                arrayA[lessSubSize * subSize + j] = r;

                A.set(j, lessSubSize, r);
                A.set(lessSubSize, j, r);
            }

            arrayB[subSize * 2 - 2] = pw.chi;
            b1.set(lessSubSize, 0, pw.chi);

            if (useR) {
                nnlmSolver(rcon, arrayA, arrayB, xx1, xx2);
                //nnlsSolver(rcon, arrayA, arrayB, xx1, xx2);
            } else {
                mySudoSVDSolver(A, b1, b2, xx1, xx2);
            }
            Y1 = 0;
            df1 = 0;
            for (int j = 0; j < subSize; j++) {
                Y1 += (xx1.get(j, 0));
                //  Y1 += chisquareArray[t][0];
                //   pValueArray[t].chi *                               
                df1 += (xx2.get(j, 0));
                // System.out.println(j + "\t" + pValueArray[j] + "\t" + arrayB[j * 2] + "\t" + xx2.get(j, 0) + "\t" + xx1.get(j, 0) + "\t" + Gamma.incompleteGammaComplement(xx2.get(j, 0) / 2, xx1.get(j, 0) / 2));
            }
            Y1 -= Y0;
            df1 -= df0;
            /*
                                                          Estimate Std. Error t value Pr(>|t|)    
(Intercept)                                         0.027658   0.007975   3.468 0.000624 ***
polym(EffDF, RemainChi, degree = 2, raw = TRUE)1.0  1.248952   0.182342   6.849 6.48e-11 ***
polym(EffDF, RemainChi, degree = 2, raw = TRUE)2.0  0.009192   0.146540   0.063 0.950038    
polym(EffDF, RemainChi, degree = 2, raw = TRUE)0.1 -0.265742   0.060076  -4.423 1.49e-05 ***
polym(EffDF, RemainChi, degree = 2, raw = TRUE)1.1 -0.334783   0.208860  -1.603 0.110305    
polym(EffDF, RemainChi, degree = 2, raw = TRUE)0.2  0.280378   0.105773   2.651 0.008580 ** 
      
             */

            //double fitd = 0.027658 + 1.248952 * df1 + 0.009192 * df1 * df1 - 0.265742 * Y1 - 0.334783 * df1 * Y1 + 0.280378 * Y1 * Y1;
            // double fitd = 0.004709 - 0.083871 * df1 - 0.00664 * Y0 + 0.041063 * Y1 + 0.023685 * Y0 * Y1 - 0.042551 * df1 * Y0 + 0.98947 * df1 * Y1;
            if (Y1 > 0) {
                int sss = 0;
            }
            //double p1 = Gamma.incompleteGammaComplement(fitd / 2, Y1 / 2);
            double p1 = Gamma.incompleteGammaComplement(df1 / 2, Y1 / 2);
            // if (p1 > pw.pValue) 
            {
                pw.pValue = p1;
                pw.chi = MultipleTestingMethod.zScore(pw.pValue / 2);
                pw.chi = pw.chi * pw.chi;
            }
        }
        return 1;
    }

    public double effectiveChiSquare(RConnection rcon, double[] pValueArray, IntArrayList varIndexes,
            DoubleMatrix2D ldCorr, boolean useR2, int ldSampleSize, double[] re) throws Exception {
        int snpSize = varIndexes.size();
        if (snpSize == 0) {
            return 0;
        }
        double[] chisquares1 = new double[snpSize];

        for (int i = 0; i < snpSize; i++) {
            chisquares1[i] = pValueArray[varIndexes.getQuick(i)] / 2;
        }

        double[] chisquares = MultipleTestingMethod.zScores(chisquares1);
        if (snpSize == 1) {
            re[0] = 1;
            re[1] = chisquares[0] * chisquares[0];
            return pValueArray[varIndexes.getQuick(0)];
        }
        DMatrixRMaj A = new DMatrixRMaj(snpSize, snpSize);
        DMatrixRMaj b1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj b2 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj Ad = new DMatrixRMaj(snpSize, snpSize);
        DMatrixRMaj x1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj x2 = new DMatrixRMaj(snpSize, 1);

        double c = 1, r;
        int adjIndivSize = 5000;
        double[] arrayA = new double[snpSize * snpSize];
        double[] arrayB = new double[snpSize * 2];
        double[][] arrayAA = new double[snpSize][snpSize];
        double[][] arrayBB1 = new double[snpSize][1];
        double[][] arrayBB2 = new double[snpSize][1];
        double[][] arrayBB3 = new double[snpSize][2];
        double[] arrayW = new double[snpSize];
        DMatrixRMaj xx1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj xx2 = new DMatrixRMaj(snpSize, 1);

        DMatrixRMaj xx11 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj xx22 = new DMatrixRMaj(snpSize, 1);

        Arrays.fill(arrayW, 1);
        // arrayW[0] = 10;
        // arrayW[10] = 10;
        // arrayW[20] = 10;
        for (int i = 0; i < snpSize; i++) {
            b1.set(i, 0, chisquares[i] * chisquares[i]);
            b2.set(i, 0, 1);
            A.set(i, i, 1);
            Ad.set(i, i, 1);

            arrayB[i * 2] = chisquares[i] * chisquares[i];
            arrayB[i * 2 + 1] = 1;
            arrayA[i * snpSize + i] = 1;

            arrayAA[i][i] = 1;
            arrayBB1[i][0] = arrayB[i * 2];
            arrayBB2[i][0] = 1;

            arrayBB3[i][0] = arrayB[i * 2];
            arrayBB3[i][1] = 1;

            for (int j = i + 1; j < snpSize; j++) {
                r = ldCorr.getQuick(varIndexes.getQuick(i), varIndexes.getQuick(j));
                if (useR2) {
                    r = r * r;
                    r = r - ((1 - r) / (ldSampleSize - 2));
                    if (r < 0) {
                        r = 0;
                    }
                } else {
                    r = Math.abs(r);
                }

                A.set(i, j, r);
                A.set(j, i, r);
                arrayA[i * snpSize + j] = r;
                arrayA[j * snpSize + i] = r;

                arrayAA[i][j] = r;
                arrayAA[j][i] = r;
            }
        }

        // System.out.println(A.toString());
        boolean useR = true;

        if (useR) {
            double df1 = 0;
            double Y1 = 0;
            double total = 0;

            nnlmSolver(rcon, arrayA, arrayB, xx1, xx2);

            for (int i = 0; i < snpSize; i++) {
                Y1 += (xx1.get(i, 0));
                //  Y1 += chisquareArray[t][0];
                //   pValueArray[t].var *                               
                df1 += (xx2.get(i, 0));
                total += arrayB[i * 2];
                // System.out.println(j + "\t" + pValueArray[j] + "\t" + arrayB[j * 2] + "\t" + xx2.get(j, 0) + "\t" + xx1.get(j, 0) + "\t" + Gamma.incompleteGammaComplement(xx2.get(j, 0) / 2, xx1.get(j, 0) / 2));
            }

            re[0] = df1;
            re[1] = Y1;

            /*
             nnlsSolver(rcon, arrayA, arrayB, xx11, xx22);
            df1 = 0;
            Y1 = 0;
            for (int i = 0; i < snpSize; i++) {
                Y1 += (xx11.get(i, 0));
                //  Y1 += chisquareArray[t][0];
                //   pValueArray[t].var *                               
                df1 += (xx22.get(i, 0));
                 
                // System.out.println(j + "\t" + pValueArray[j] + "\t" + arrayB[j * 2] + "\t" + xx2.get(j, 0) + "\t" + xx1.get(j, 0) + "\t" + Gamma.incompleteGammaComplement(xx2.get(j, 0) / 2, xx1.get(j, 0) / 2));
            }
             System.out.print(df1 + "\t" + Y1 + "\t");
             */
        } else {
            // System.out.println(A.toString());
            mySudoSVDSolver(A, b1, b2, x1, x2);
            // mySudoSVDSolver(A, Ad, b1, b2, x1, x2);
            double df = 0;
            double Y = 0;
            double total = 0;
            for (int i = 0; i < snpSize; i++) {
                Y += (x1.get(i, 0));
                //  Y1 += chisquareArray[t][0];
                //   pValueArray[t].var *
                df += (x2.get(i, 0));
                total += arrayB[i * 2];
            }

            re[0] = df;
            re[1] = Y;

            if (Y < 0) {
                Y = 0;
            }
            // System.out.println("\n" + df / snpSize + "\t" + Y / total + "\n");
            int sss = 0;
        }

        double p1 = Gamma.incompleteGammaComplement(re[0] / 2, re[1] / 2);
        if (p1 < 1E-4) {
            int sss = 0;
        }

        return p1;
    }

    public double combinePValuebyCorrectedChiFisherCombinationTestMXLiEJMLSubsetSplit(RConnection rcon, double[] pValueArray, int startIndex, int endIndex,
            DoubleMatrix2D ldCorr, double pCut, int ldSampleSize, double[] re) throws Exception {
        int snpSize = endIndex - startIndex;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }

        IntArrayList sigVarIndexes = new IntArrayList();
        IntArrayList insigVarIndexes = new IntArrayList();
        for (int i = startIndex; i < endIndex; i++) {
            if (pValueArray[i] < pCut) {
                sigVarIndexes.add(i);
            } else {
                insigVarIndexes.add(i);
            }
        }
        double[] sigResult = new double[2];
        Arrays.fill(sigResult, 0);
        effectiveChiSquare(rcon, pValueArray, sigVarIndexes, ldCorr, false, ldSampleSize, sigResult);
        double[] ingsigResult = new double[2];
        Arrays.fill(ingsigResult, 0);
        effectiveChiSquare(rcon, pValueArray, insigVarIndexes, ldCorr, true, ldSampleSize, ingsigResult);

        re[0] = (sigResult[0] + ingsigResult[0]);
        re[1] = (sigResult[1] + ingsigResult[1]);
        double p1 = Gamma.incompleteGammaComplement(re[0] / 2, re[1] / 2);
        if (p1 < 1E-4) {
            int sss = 0;
        }

        return p1;
    }

    public double combinePValuebyCorrectedChiFisherCombinationTestMXLiEJMLSubset(double[] pValueArray, int startIndex,
            int endIndex, DoubleMatrix2D ldCorr, double[] re) throws Exception {
        int snpSize = endIndex - startIndex;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }

        double[] chisquares1 = new double[snpSize];
        for (int i = startIndex; i < endIndex; i++) {
            chisquares1[i - startIndex] = pValueArray[i] / 2;
        }
        double[] chisquares = MultipleTestingMethod.zScores(chisquares1);

        DMatrixRMaj A = new DMatrixRMaj(snpSize, snpSize);
        DMatrixRMaj Ad = new DMatrixRMaj(snpSize, snpSize);
        DMatrixRMaj x1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj x2 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj b1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj b2 = new DMatrixRMaj(snpSize, 1);
        double c = 1, r;
        int adjIndivSize = 5000;
        double[] arrayA = new double[snpSize * snpSize];
        double[] arrayB = new double[snpSize * 2];
        DMatrixRMaj xx1 = new DMatrixRMaj(snpSize, 1);
        DMatrixRMaj xx2 = new DMatrixRMaj(snpSize, 1);

        for (int i = 0; i < snpSize; i++) {
            b1.set(i, 0, chisquares[i] * chisquares[i]);
            b2.set(i, 0, 1);
            A.set(i, i, 1);
            Ad.set(i, i, 1);

            arrayB[i * 2] = chisquares[i] * chisquares[i];
            arrayB[i * 2 + 1] = 1;
            arrayA[i * snpSize + i] = 1;

            for (int j = i + 1; j < snpSize; j++) {
                r = ldCorr.getQuick(i + startIndex, j + startIndex);
                // r = r * r;
                r = Math.abs(r);
                //R2
                //johny's correction                
                // r = 1 - (adjIndivSize - 3.0) / (adjIndivSize - 2.0) * (1.0 - r) * (1 + 2.0 * (1 - r) / (adjIndivSize - 3.3));                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
                //if (r > 0) 
                {
                    //r2n=5
                    //y = 41.773x6 - 128.05x5 + 151.17x4 - 86.321x3 + 24.67x2 - 3.3787x + 0.9174
                    //c = (((((41.773 * r - 128.05) * r + 151.17) * r - 86.321) * r + 24.67) * r - 3.3787) * r + 0.9174;
                    //n=2
                    //y = -35.741x6 + 111.16x5 - 128.42x4 + 66.906x3 - 14.641x2 + 0.6075x + 0.8596
                    // c = (((((-35.741 * r + 111.16) * r - 128.42) * r + 66.906) * r - 14.641) * r + 0.6075) * r + 0.8596;
                    // c = 0.85;
                    // r = Math.pow(r, c);
                }
                A.set(i, j, r);
                A.set(j, i, r);
                arrayA[i * snpSize + j] = r;
                arrayA[j * snpSize + i] = r;
                /*
                r = ldCorr.getQuick(j + startIndex, j + startIndex);
                r = Math.abs(r);
                //r=Math.sqrt(Math.abs(r));
                //c = 0.75;
                r = Math.pow(r, 2.1);
                Ad.set(j, j, r);
                Ad.set(j, j, r);
                 */
            }
        }
        // System.out.println(A.toString());
        mySudoSVDSolver(A, b1, b2, x1, x2);

        // mySudoSVDSolver(A, Ad, b1, b2, x1, x2);
        double df = 0;
        double Y = 0;
        for (int i = 0; i < snpSize; i++) {
            Y += (x1.get(i, 0));
            //  Y1 += chisquareArray[t][0];
            //   pValueArray[t].var *
            df += (x2.get(i, 0));
        }

        re[0] = df;
        re[1] = Y;

        if (Y < 0) {
            Y = 0;
        }
        //double xx1= Probability.chiSquareComplemented(10, 10);
        //double xx2= Gamma.incompleteGammaComplement(10/2, 10/2);

        // mySudoSVDSolverOverlappedWindow(10, A, b1, b2, re);
        //mySudoSVDSolverOverlappedWindow(6, A, b1, b2, re);
        double p1 = Gamma.incompleteGammaComplement(re[0] / 2, re[1] / 2);
        if (p1 < 1E-4) {
            int sss = 0;
        }

        return p1;

    }

    public static int[] partitionEvenBlock(int startIndex, int endIndex, int intervalLen) {
        int totalSnpSize = endIndex - startIndex;
        int blockNum = totalSnpSize / intervalLen;
        if (blockNum <= 1) {
            int[] bigBlockIndexes = new int[2];
            bigBlockIndexes[0] = startIndex;
            bigBlockIndexes[1] = endIndex;
            return bigBlockIndexes;
        }

        int[] bigBlockIndexes = new int[blockNum + blockNum + 1];
        bigBlockIndexes[0] = startIndex;
        blockNum++;
        for (int i = 1; i < blockNum; i++) {
            bigBlockIndexes[i * 2] = startIndex + i * intervalLen;
            bigBlockIndexes[i * 2 - 1] = (bigBlockIndexes[i * 2] + bigBlockIndexes[i * 2 - 2]) / 2;
        }
        blockNum--;
        if (bigBlockIndexes[blockNum * 2] < endIndex) {
            bigBlockIndexes[blockNum * 2] = endIndex;
            bigBlockIndexes[blockNum * 2 - 1] = (bigBlockIndexes[blockNum * 2] + bigBlockIndexes[blockNum * 2 - 2]) / 2;
        }
        return bigBlockIndexes;
    }

    public void mySudoSVDSolverOverlappedWindow(int superBlockLen, DMatrixRMaj A, DMatrixRMaj b1, DMatrixRMaj b2, double[] results) throws Exception {

        int n = A.numCols;
        int[] bigBlockIndexes = partitionEvenBlock(0, n, superBlockLen);

        int blockNum = bigBlockIndexes.length - 2;
        System.out.println(A.toString());
        double df = 0, dft = 0, Y = 0, Yt = 0;
        int blockLen = 0;
        if (blockNum == 0) {
            DMatrixRMaj x1 = new DMatrixRMaj(n, 1);
            DMatrixRMaj x2 = new DMatrixRMaj(n, 1);
            mySudoSVDSolver(A, b1, b2, x1, x2);

            Y = CommonOps_DDRM.elementSum(x1);
            df = CommonOps_DDRM.elementSum(x2);

            if (Y < 0) {
                Y = 0;
            }
            if (df < 0) {
                df = 0.001;
            }
            results[0] = df;
            results[1] = Y;
            return;
        }
        for (int i = 0; i < blockNum; i++) {
            blockLen = bigBlockIndexes[i + 2] - bigBlockIndexes[i];
            DMatrixRMaj sA = CommonOps_DDRM.extract(A, bigBlockIndexes[i], bigBlockIndexes[i + 2], bigBlockIndexes[i], bigBlockIndexes[i + 2]);
            DMatrixRMaj sb1 = CommonOps_DDRM.extract(b1, bigBlockIndexes[i], bigBlockIndexes[i + 2], 0, 1);
            DMatrixRMaj sb2 = CommonOps_DDRM.extract(b2, bigBlockIndexes[i], bigBlockIndexes[i + 2], 0, 1);
            DMatrixRMaj x1 = new DMatrixRMaj(blockLen, 1);
            DMatrixRMaj x2 = new DMatrixRMaj(blockLen, 1);
            mySudoSVDSolver(sA, sb1, sb2, x1, x2);

            Y = CommonOps_DDRM.elementSum(x1);
            df = CommonOps_DDRM.elementSum(x2);

            if (Y < 0) {
                Y = 0;
            }
            if (df < 0) {
                df = 0.001;
            }
            dft += df;
            Yt += Y;
        }
        int overlappedNum = bigBlockIndexes.length - 2;
        for (int i = 1; i < overlappedNum; i++) {
            blockLen = bigBlockIndexes[i + 1] - bigBlockIndexes[i];
            DMatrixRMaj sA = CommonOps_DDRM.extract(A, bigBlockIndexes[i], bigBlockIndexes[i + 1], bigBlockIndexes[i], bigBlockIndexes[i + 1]);
            DMatrixRMaj sb1 = CommonOps_DDRM.extract(b1, bigBlockIndexes[i], bigBlockIndexes[i + 1], 0, 1);
            DMatrixRMaj sb2 = CommonOps_DDRM.extract(b2, bigBlockIndexes[i], bigBlockIndexes[i + 1], 0, 1);
            DMatrixRMaj x1 = new DMatrixRMaj(blockLen, 1);
            DMatrixRMaj x2 = new DMatrixRMaj(blockLen, 1);
            mySudoSVDSolver(sA, sb1, sb2, x1, x2);

            Y = CommonOps_DDRM.elementSum(x1);
            df = CommonOps_DDRM.elementSum(x2);
            if (Y < 0) {
                Y = 0;
            }
            if (df < 0) {
                df = 0.001;
            }
            dft -= df;
            Yt -= Y;
        }
        results[0] = dft;
        results[1] = Yt;
    }

    public double combinePValuebyCorrectedChiFisherCombinationTestMXLiS(double[] pValueArray, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }

        double[] chisquares1 = new double[snpSize];
        for (int i = 0; i < snpSize; i++) {
            chisquares1[i] = pValueArray[i] / 2;
        }
        double[] chisquares = MultipleTestingMethod.zScores(chisquares1);
        double[] dfs = new double[snpSize];
        for (int i = 0; i < snpSize; i++) {
            chisquares[i] = chisquares[i] * chisquares[i];
            chisquares1[i] = chisquares[i];
            dfs[i] = 1;
        }
        double r;

        double df1 = 0;
        double Y1 = 0;
        for (int t = 0; t < snpSize; t++) {
            for (int k = t + 1; k < snpSize; k++) {
                r = ldCorr.getQuick(t, k);
                r = r * r;
                r = Math.pow(r, 0.75);
                chisquares[k] -= (chisquares[t] * r);
                dfs[k] -= (dfs[t] * r);
            }
        }

        for (int i = 0; i < snpSize; i++) {
            Y1 += chisquares[i];
            df1 += dfs[i];
        }

        if (Y1 <= 0 || df1 <= 0) {
            return 1;
        }

        //calcualte the scalled chi 
        // p1 = Probability.chiSquareComplemented((df1 + df2) / 2, (Y1 + Y2) / 2);
        double p1 = Probability.chiSquareComplemented(df1, Y1);
        if (p1 < 0.0) {
            p1 = 0.0;
        }

        return p1;
    }

    public double combinePValuebyCorrectedChiFisherCombinationTestJohnnyDf(double[] pValueArray, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }

        double[] chisquares1 = new double[snpSize];
        for (int i = 0; i < snpSize; i++) {
            chisquares1[i] = pValueArray[i] / 2;
        }
        double[] chisquares = MultipleTestingMethod.zScores(chisquares1);
        double[][] chisquareArray = new double[snpSize][1];
        for (int i = 0; i < snpSize; i++) {
            chisquareArray[i][0] = chisquares[i] * chisquares[i];
        }

        DoubleMatrix2D chisequreMat = new DenseDoubleMatrix2D(chisquareArray);
        Algebra alg = new Algebra();
        DoubleMatrix2D inv = alg.inverse(ldCorr);
        DoubleMatrix2D indChisequreMat = alg.mult(inv, chisequreMat);
        for (int i = 0; i < snpSize; i++) {
            chisequreMat.setQuick(i, 0, 1);
        }
        double df = 0;
        double Y = 0;
        for (int i = 0; i < snpSize; i++) {
            Y += indChisequreMat.getQuick(0, i);
        }

        df = 0;
        for (int i = 0; i < snpSize; i++) {
            for (int j = i + 1; j < snpSize; j++) {
                df += ldCorr.getQuick(i, j);
            }
        }
        df += df;
        df += snpSize;
        df = snpSize * snpSize / df;

        //calcualte the scalled chi 
        double p = Probability.chiSquareComplemented(df, Y);
        if (p < 0.0) {
            p = 0.0;
        }
        return p;
    }

    public double combinePValuebyCorrectedChiFisherCombinationTestJohnnyAll(double[] pValueArray, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }

        double[] chisquares1 = new double[snpSize];
        for (int i = 0; i < snpSize; i++) {
            chisquares1[i] = pValueArray[i] / 2;
        }
        double[] chisquares = MultipleTestingMethod.zScores(chisquares1);
        double df = 0;
        double Y = 0;
        for (int i = 0; i < snpSize; i++) {
            Y += chisquares[i] * chisquares[i];
        }

        df = 0;
        for (int i = 0; i < snpSize; i++) {
            for (int j = i + 1; j < snpSize; j++) {
                df += ldCorr.getQuick(i, j);
            }
        }
        df += df;
        df += snpSize;
        Y /= df;
        Y *= snpSize;
        df = snpSize * snpSize / df;

        //calcualte the scalled chi 
        double p = Probability.chiSquareComplemented(df, Y);
        if (p < 0.0) {
            p = 0.0;
        }
        return p;
    }

    public double combinePValuebyCorrectedChiFisherCombinationTestWeightJohnnyAll(PValueWeight[] pValueArray, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0].pValue;
        }

        double[] chisquares1 = new double[snpSize];
        for (int i = 0; i < snpSize; i++) {
            chisquares1[i] = pValueArray[i].pValue / 2;
        }
        double[] chisquares = MultipleTestingMethod.zScores(chisquares1);
        double df = 0;
        double Y = 0;
        double allWeight = 0;
        for (int i = 0; i < snpSize; i++) {
            Y += (pValueArray[i].var * chisquares[i] * chisquares[i]);
            allWeight += pValueArray[i].var;
        }

        df = 0;
        for (int i = 0; i < snpSize; i++) {
            df += (pValueArray[i].var * pValueArray[i].var);
            for (int j = i + 1; j < snpSize; j++) {
                df += (2 * pValueArray[i].var * pValueArray[j].var * ldCorr.getQuick(i, j));
            }
        }
        Y /= df;
        Y *= allWeight;
        df = allWeight * allWeight / df;

        //calcualte the scalled chi 
        double p = Probability.chiSquareComplemented(df, Y);
        if (p < 0.0) {
            p = 0.0;
        }
        return p;
    }

    public double combinePValuebyScaleedFisherCombinationTestCovLogP(PValueWeight[] pValueArray, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0].pValue;
        }
        DoubleMatrix2D covLogP = new DenseDoubleMatrix2D(snpSize, snpSize);
        for (int i = 0; i < snpSize; i++) {
            for (int j = i + 1; j < snpSize; j++) {
                if (i == j) {
                    continue;
                }
                double x = ldCorr.getQuick(pValueArray[i].index, pValueArray[j].index);

                //for r
                //y = 0.0079x3 + 3.9459x2 - 0.0024x ; y = 0.0331x3 + 3.9551x2 - 0.0156x
                //x = 0.0331 * (Math.pow(x1, 3)) + 3.9551 * (Math.pow(x1, 2)) - 0.0156 * x1;
                if (x < 0) {
                    x = -x;
                }
                // x1 = (0.75 * x1 + 3.25) * x1;

                //for r2                          
                //the new approximation
                // x1 = 8.595 * x1 * x1;
                //the formular I used in KGG
                if (x > 0.5) {
                    x = 0.75 * x + 3.25 * Math.sqrt(x);
                } else {
                    x = 8.6 * x;
                    //  x1 = 0.75 * x1 + 3.25 * Math.sqrt(x1);
                }

                covLogP.setQuick(i, j, x);
            }
        }

        double Y = 0;
        for (int i = 0; i < snpSize; i++) {
            Y += (-2 * Math.log(pValueArray[i].pValue) * pValueArray[i].var);
        }
        /*
        
         //calcualte the scalled chi
         double varTD = 4 * snpSize;
         for (int j = 0; j < snpSize; j++) {
         for (int j = j + 1; j < snpSize; j++) {
         varTD += 2 * covLogP.get(j, j);
         }
         }
         double c = varTD / (4 * snpSize);
         double f = 8 * snpSize * snpSize / varTD;
         double p1 = Probability.chiSquareComplemented(f, Y1 / c);
         */
        double sumWeight = 0;
        double sumWeight2 = 0;
        double sumCov = 0;
        for (int i = 0; i < snpSize; i++) {
            sumWeight += pValueArray[i].var;
        }
        //http://www.sciencedirect.com/science/article/pii/S016771520500009X 
        //A simple approximation for the distribution of the weighted combination of non-independent or independent probabilities Chia-Ding Hou

        for (int i = 0; i < snpSize; i++) {
            sumWeight2 += pValueArray[i].var * pValueArray[i].var;
        }

        for (int i = 0; i < snpSize; i++) {
            for (int j = i + 1; j < snpSize; j++) {
                sumCov += covLogP.get(i, j) * pValueArray[i].var * pValueArray[j].var;
            }
        }

        double c = (sumWeight2 + sumCov / 2) / sumWeight;
        double f = 4 * sumWeight * sumWeight / (2 * sumWeight2 + sumCov);
        double p = Probability.chiSquareComplemented(f, Y / c);
        if (p < 0.0) {
            p = 0.0;
        }
        return p;
    }

    public double combinePValuebyScaleedFisherCombinationTestCovLogPChisquare(PValueWeight[] pValueArray, DoubleMatrix2D ldCorr, double scale) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0].pValue;
        }

        DoubleMatrix2D covLogP = new DenseDoubleMatrix2D(snpSize, snpSize);
        for (int i = 0; i < snpSize; i++) {
            for (int j = i + 1; j < snpSize; j++) {
                if (i == j) {
                    continue;
                }
                double x = ldCorr.getQuick(pValueArray[i].index, pValueArray[j].index);

                //for r
                //y = 0.0079x3 + 3.9459x2 - 0.0024x ; y = 0.0331x3 + 3.9551x2 - 0.0156x
                //x = 0.0331 * (Math.pow(x1, 3)) + 3.9551 * (Math.pow(x1, 2)) - 0.0156 * x1;
                /*
                 if (x1 < 0) {
                 x1 = -x1;
                 }
                 x1 = (0.75 * x1 + 3.25) * x1;
                 * 
                 */
                //for r2
                x = x * x;
                x = 3.9471 * x;
                // x1 = 4 * x1;
                covLogP.setQuick(i, j, x);
            }
        }

        double Y = 0;
        for (int i = 0; i < snpSize; i++) {
            Y += (-2 * Math.log(pValueArray[i].pValue) * pValueArray[i].var);
        }
        /*
        
         //calcualte the scalled chi
         double varTD = 4 * snpSize;
         for (int j = 0; j < snpSize; j++) {
         for (int j = j + 1; j < snpSize; j++) {
         varTD += 2 * covLogP.get(j, j);
         }
         }
         double c = varTD / (4 * snpSize);
         double f = 8 * snpSize * snpSize / varTD;
         double p1 = Probability.chiSquareComplemented(f, Y1 / c);
         */
        double sumWeight = 0;
        double sumWeight2 = 0;
        double sumCov = 0;
        for (int i = 0; i < snpSize; i++) {
            sumWeight += pValueArray[i].var;
        }
        //http://www.sciencedirect.com/science/article/pii/S016771520500009X A simple approximation for the distribution of the weighted combination of non-independent or independent probabilities Chia-Ding Hou

        for (int i = 0; i < snpSize; i++) {
            sumWeight2 += pValueArray[i].var * pValueArray[i].var;
        }

        for (int i = 0; i < snpSize; i++) {
            for (int j = i + 1; j < snpSize; j++) {
                sumCov += covLogP.get(i, j) * pValueArray[i].var * pValueArray[j].var;
            }
        }

        double c = (sumWeight2 + sumCov / 2) / sumWeight;
        double f = 4 * sumWeight * sumWeight / (2 * sumWeight2 + sumCov);
        // Probability.chiSquareComplemented(f, Y1 / c);
        double chi = Math.pow(Y / c / f, 1 / scale) - (1 - 2 / (scale * scale * f));
        chi = scale * chi / Math.sqrt(2 / f);

        return chi;
    }

    public double combinePValuebyFisherCombinationTestChisquare(double[] pValueArray) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return -1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }

        double Y = 0;
        for (int i = 0; i < snpSize; i++) {
            double p = pValueArray[i];
            Y += (-2 * Math.log(p));
        }
        return Y;
    }

    public double combinePValuebyBonferroniCombinationTest(double[] pValueArray) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return 1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }

        double p = pValueArray[0];
        for (int i = 1; i < snpSize; i++) {
            if (pValueArray[i] < p) {
                p = pValueArray[i];
            }
        }
        return p * snpSize;
    }

    public double combinePValuebySidakCombinationTest(double[] pValueArray, double effectiveSampleSize) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return 1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }

        double p = pValueArray[0];
        for (int i = 1; i < snpSize; i++) {
            if (pValueArray[i] < p) {
                p = pValueArray[i];
            }
        }
        p = 1 - (Math.pow(1.0 - p, effectiveSampleSize));
        return p;
    }

    public double combinePValuebySidakCombinationTest(double[] pValueArray) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return 1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }

        double p = pValueArray[0];
        for (int i = 1; i < snpSize; i++) {
            if (pValueArray[i] < p) {
                p = pValueArray[i];
            }
        }
        p = 1 - (Math.pow(1.0 - p, snpSize));
        return p;
    }

    public double combinePValuebyWeightedSimeCombinationTest(PValueWeight[] pValueArray) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return 1;
        } else if (snpSize == 1) {
            return pValueArray[0].pValue;
        }
        Arrays.sort(pValueArray, new PValueWeightPComparator());
        double accumulatedWeight = pValueArray[0].var;
        double minP = snpSize * pValueArray[0].pValue / accumulatedWeight;
        double p;

        for (int i = 1; i < snpSize; i++) {
            accumulatedWeight += pValueArray[i].var;
            p = (snpSize * pValueArray[i].pValue / accumulatedWeight);
            if (p < minP) {
                minP = p;
            }
        }
        return minP;
    }

    public double combinePValuebySimeCombinationTest(double[] pValueArray) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return 1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }
        Arrays.sort(pValueArray);

        double minP = snpSize * pValueArray[0];
        double p;

        for (int i = 1; i < snpSize; i++) {
            p = snpSize * pValueArray[i] / (i + 1);
            if (p < minP) {
                minP = p;
            }
        }
        return minP;
    }

    public double combinePValuebyBiNormalTest(double[] pValueArray, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return 1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }
        Arrays.sort(pValueArray);

        //note only valid for 2 SNPs
        BiNormalDist bionrmal = new BiNormalDist(ldCorr.getQuick(0, 1));
        //two-tails
        double q1 = Probability.normalInverse(pValueArray[0] / 2);
        double q2 = Probability.normalInverse(pValueArray[1] / 2);
        q2 = q1;
        double p = bionrmal.cdf(q1, q2, -q1, -q2);

        return (1 - p);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PValuesAnalyzer pa = new PValuesAnalyzer();
        try {
            int lociNum = 3;

            double[][] ldr2 = new double[][]{{1, 0.110236, 0.055118, 0.200787, 0.728346, 0.507874, 0.311024, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {
                0.110236, 1, 0, 0, 0.110236, 0, 0.098425, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {
                0.055118, 0, 1, 0, 0.055118, 0, 0.051181, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {
                0.200787, 0, 0, 1, 0.200787, 0.094488, 0.732283, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {
                0.728346, 0.110236, 0.055118, 0.200787, 1, 0.507874, 0.80315, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {
                0.507874, 0, 0, 0.094488, 0.507874, 1, 0.437008, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {
                0.311024, 0.098425, 0.051181, 0.732283, 0.80315, 0.437008, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {
                0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0.011811, 0, 0, 0, 0, 0, 0, 0.011811, 0, 0, 0, 0, 0, 0, 0.007874}, {
                0, 0, 0, 0, 0, 0, 0, 0, 1, 0.059055, 0.059055, 0, 0, 0, 0.051181, 0, 0.047244, 0.047244, 0, 0, 0, 0, 0, 0.047244, 0.047244, 0.047244, 0.047244, 0.035433, 0.03937, 0}, {
                0, 0, 0, 0, 0, 0, 0, 0, 0.059055, 1, 0.055118, 0, 0, 0, 0.047244, 0, 0.043307, 0.043307, 0, 0, 0, 0, 0, 0.043307, 0.043307, 0.043307, 0.043307, 0.035433, 0.035433, 0}, {
                0, 0, 0, 0, 0, 0, 0, 0, 0.059055, 0.055118, 1, 0, 0, 0, 0.051181, 0, 0.043307, 0.047244, 0, 0, 0, 0, 0, 0.043307, 0.047244, 0.043307, 0.043307, 0.035433, 0.03937, 0}, {
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0.007874, 0.011811, 0, 0.015748, 0, 0, 0.011811, 0.011811, 0.011811, 0.011811, 0.015748, 0, 0, 0, 0, 0.007874, 0, 0.011811}, {
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.007874, 1, 0, 0, 0.007874, 0, 0, 0, 0, 0, 0, 0.007874, 0, 0, 0, 0, 0, 0, 0}, {
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.011811, 0, 1, 0, 0.007874, 0, 0, 0, 0, 0, 0, 0.007874, 0, 0, 0, 0, 0, 0, 0.007874}, {
                0, 0, 0, 0, 0, 0, 0, 0, 0.051181, 0.047244, 0.051181, 0, 0, 0, 1, 0, 0.055118, 0.059055, 0, 0, 0, 0, 0, 0.051181, 0.055118, 0.051181, 0.051181, 0.043307, 0.043307, 0}, {
                0, 0, 0, 0, 0, 0, 0, 0.011811, 0, 0, 0, 0.015748, 0.007874, 0.007874, 0, 1, 0, 0, 0.007874, 0.007874, 0.007874, 0.007874, 0.011811, 0, 0, 0, 0, 0, 0, 0.011811}, {
                0, 0, 0, 0, 0, 0, 0, 0, 0.047244, 0.043307, 0.043307, 0, 0, 0, 0.055118, 0, 1, 0.055118, 0, 0, 0, 0, 0, 0.051181, 0.051181, 0.051181, 0.051181, 0.03937, 0.03937, 0}, {
                0, 0, 0, 0, 0, 0, 0, 0, 0.047244, 0.043307, 0.047244, 0, 0, 0, 0.059055, 0, 0.055118, 1, 0, 0, 0, 0, 0, 0.051181, 0.055118, 0.051181, 0.051181, 0.043307, 0.043307, 0}, {
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.011811, 0, 0, 0, 0.007874, 0, 0, 1, 0, 0, 0, 0.007874, 0, 0, 0, 0, 0, 0, 0}, {
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.011811, 0, 0, 0, 0.007874, 0, 0, 0, 1, 0, 0, 0.007874, 0, 0, 0, 0, 0, 0, 0}, {
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.011811, 0, 0, 0, 0.007874, 0, 0, 0, 0, 1, 0, 0.007874, 0, 0, 0, 0, 0, 0, 0}, {
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.011811, 0, 0, 0, 0.007874, 0, 0, 0, 0, 0, 1, 0.007874, 0, 0, 0, 0, 0, 0, 0}, {
                0, 0, 0, 0, 0, 0, 0, 0.011811, 0, 0, 0, 0.015748, 0.007874, 0.007874, 0, 0.011811, 0, 0, 0.007874, 0.007874, 0.007874, 0.007874, 1, 0, 0, 0, 0, 0, 0, 0.011811}, {
                0, 0, 0, 0, 0, 0, 0, 0, 0.047244, 0.043307, 0.043307, 0, 0, 0, 0.051181, 0, 0.051181, 0.051181, 0, 0, 0, 0, 0, 1, 0.059055, 0.055118, 0.055118, 0.047244, 0.047244, 0}, {
                0, 0, 0, 0, 0, 0, 0, 0, 0.047244, 0.043307, 0.047244, 0, 0, 0, 0.055118, 0, 0.051181, 0.055118, 0, 0, 0, 0, 0, 0.059055, 1, 0.059055, 0.059055, 0.051181, 0.051181, 0}, {
                0, 0, 0, 0, 0, 0, 0, 0, 0.047244, 0.043307, 0.043307, 0, 0, 0, 0.051181, 0, 0.051181, 0.051181, 0, 0, 0, 0, 0, 0.055118, 0.059055, 1, 0.059055, 0.047244, 0.047244, 0}, {
                0, 0, 0, 0, 0, 0, 0, 0, 0.047244, 0.043307, 0.043307, 0, 0, 0, 0.051181, 0, 0.051181, 0.051181, 0, 0, 0, 0, 0, 0.055118, 0.059055, 0.059055, 1, 0.047244, 0.047244, 0}, {
                0, 0, 0, 0, 0, 0, 0, 0, 0.035433, 0.035433, 0.035433, 0.007874, 0, 0, 0.043307, 0, 0.03937, 0.043307, 0, 0, 0, 0, 0, 0.047244, 0.051181, 0.047244, 0.047244, 1, 0.043307, 0}, {
                0, 0, 0, 0, 0, 0, 0, 0, 0.03937, 0.035433, 0.03937, 0, 0, 0, 0.043307, 0, 0.03937, 0.043307, 0, 0, 0, 0, 0, 0.047244, 0.051181, 0.047244, 0.047244, 0.043307, 1, 0}, {
                0, 0, 0, 0, 0, 0, 0, 0.007874, 0, 0, 0, 0.011811, 0, 0.007874, 0, 0.011811, 0, 0, 0, 0, 0, 0, 0.011811, 0, 0, 0, 0, 0, 0, 1}
            };
            DoubleMatrix2D ldCorr = new DenseDoubleMatrix2D(ldr2);

            double[] pvalues = new double[]{0.124844607, 0.110661309, 0.822461041, 0.127453284, 0.417854711, 0.868397721, 0.067436906, 0.020542319, 0.009341871, 0.015883614, 0.012985321, 0.025744335, 0.012498142, 0.019169445, 0.015311359, 0.052160798, 0.054297026, 0.030886073, 0.021841838, 0.024432454, 0.013435841, 0.014925982, 0.029405817, 0.033456928, 0.047903982, 0.023374816, 0.017867578, 0.039527871, 0.104978108, 0.019891388};
            int startIndex = 7;
            int endIndex = 30;
            PValueWeight[] pvalueWeights = new PValueWeight[endIndex - startIndex];
            for (int i = startIndex; i < endIndex; i++) {
                pvalueWeights[i - startIndex] = new PValueWeight();
                pvalueWeights[i - startIndex].pValue = pvalues[i];
                pvalueWeights[i - startIndex].index = i - startIndex;
                pvalueWeights[i - startIndex].var = 1;
            }

            ldCorr = ldCorr.viewPart(startIndex, startIndex, endIndex - startIndex, endIndex - startIndex);
            // System.out.println(ldCorr.toString());
            System.out.println(pa.combinePValuebyScaleedFisherCombinationTestCovLogP(pvalueWeights, ldCorr));
            //for Pitman, Roger Keith analysis 
            System.out.println(pa.combinePValuebyWeightedSimeCombinationTestGATES(pvalueWeights, ldCorr));

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void testScaledChi() throws Exception {
        int lociNum = 10;
        final double PRECISION = 1.0e-8;
        double[] mean = new double[lociNum];
        Arrays.fill(mean, 0.0);

        RealMatrix covarianceMatrix = new Array2DRowRealMatrix(lociNum, lociNum);

        double roh = 0.5;

        for (int i = 0; i < lociNum; i++) {
            for (int j = 0; j < lociNum; j++) {
                if (i == j) {
                    covarianceMatrix.setEntry(i, j, 1);
                } else {
                    covarianceMatrix.setEntry(i, j, roh);
                }
            }
        }

        CorrelatedRandomVectorGenerator sg = new CorrelatedRandomVectorGenerator(mean, covarianceMatrix, PRECISION, new GaussianRandomGenerator(new MersenneTwister()));

        DoubleArrayList[] chisList = new DoubleArrayList[lociNum];
        DoubleArrayList[] pvList = new DoubleArrayList[lociNum];
        double[][] covLogP = new double[lociNum][lociNum];
        double[][] correPV = new double[lociNum][lociNum];

        for (int i = 0; i < lociNum; i++) {
            Arrays.fill(covLogP[i], 0);
            Arrays.fill(correPV[i], 0);
            chisList[i] = new DoubleArrayList();
            pvList[i] = new DoubleArrayList();
        }

        int popuSize = 500000;
        double currentP = 0.01;

        double adjP = 0;

        double varTD = 2 * lociNum;
        double meanTD = lociNum;
        double a1 = 3.263119, a2 = 0.709866, a3 = 0.026589, a4 = 0.709866;

        // double a1 = 0.0037, a2 = 3.9457, a3 = 0.0004, a4 = 0.709866;
        double X = 0;
        for (int i = 0; i < lociNum; i++) {
            for (int j = i + 1; j < lociNum; j++) {
                //y = 0.0037x3 + 3.9457x2 + 0.0004x
                //when here is r
                //x = 0.026589 * (Math.pow(x1, 3)) + 0.709866* (Math.pow(x1, 2)) + 3.263119 * x1;
                //x = 0.0037 * (Math.pow(x1, 3)) + 3.9457 * (Math.pow(x1, 2)) + 0.0004 * x1;
                double r = covarianceMatrix.getEntry(i, j);
                //r = Math.abs(r);
                // X += 2 * (a1 * r + a2 * r * r + a3 * r * r * r);
                //X += 2 * 2 * r * r;
                X += 0.180;
                //X += 2 * (4.0 * r * r);
                //y = 0.0565x3 + 0.0542x2 + 3.8891x
                //when here is r2
                //r = r * r;
                //X +=  2*(0.0565 * (Math.pow(r, 3)) + 0.0542 * (Math.pow(r, 2)) + 3.8891 * r);

                // varTD += 2 * (a1 * ldCorr.get(j, j) + a2 * ldCorr.get(j, j) * ldCorr.get(j, j) + a3 * ldCorr.get(j, j) * ldCorr.get(j, j) * ldCorr.get(j, j));
            }
        }
//roh
        varTD = X + varTD;
        double c = varTD / (2 * meanTD);
        double f = 2 * meanTD * meanTD / varTD;
        double sum1 = 0, sum2 = 0;

        double adjP1 = 0;
        DoubleMatrix2D ldCorr = new DenseDoubleMatrix2D(2, 2);
        double[] pvs = new double[lociNum];
        ChiSquaredDistributionImpl chisqare = new ChiSquaredDistributionImpl(1);
        DoubleArrayList list1 = new DoubleArrayList();
        DoubleArrayList list2 = new DoubleArrayList();

        /*
         pp <- scan("D:/home/mxli/MyJava/GenetSimulator/test.txt", quiet= TRUE);
         hist(pp, breaks=100);
         */
        BufferedWriter debugOut = new BufferedWriter(new FileWriter("test.txt"));

        for (int i = 0; i < popuSize; i++) {

            double[] samples = sg.nextVector();
            sum1 = 0;

            for (int j = 0; j < lociNum; j++) {
                // System.out.print(samples[j] + " ");
                double pt = 1 - Probability.normal(samples[j]);
                //System.out.println(samples[j]);

                sum1 += -2 * Math.log(pt);
                chisList[j].add(-2 * Math.log(pt));
            }
            list1.add(sum1);
            //System.out.println();

            double pt = 1;
            sum2 = 0;
            for (int j = 0; j < lociNum; j++) {
                // pvList[j].add(samples[j]);
                // sum2 +=samples[j];
                samples[j] = samples[j] * samples[j];
                pt = Probability.chiSquareComplemented(1, samples[j]);
                sum2 += Probability.normalInverse(1 - pt);

                //sum2 += -2 * Math.log(2 - 2*Probability.normal(Math.abs(samples[j])));
                //pvList[j].add(Probability.normalInverse(1-pt));
                pvList[j].add(Probability.normalInverse(1 - pt));
            }
            debugOut.write(String.valueOf(sum2));
            debugOut.newLine();
            list2.add(sum2);
            double p = 0;

            p = Probability.chiSquareComplemented(f, sum1 / c);
            if (p <= currentP) {
                adjP1 += 1;
            }
            //p = Probability.chiSquareComplemented(f, sum2 / c);
            p = Probability.normal(0, lociNum + 2 * X, sum2);
            if (p <= currentP) {
                adjP += 1;
            }
        }
        debugOut.close();

        System.out.println(adjP1 / popuSize);
        System.out.println(adjP / popuSize);

        System.out.println(Descriptive.mean(list1));
        System.out.println(Descriptive.sampleVariance(list1, Descriptive.mean(list1)));

        System.out.println(Descriptive.mean(list2));
        System.out.println(Descriptive.sampleVariance(list2, Descriptive.mean(list2)));

        for (int j = 0; j < lociNum; j++) {
            for (int s = j + 1; s < lociNum; s++) {
                double mean1 = Descriptive.mean(chisList[j]);
                double mean2 = Descriptive.mean(chisList[s]);
                double sd1 = Descriptive.sampleVariance(chisList[j], mean1);
                double sd2 = Descriptive.sampleVariance(chisList[s], mean2);

                //covLogP[j][s] += Descriptive.correlation(chisList[j], Math.sqrt(sd1), chisList[s], Math.sqrt(sd2));
                covLogP[j][s] += Descriptive.covariance(chisList[j], chisList[s]);
                mean1 = Descriptive.mean(pvList[j]);
                mean2 = Descriptive.mean(pvList[s]);
                sd1 = Descriptive.sampleVariance(pvList[j], mean1);
                sd2 = Descriptive.sampleVariance(pvList[s], mean2);
                //correPV[j][s] += Descriptive.correlation(pvList[j], Math.sqrt(sd1), pvList[s], Math.sqrt(sd2));
                correPV[j][s] += Descriptive.covariance(pvList[j], pvList[s]);
            }
        }
        for (int j = 0; j < lociNum; j++) {
            for (int s = 0; s < lociNum; s++) {
                System.out.print(String.valueOf(covLogP[j][s]));
                System.out.print("\t");
            }
            System.out.println();
        }

        for (int j = 0; j < lociNum; j++) {
            for (int s = 0; s < lociNum; s++) {
                System.out.print(String.valueOf(correPV[j][s]));
                System.out.print("\t");
            }
            System.out.println();
        }

        // System.out.println(crudeEp / simulationTime);
        //System.out.println(adjP / simulationTime);
    }

    public double veagsPNormal(double[] vars, DoubleMatrix2D ldCorr) throws Exception {
        //VEAGA orginal implemenation
        int lociNum = ldCorr.rows();
        CholeskyDecomposition cd = new CholeskyDecomposition(ldCorr);
        DoubleMatrix2D lowTriangle = cd.getL();
        //System.out.println(ltriangle.toString());
        final double PRECISION = 1.0e-8;
        double[] mean = new double[lociNum];
        Arrays.fill(mean, 0.0);

        RealMatrix covarianceMatrix = new Array2DRowRealMatrix(lociNum, lociNum);
        for (int i = 0; i < lociNum; i++) {
            for (int j = 0; j < lociNum; j++) {
                if (i != j) {
                    covarianceMatrix.setEntry(i, j, 0);
                } else {
                    covarianceMatrix.setEntry(i, j, 1);
                }
            }
        }

        double sumAB = 0;
        for (int i = 0; i < lociNum; i++) {
            sumAB += (vars[i] * vars[i]);
        }
        CorrelatedRandomVectorGenerator sg = new CorrelatedRandomVectorGenerator(mean, covarianceMatrix, PRECISION, new GaussianRandomGenerator(new MersenneTwister()));
        double crudeEp = 0;
        int popuSize = 10000;
        DoubleMatrix2D vector = new DenseDoubleMatrix2D(1, lociNum);
        DoubleMatrix2D tmpMatrix = new DenseDoubleMatrix2D(1, lociNum);
        for (int i = 0; i < popuSize; i++) {
            double[] samples = sg.nextVector();
            for (int j = 0; j < lociNum; j++) {
                vector.setQuick(0, j, samples[j]);
            }
            vector.zMult(lowTriangle, tmpMatrix);
            double sum = 0;
            for (int j = 0; j < lociNum; j++) {
                sum += (tmpMatrix.getQuick(0, j) * tmpMatrix.getQuick(0, j));
            }
            if (sumAB <= sum) {
                crudeEp += 1;
            }
        }
        //System.out.println(crudeEp / simulationTime);
        return crudeEp / popuSize;
    }

    /*
     library(mvtnorm)
     m <- 3
     sigma <- diag(3)
     sigma[2, 1] <- 3/5
     sigma[3, 1] <- 1/3
     sigma[3, 2] <- 11/15
     pmvnorm(mean = rep(0, m), sigma, lower = rep(-Inf, m), upper = c(1, 4, 2))
     *
     *
     *
     *
     */
    public double combinePValuebyMultiNormalTest(double[] pValueArray, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return 1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }
        Arrays.sort(pValueArray);
        //two-tails
        double[] a = new double[snpSize];
        for (int i = 0; i < snpSize; i++) {
            a[i] = Probability.normalInverse(pValueArray[i] / 2);
        }

        CholeskyDecomposition cd = new CholeskyDecomposition(ldCorr);
        DoubleMatrix2D ltriangle = cd.getL();
        System.out.println(ltriangle.toString());

        final double PRECISION = 1.0e-8;
        double alpha = 2.5;
        int iterMax = 100;
        double intSum = 0, varSum = 0;
        double d0 = Probability.normal(a[0] / ltriangle.getQuick(0, 0));
        double e0 = Probability.normal(-a[0] / ltriangle.getQuick(0, 0));
        double f0 = e0 - d0;
        double error = 1;

        double uniVariable = 0;
        cern.jet.random.engine.RandomEngine twister = new cern.jet.random.engine.MersenneTwister(new java.util.Date());
        double[] y = new double[snpSize];
        int iterNum = 0;
        double tmpD = 0;
        while (error >= PRECISION && iterNum < iterMax) {
            for (int i = 1; i < snpSize; ++i) {
                uniVariable = twister.raw();
                tmpD = d0 + uniVariable * f0;
                System.out.println(tmpD);
                y[i - 1] = Probability.normalInverse(tmpD);
                double sum = 0;
                for (int j = 0; j < i; j++) {
                    sum += ltriangle.getQuick(i, j) * y[j];
                }
                d0 = Probability.normal(a[i] - sum) / ltriangle.getQuick(i, i);
                e0 = Probability.normal(-a[i] - sum) / ltriangle.getQuick(i, i);
                f0 = (e0 - d0) * f0;
            }
            intSum += f0;
            varSum += f0 * f0;
            iterNum++;
            if (iterNum > 2) {
                error = alpha * Math.sqrt(((varSum / iterNum - (intSum * intSum / iterNum / iterNum)) / iterNum));
            }
        }

        double p = intSum / iterNum;
        return (1 - p) / 2;
    }

    public double combinePValuebyWeightedSimeCombinationTestGATES(PValueWeight[] pValueArray, DoubleMatrix2D ldRMatrix) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return 1;
        } else if (snpSize == 1) {
            return pValueArray[0].pValue;
        }
        Arrays.sort(pValueArray, new PValueWeightPComparator());
        pValueArray[0].effectiveIndex = 1;
        List<Integer> selectedIndex = new ArrayList<Integer>();

        double ess = 0;
        double accumulatedIndex = 1;
        double totalRatio = pValueArray[0].effectiveIndex * pValueArray[0].var;

        for (int i = 0; i < snpSize; i++) {
            selectedIndex.add(pValueArray[i].index);
            for (int j = i + 1; j < snpSize; j++) {
                if (i == j) {
                    continue;
                }

                double x = ldRMatrix.getQuick(pValueArray[i].index, pValueArray[j].index);
                x = x * x;
                //when r2                  
                x = (((((0.7723 * x - 1.5659) * x + 1.201) * x - 0.2355) * x + 0.2184) * x + 0.6086) * x;

                ldRMatrix.setQuick(pValueArray[i].index, pValueArray[j].index, x);
                ldRMatrix.setQuick(pValueArray[j].index, pValueArray[i].index, x);

            }
        }

        double totalEffetiveSize = SpecialFunc.calculateEffectSampleSizeColtMatrixMyMethod(ldRMatrix, selectedIndex);

        selectedIndex.clear();
        selectedIndex.add(pValueArray[0].index);
        snpSize--;
        for (int i = 1; i < snpSize; i++) {
            selectedIndex.add(pValueArray[i].index);
            ess = SpecialFunc.calculateEffectSampleSizeColtMatrixMyMethod(ldRMatrix, selectedIndex);
            pValueArray[i].effectiveIndex = ess - accumulatedIndex;
            accumulatedIndex = ess;
            totalRatio += pValueArray[i].effectiveIndex * pValueArray[i].var;
        }
        //to save time
        pValueArray[snpSize].effectiveIndex = totalEffetiveSize - accumulatedIndex;
        totalRatio += pValueArray[snpSize].effectiveIndex * pValueArray[snpSize].var;
        snpSize++;

        double factor = totalEffetiveSize / totalRatio;
        pValueArray[0].effectiveIndex = pValueArray[0].effectiveIndex * pValueArray[0].var * factor;
        for (int i = 1; i < snpSize; i++) {
            pValueArray[i].effectiveIndex = pValueArray[i].effectiveIndex * pValueArray[i].var * factor + pValueArray[i - 1].effectiveIndex;
        }
        double minP = totalEffetiveSize * pValueArray[0].pValue / pValueArray[0].effectiveIndex;
        double p;
        double factor1 = totalEffetiveSize, factor2 = pValueArray[0].pValue;
        for (int i = 1; i < snpSize; i++) {
            p = totalEffetiveSize * pValueArray[i].pValue / pValueArray[i].effectiveIndex;
            if (p < minP) {
                minP = p;
                factor1 = totalEffetiveSize / pValueArray[i].effectiveIndex;
                factor2 = pValueArray[i].pValue;
            }
        }
        // System.out.println(factor1 + "\t" + factor2);
        return minP;
    }

    public double combinePValuebyCorrectedChiFisherCombinationTestMXLiWeight(PValueWeight[] pValueArray, DoubleMatrix2D ldRMatrix) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return 1;
        } else if (snpSize == 1) {
            return pValueArray[0].pValue;
        }

        double[] chisquares1 = new double[snpSize];
        for (int i = 0; i < snpSize; i++) {
            chisquares1[i] = pValueArray[i].pValue / 2;
        }
        double[] chisquares = MultipleTestingMethod.zScores(chisquares1);
        double[][] chisquareArray = new double[snpSize][1];
        for (int i = 0; i < snpSize; i++) {
            chisquareArray[i][0] = chisquares[i] * chisquares[i];
        }

        DoubleMatrix2D chisequreMat = new DenseDoubleMatrix2D(chisquareArray);
        Algebra alg = new Algebra();
        for (int i = 0; i < snpSize; i++) {
            //* pValueArray[j].var
            ldRMatrix.setQuick(i, i, pValueArray[i].var * pValueArray[i].var);
            for (int j = i + 1; j < snpSize; j++) {
                //Math.sqrt(pValueArray[j].var * pValueArray[j].var) 
                ldRMatrix.setQuick(i, j, pValueArray[i].var * pValueArray[j].var * ldRMatrix.getQuick(i, j));
                ldRMatrix.setQuick(j, i, ldRMatrix.getQuick(i, j));
            }
        }

        DoubleMatrix2D inv = alg.inverse(ldRMatrix);
        DoubleMatrix2D indChisequreMat = alg.mult(inv, chisequreMat);

        for (int i = 0; i < snpSize; i++) {
            chisequreMat.setQuick(i, 0, 1);
        }
        DoubleMatrix2D indChiDfMat = alg.mult(inv, chisequreMat);
        double df = 0;
        double Y = 0;
        for (int i = 0; i < snpSize; i++) {
            Y += (pValueArray[i].var * indChisequreMat.getQuick(0, i));
            // Y1 += chisquareArray[j][0];
            // pValueArray[j].var *
            df += (pValueArray[i].var * indChiDfMat.getQuick(0, i));
        }

        //calcualte the scalled chi 
        double p = Probability.chiSquareComplemented(df, Y);
        if (p < 0.0) {
            p = 0.0;
        }
        return p;
    }

    public double combinePValuebyWeightedSimeCombinationTestMyMeChangeP(PValueWeight[] pValueArray, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return 1;
        } else if (snpSize == 1) {
            return pValueArray[0].pValue;
        }
        Arrays.sort(pValueArray, new PValueWeightPComparator());
        pValueArray[0].effectiveIndex = 1;
        List<Integer> selectedIndex = new ArrayList<Integer>();

        double ess = 0;
        double accumulatedIndex = 1;
        double totalRatio = pValueArray[0].effectiveIndex * pValueArray[0].var;

        for (int i = 0; i < snpSize; i++) {
            selectedIndex.add(pValueArray[i].index);
            for (int j = i + 1; j < snpSize; j++) {
                if (i == j) {
                    continue;
                }

                //poweredcorrMat.setQuick(j, j, Math.pow(corrMat.getQuick(j, j), power));
                double x = ldCorr.getQuick(pValueArray[i].index, pValueArray[j].index);
                x = x * x;
                //when r2                 
                //I do not know why it seems if I use x1=x1*x1  it woks better in terms of type 1 error
                x = (((((0.7723 * x - 1.5659) * x + 1.201) * x - 0.2355) * x + 0.2184) * x + 0.6086) * x;
                //x = x1 * x1;
                ldCorr.setQuick(pValueArray[i].index, pValueArray[j].index, x);
                ldCorr.setQuick(pValueArray[j].index, pValueArray[i].index, x);

            }
        }

        double totalEffetiveSize = SpecialFunc.calculateEffectSampleSizeColtMatrixMyMethod(ldCorr, selectedIndex);

        selectedIndex.clear();
        selectedIndex.add(pValueArray[0].index);
        snpSize--;
        for (int i = 1; i < snpSize; i++) {
            selectedIndex.add(pValueArray[i].index);
            ess = SpecialFunc.calculateEffectSampleSizeColtMatrixMyMethod(ldCorr, selectedIndex);
            pValueArray[i].effectiveIndex = ess - accumulatedIndex;
            accumulatedIndex = ess;
            totalRatio += pValueArray[i].effectiveIndex * pValueArray[i].var;
        }
        //to save time
        pValueArray[snpSize].effectiveIndex = totalEffetiveSize - accumulatedIndex;
        totalRatio += pValueArray[snpSize].effectiveIndex * pValueArray[snpSize].var;
        snpSize++;

        double factor = totalEffetiveSize / totalRatio;
        pValueArray[0].effectiveIndex = pValueArray[0].effectiveIndex * pValueArray[0].var * factor;
        for (int i = 1; i < snpSize; i++) {
            pValueArray[i].effectiveIndex = pValueArray[i].effectiveIndex * pValueArray[i].var * factor + pValueArray[i - 1].effectiveIndex;
        }
        double minP = totalEffetiveSize * pValueArray[0].pValue / pValueArray[0].effectiveIndex;
        pValueArray[0].pValue = minP;
        double p;

        for (int i = 1; i < snpSize; i++) {
            p = totalEffetiveSize * pValueArray[i].pValue / pValueArray[i].effectiveIndex;
            if (p < minP) {
                minP = p;

            }
            pValueArray[i].pValue = p;
        }

        return minP;
    }

    public double combinePValuebyWeightedSimeCombinationTestMyMe(PValueWeight[] pValueArray, DoubleMatrix2D ldCorr, PValueWeight pw) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return 1;
        } else if (snpSize == 1) {
            pw.pValue = pValueArray[0].pValue;
            pw.index = pValueArray[0].index;
            return pValueArray[0].pValue;
        }
        Arrays.sort(pValueArray, new PValueWeightPComparator());
        pValueArray[0].effectiveIndex = 1;
        List<Integer> selectedIndex = new ArrayList<Integer>();

        double ess = 0;
        double accumulatedIndex = 1;
        double totalRatio = pValueArray[0].effectiveIndex * pValueArray[0].var;

        for (int i = 0; i < snpSize; i++) {
            selectedIndex.add(pValueArray[i].index);
            for (int j = i + 1; j < snpSize; j++) {
                if (i == j) {
                    continue;
                }
                //poweredcorrMat.setQuick(j, j, Math.pow(corrMat.getQuick(j, j), power));
                double x = ldCorr.getQuick(pValueArray[i].index, pValueArray[j].index);
                x = x * x;
                //when r2                 
                //I do not know why it seems if I use x1=x1*x1  it woks better in terms of type 1 error
                x = (((((0.7723 * x - 1.5659) * x + 1.201) * x - 0.2355) * x + 0.2184) * x + 0.6086) * x;
                //x = x1 * x1;
                ldCorr.setQuick(pValueArray[i].index, pValueArray[j].index, x);
                ldCorr.setQuick(pValueArray[j].index, pValueArray[i].index, x);
            }
        }

        double totalEffetiveSize = SpecialFunc.calculateEffectSampleSizeColtMatrixMyMethod(ldCorr, selectedIndex);
        selectedIndex.clear();
        selectedIndex.add(pValueArray[0].index);
        snpSize--;
        for (int i = 1; i < snpSize; i++) {
            selectedIndex.add(pValueArray[i].index);
            ess = SpecialFunc.calculateEffectSampleSizeColtMatrixMyMethod(ldCorr, selectedIndex);
            pValueArray[i].effectiveIndex = ess - accumulatedIndex;
            accumulatedIndex = ess;
            totalRatio += pValueArray[i].effectiveIndex * pValueArray[i].var;
        }
        //to save time
        pValueArray[snpSize].effectiveIndex = totalEffetiveSize - accumulatedIndex;
        totalRatio += pValueArray[snpSize].effectiveIndex * pValueArray[snpSize].var;
        snpSize++;

        double factor = totalEffetiveSize / totalRatio;
        pValueArray[0].effectiveIndex = pValueArray[0].effectiveIndex * pValueArray[0].var * factor;
        for (int i = 1; i < snpSize; i++) {
            pValueArray[i].effectiveIndex = pValueArray[i].effectiveIndex * pValueArray[i].var * factor + pValueArray[i - 1].effectiveIndex;
        }
        double minP = totalEffetiveSize * pValueArray[0].pValue / pValueArray[0].effectiveIndex;
        pw.pValue = pValueArray[0].pValue;
        pw.index = pValueArray[0].index;
        double p;
        for (int i = 1; i < snpSize; i++) {
            p = totalEffetiveSize * pValueArray[i].pValue / pValueArray[i].effectiveIndex;
            if (p < minP) {
                minP = p;
                pw.pValue = pValueArray[i].pValue;
                pw.index = pValueArray[i].index;
            }
        }
        return minP;
    }

    public IntArrayList weightedSimesTestMyMe(PValueWeight[] pValueArray, DoubleMatrix2D ldCorr, double threshlod) throws Exception {
        int snpSize = pValueArray.length;
        IntArrayList significantIndex = new IntArrayList();
        if (snpSize == 0) {
            return significantIndex;
        }
        Arrays.sort(pValueArray, new PValueWeightPComparator());
        pValueArray[0].effectiveIndex = 1;
        List<Integer> selectedIndex = new ArrayList<Integer>();
        selectedIndex.add(pValueArray[0].index);
        double ess = 0;
        double accumulatedIndex = 1;
        double totalRatio = pValueArray[0].effectiveIndex * pValueArray[0].var;

        double totalEffetiveSize = SpecialFunc.calculateEffectSampleSizeColtMatrixMyMethod(ldCorr, null);
        snpSize--;
        for (int i = 1; i < snpSize; i++) {
            selectedIndex.add(pValueArray[i].index);
            ess = SpecialFunc.calculateEffectSampleSizeColtMatrixMyMethod(ldCorr, selectedIndex);
            pValueArray[i].effectiveIndex = ess - accumulatedIndex;
            accumulatedIndex = ess;
            totalRatio += pValueArray[i].effectiveIndex * pValueArray[i].var;
        }
        //to save time
        pValueArray[snpSize].effectiveIndex = totalEffetiveSize - accumulatedIndex;
        totalRatio += pValueArray[snpSize].effectiveIndex * pValueArray[snpSize].var;
        snpSize++;
        double factor = totalEffetiveSize / totalRatio;
        pValueArray[0].effectiveIndex = pValueArray[0].effectiveIndex * pValueArray[0].var * factor;
        for (int i = 1; i < snpSize; i++) {
            pValueArray[i].effectiveIndex = pValueArray[i].effectiveIndex * pValueArray[i].var * factor + pValueArray[i - 1].effectiveIndex;
        }

        threshlod = threshlod / totalEffetiveSize;
        //P{P(j)>j��/k, forall j=1,��,k}=1?��.
        for (int i = 0; i < snpSize; i++) {
            if (pValueArray[i].pValue <= pValueArray[i].effectiveIndex * threshlod) {
                significantIndex.add(pValueArray[i].index);
            }
        }
        return significantIndex;
    }

    /*
     public double combinePValuebyWeightedSimeCombinationTestGATES(PValueWeight[] pValueArray, DoubleMatrix2D ldCorr) throws Exception {
     int snpSize = pValueArray.length;
     if (snpSize == 0) {
     return 1;
     } else if (snpSize == 1) {
     return pValueArray[0].pValue;
     }
     Arrays.sort(pValueArray, new PValueWeightComparator());
     double totalEffetiveSize = SpecialFunc.calculateEffectSampleSizeColtMatrixMyMethod(ldCorr, null);
    
     double totalRatio = 0;
     for (int t = 0; t < snpSize; t++) {
     totalRatio += pValueArray[t].weight;
     }
    
     totalRatio /= snpSize;
     double accumulatedWeight = pValueArray[0].weight;
    
    
     double minP = totalRatio * totalEffetiveSize * pValueArray[0].pValue / accumulatedWeight;
     double p1;
     Set<Integer> selectedIndex = new HashSet<Integer>();
     selectedIndex.add(pValueArray[0].index);
     double ess = 0;
     snpSize--;
     for (int j = 1; j <= snpSize; j++) {
     accumulatedWeight += pValueArray[j].weight;
     selectedIndex.add(pValueArray[j].index);
     if (j == snpSize) {
     p1 = pValueArray[j].pValue;
     } else {
     ess = SpecialFunc.calculateEffectSampleSizeColtMatrixMyMethod(ldCorr, selectedIndex);
     p1 = ((j + 1) * totalRatio * totalEffetiveSize * pValueArray[j].pValue / (ess * accumulatedWeight));
     }
     if (p1 < minP) {
     minP = p1;
     }
     }
     return minP;
     }
     */
    public double[] combinePValuebyVEGAS(double totalTestStatistics, double bestStatistics, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = ldCorr.columns();
        if (snpSize == 0) {
            return new double[]{1, 1};
        }

        /*
         for (int j = 0; j < snpSize; j++) {
         for (int j = 0; j < snpSize; j++) {
         ldCorr.setQuick(j, j, ldCorr.getQuick(j, j) * ldCorr.getQuick(j, j));
         }
         }
         *
         */
        CholeskyDecomposition cd = new CholeskyDecomposition(ldCorr);
        DoubleMatrix2D lowTriangle = cd.getL();
        //System.out.println(ltriangle.toString());

        final double PRECISION = 1.0e-8;
        double[] mean = new double[snpSize];
        Arrays.fill(mean, 0.0);
        int simulationTime = 1000000;
        RealMatrix covarianceMatrix = new Array2DRowRealMatrix(snpSize, snpSize);
        DoubleMatrix2D vector = new DenseDoubleMatrix2D(1, snpSize);
        DoubleMatrix2D tmpMatrix = new DenseDoubleMatrix2D(1, snpSize);

        double empiricalP1 = 0.0;
        double empiricalP2 = 0.0;
        for (int i = 0; i < snpSize; i++) {
            covarianceMatrix.setEntry(i, i, 1);
        }
        double tmp = 0;
        double betStat = 0;

        CorrelatedRandomVectorGenerator sg = new CorrelatedRandomVectorGenerator(mean, covarianceMatrix, PRECISION, new GaussianRandomGenerator(new MersenneTwister()));
        for (int i = 0; i < simulationTime; i++) {
            double[] samples = sg.nextVector();
            for (int j = 0; j < snpSize; j++) {
                vector.setQuick(0, j, samples[j]);
            }

            vector.zMult(lowTriangle, tmpMatrix);

            double sum = 0;
            betStat = -1;
            for (int j = 0; j < snpSize; j++) {
                if (Double.isInfinite(tmpMatrix.getQuick(0, j)) || Double.isNaN(tmpMatrix.getQuick(0, j))) {
                    continue;
                }
                tmp = (tmpMatrix.getQuick(0, j) * tmpMatrix.getQuick(0, j));
                if (tmp >= betStat) {
                    betStat = tmp;
                }
                sum += tmp;
            }

            if (sum >= totalTestStatistics) {
                empiricalP1 += 1;
            }

            if (betStat >= bestStatistics) {
                empiricalP2 += 1;
            }
        }
        empiricalP1 += 1;
        empiricalP2 += 1;
        simulationTime += 1;
        return new double[]{empiricalP1 / simulationTime, empiricalP2 / simulationTime};
    }

    public double[] combinePValuebyVEGAS1(double totalTestStatistics, double bestStatistics, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = ldCorr.columns();
        if (snpSize == 0) {
            return new double[]{1, 1};
        }

        /*
        for (int j = 0; j < snpSize; j++) {
            for (int j = 0; j < snpSize; j++) {
                ldCorr.setQuick(j, j, Math.abs(ldCorr.getQuick(j, j)));
            }
        }
         */
        //CholeskyDecomposition cd = new CholeskyDecomposition(ldCorr);
        //DoubleMatrix2D lowTriangle = cd.getL();
        //System.out.println(ltriangle.toString());
        final double PRECISION = 1.0e-8;
        double[] mean = new double[snpSize];
        Arrays.fill(mean, 0.0);
        int simulationTime = 10000;

        double empiricalP1 = 0.0;
        double empiricalP2 = 0.0;

        double betStat = 0;
        double sum = 0;
        int[] seeds = new int[19];
        for (int i = 0; i < seeds.length; i++) {
            seeds[i] = (int) (Math.random() * 1000000);
            // System.out.println(seeds[j]);
        }
        WELL607 we = new WELL607();
        we.setSeed(seeds);
        NormalGen ng = new NormalGen(new MT19937(we));

        MultinormalCholeskyGen sg = new MultinormalCholeskyGen(ng, mean, ldCorr); //How about the alternative one MultinormalPCAGen?
        double[] samples = new double[snpSize];

        for (int i = 0; i < simulationTime; i++) {
            sg.nextPoint(samples);
            sum = 0;
            betStat = -1;
            for (int j = 0; j < snpSize; j++) {
                samples[j] = samples[j] * samples[j];
                if (samples[j] > betStat) {
                    betStat = samples[j];
                }
                sum += samples[j];
            }

            if (sum >= totalTestStatistics) {
                empiricalP1 += 1;
            }

            if (betStat >= bestStatistics) {
                empiricalP2 += 1;
            }
        }
        empiricalP1 += 1;
        empiricalP2 += 1;
        simulationTime += 1;
        return new double[]{empiricalP1 / simulationTime, empiricalP2 / simulationTime};
    }

    //Genetic Epidemiology 22:170?185 (2002)
    public double combinePValuebyZaykin(double[] pvalues, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = ldCorr.columns();
        if (snpSize == 0) {
            return 1;
        }
        DoubleMatrix2D zs = new DenseDoubleMatrix2D(pvalues.length, 1);
        for (int i = 0; i < snpSize; i++) {
            zs.setQuick(i, 0, MultipleTestingMethod.zScore(pvalues[i]));
        }

        CholeskyDecomposition cd = new CholeskyDecomposition(ldCorr);
        DoubleMatrix2D lowTriangle = cd.getL();

        DoubleMatrix2D zs1 = new DenseDoubleMatrix2D(pvalues.length, 1);
        lowTriangle.zMult(zs, zs1);
        double[] pp = new double[snpSize];
        for (int i = 0; i < snpSize; i++) {
            pp[i] = 1 - Probability.normal(zs1.getQuick(i, 0));
        }
        return combinePValuebyFisherCombinationTest(pp);
    }

    public double combinePValuebyBestSVEGAS1(double[] pValueArray, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = ldCorr.columns();
        if (snpSize == 0) {
            return 1;
        }
        double bestStatistics = 0;
        for (int i = 0; i < snpSize; i++) {
            double a = Probability.normalInverse(pValueArray[i] / 2);
            if (a * a > bestStatistics) {
                bestStatistics = (a * a);
            }
        }

        double betStat;
        CholeskyDecomposition cd = new CholeskyDecomposition(ldCorr);
        DoubleMatrix2D lowTriangle = cd.getL();
        //System.out.println(ltriangle.toString());

        final double PRECISION = 1.0e-8;
        double[] mean = new double[snpSize];
        Arrays.fill(mean, 0.0);
        int simulationTime = 10000;
        RealMatrix covarianceMatrix = new Array2DRowRealMatrix(snpSize, snpSize);
        DoubleMatrix2D vector = new DenseDoubleMatrix2D(1, snpSize);
        DoubleMatrix2D tmpMatrix = new DenseDoubleMatrix2D(1, snpSize);

        double empiricalP = 0.0;
        for (int i = 0; i < snpSize; i++) {
            covarianceMatrix.setEntry(i, i, 1);
        }
        CorrelatedRandomVectorGenerator sg = new CorrelatedRandomVectorGenerator(mean, covarianceMatrix, PRECISION, new GaussianRandomGenerator(new MersenneTwister()));
        for (int i = 0; i < simulationTime; i++) {
            double[] samples = sg.nextVector();

            for (int j = 0; j < snpSize; j++) {
                vector.setQuick(0, j, samples[j]);
            }
            vector.zMult(lowTriangle, tmpMatrix);
            betStat = 0;
            for (int j = 0; j < snpSize; j++) {
                if (Double.isInfinite(tmpMatrix.getQuick(0, j)) || Double.isNaN(tmpMatrix.getQuick(0, j))) {
                    continue;
                }
                if (tmpMatrix.getQuick(0, j) * tmpMatrix.getQuick(0, j) > betStat) {
                    betStat = tmpMatrix.getQuick(0, j) * tmpMatrix.getQuick(0, j);
                }
            }

            if (betStat >= bestStatistics) {
                empiricalP += 1;
            }
            //System.out.println(tmpMatrix.toString());
        }
        return empiricalP / simulationTime;
    }

    //note this function is very sensitive to the non positive definite covariance matrix
    public double combinePValuebyBestSVEGAS(double[] pValueArray, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = ldCorr.columns();
        if (snpSize == 0) {
            return 1;
        }
        double bestStatistics = 0;
        for (int i = 0; i < snpSize; i++) {
            double a = Probability.normalInverse(pValueArray[i] / 2);
            if (a * a > bestStatistics) {
                bestStatistics = (a * a);
            }
        }

        final double PRECISION = 1.0e-8;
        double[] mean = new double[snpSize];
        Arrays.fill(mean, 0.0);
        int simulationTime = 10000;
        RealMatrix covarianceMatrix = new Array2DRowRealMatrix(snpSize, snpSize);

        double empiricalP = 0.0;

        for (int i = 0; i < snpSize; i++) {
            for (int j = 0; j < snpSize; j++) {
                covarianceMatrix.setEntry(i, j, ldCorr.getQuick(i, j));
            }
        }

        double betStat = 0;
        CorrelatedRandomVectorGenerator sg = new CorrelatedRandomVectorGenerator(mean, covarianceMatrix, PRECISION, new GaussianRandomGenerator(new MersenneTwister()));
        for (int i = 0; i < simulationTime; i++) {
            double[] samples = sg.nextVector();
            betStat = samples[0] * samples[0];
            for (int j = 1; j < snpSize; j++) {
                samples[j] = samples[j] * samples[j];
                if (samples[j] > betStat) {
                    betStat = samples[j];
                }
            }
            if (betStat >= bestStatistics) {
                empiricalP += 1;
            }
            //System.out.println(tmpMatrix.toString());
        }
        return empiricalP / simulationTime;
    }

    public double combinePValuebyMultiChi(double[] pValueArray, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = pValueArray.length;
        if (snpSize == 0) {
            return 1;
        } else if (snpSize == 1) {
            return pValueArray[0];
        }

        //two-tails
        double[] a = new double[snpSize];
        for (int i = 0; i < snpSize; i++) {
            a[i] = Probability.normalInverse(pValueArray[i] / 2);
        }

        for (int i = 0; i < snpSize; i++) {
            for (int j = 0; j < snpSize; j++) {
                //  ldCorr.setQuick(j, j, ldCorr.getQuick(j, j) * ldCorr.getQuick(j, j));
            }
        }

        Algebra algebra = new Algebra();
        DoubleMatrix2D inverseCorr = algebra.inverse(ldCorr);
        //System.out.println(inverseCorr.toString());
        DoubleMatrix2D vector1 = new DenseDoubleMatrix2D(1, snpSize);
        DoubleMatrix2D vector2 = new DenseDoubleMatrix2D(snpSize, 1);
        for (int j = 0; j < snpSize; j++) {
            vector1.setQuick(0, j, a[j]);
            vector2.setQuick(j, 0, a[j]);
        }

        DoubleMatrix2D middle = new DenseDoubleMatrix2D(1, snpSize);
        vector1.zMult(inverseCorr, middle);
        //System.out.println(middle.toString());
        DoubleMatrix2D result = new DenseDoubleMatrix2D(1, 1);
        middle.zMult(vector2, result);
        //System.out.println(result.toString());
        //System.out.println(result.getQuick(0, 0));
        double p = Probability.chiSquareComplemented(snpSize, (result.getQuick(0, 0)));

        /*
         CholeskyDecomposition cd = new CholeskyDecomposition(ldCorr);
         DoubleMatrix2D lowTriangle = cd.getL();
         DoubleMatrix2D tmpMatrix = new DenseDoubleMatrix2D(1, snpSize);
         */
        return p;
    }

    public double combineNormalByMultiChi(double[] normalArray, DoubleMatrix2D ldCorr) throws Exception {
        int snpSize = normalArray.length;
        if (snpSize == 0) {
            return 1;
        }

        for (int i = 0; i < snpSize; i++) {
            for (int j = 0; j < snpSize; j++) {
                // ldCorr.setQuick(j, j, ldCorr.getQuick(j, j) * ldCorr.getQuick(j, j));
            }
        }

        Algebra algebra = new Algebra();
        DoubleMatrix2D inverseCorr = algebra.inverse(ldCorr);
        //System.out.println(inverseCorr.toString());
        DoubleMatrix2D vector1 = new DenseDoubleMatrix2D(1, snpSize);
        DoubleMatrix2D vector2 = new DenseDoubleMatrix2D(snpSize, 1);
        for (int j = 0; j < snpSize; j++) {
            vector1.setQuick(0, j, normalArray[j]);
            vector2.setQuick(j, 0, normalArray[j]);
        }

        DoubleMatrix2D middle = new DenseDoubleMatrix2D(1, snpSize);
        vector1.zMult(inverseCorr, middle);
        //System.out.println(middle.toString());
        DoubleMatrix2D result = new DenseDoubleMatrix2D(1, 1);
        middle.zMult(vector2, result);
        //System.out.println(result.toString());
        // System.out.println(result.getQuick(0, 0));
        double p = Probability.chiSquareComplemented(snpSize, (result.getQuick(0, 0)));

        /*
         CholeskyDecomposition cd = new CholeskyDecomposition(ldCorr);
         DoubleMatrix2D lowTriangle = cd.getL();
         DoubleMatrix2D tmpMatrix = new DenseDoubleMatrix2D(1, snpSize);
         */
        return p;
    }
}
