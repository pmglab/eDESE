/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.genetsimulator.entity;

import cern.colt.list.DoubleArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author mxli
 */
public class EffectiveNumRatio {

    Map<Double, DoubleArrayList> rhoRatioMap = new HashMap<Double, DoubleArrayList>();
    Map<Double, Integer> alphaIndexMap = new HashMap<Double, Integer>();

 
}
