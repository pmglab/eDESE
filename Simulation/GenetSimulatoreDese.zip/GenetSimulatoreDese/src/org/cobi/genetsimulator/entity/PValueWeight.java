/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.genetsimulator.entity;

/**
 *
 * @author mxli
 */
public class PValueWeight {

  public double pValue;
  public double chi;
  public double var;
  public double se;
  public int index;
  public double effectiveIndex;
}
