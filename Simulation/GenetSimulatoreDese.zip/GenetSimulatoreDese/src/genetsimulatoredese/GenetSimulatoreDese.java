/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package genetsimulatoredese;

import cern.colt.list.DoubleArrayList;
import cern.colt.list.IntArrayList;
import cern.colt.map.OpenIntIntHashMap;
import cern.colt.matrix.DoubleMatrix2D;
 
import cern.jet.stat.Descriptive;
import cern.jet.stat.Gamma;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.apache.commons.math.random.MersenneTwister;
 
import org.apache.commons.math.random.RandomData;
import org.apache.commons.math.random.RandomDataImpl;
 
import org.cobi.genetsimulator.controller.GeneInforProcessor;
import org.cobi.genetsimulator.controller.GenetAssociationAnalyzer;
import org.cobi.genetsimulator.controller.GenotypeQC;
import org.cobi.genetsimulator.controller.PValuePainter;
import org.cobi.genetsimulator.controller.PValuesAnalyzer;
import org.cobi.genetsimulator.controller.PopuStatSummarizer;
import org.cobi.genetsimulator.entity.AnnotSNP;
import org.cobi.genetsimulator.entity.GenotypeBasedLDSparseMatrix;
import org.cobi.genetsimulator.entity.Individual;
import org.cobi.genetsimulator.entity.PlinkDataset;
import org.cobi.genetsimulator.entity.Population;
import org.cobi.genetsimulator.entity.SNPPosiComparator;
import org.cobi.genetsimulator.entity.StatusGtySet;
import org.cobi.util.stat.MultipleTestingMethod;
 
import org.rosuda.REngine.Rserve.RConnection;

/**
 *
 * @author mxli
 */
public class GenetSimulatoreDese {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
     static public void realGenotypeGeneConditionalAssociationNew(String paramFile) throws Exception {
        Options option = new Options();
        option.readOptions(paramFile);
        option.parseOptions();

        GeneInforProcessor gip = new GeneInforProcessor();
        //  gip.extractGenePositions("seq_gene.md", "GeneSeq.txt");
        //read PPI pairs with 1MB        
        Map<String, int[]> closePPIPairs = gip.readConsecuiveGenePairs(option.inputFolder + "SeqGeneB36.txt", 5000, "1");
        List<AnnotSNP> snpList = new ArrayList<AnnotSNP>();
        List<Individual> indList = Collections.synchronizedList(new ArrayList<Individual>());

        String plinkFileName = option.inputFolder + option.plinFileName;
        PlinkDataset plinkDataset = new PlinkDataset(plinkFileName + ".fam", plinkFileName + ".bim", plinkFileName + ".bed");

        PopuStatSummarizer pps = new PopuStatSummarizer();
        DoubleMatrix2D twoDProb = null;
        GenotypeQC qc = new GenotypeQC();
        String chroName = "1";
        int gene1SNPNum = 20;
        String gInf = null;
        int maxQTLNum1 = 3;
        int maxQTLNum2 = 0;

        DoubleArrayList gpvList1 = new DoubleArrayList();
        DoubleArrayList gpvList2 = new DoubleArrayList();
        DoubleArrayList gpvList3 = new DoubleArrayList();

        boolean needR = true;
        double varPercentage = option.genetVarPercentage;
        String[] genePairs = new String[]{"SIPA1L2,LOC729336", "CACHD1,RAVER2", "LOC647132,FAM5C"};
        //String[] genePairs = new String[]{"SIPA1L2,LOC729336"};
        double[] landas = new double[]{1.1, 1.2, 1.25, 1.35, 1.45};
        DoubleArrayList[][] pvalueListInflationF = new DoubleArrayList[genePairs.length][landas.length];
        for (int i = 0; i < genePairs.length; i++) {
            for (int j = 0; j < landas.length; j++) {
                pvalueListInflationF[i][j] = new DoubleArrayList();
            }
        }
        // String[] genePairs = new String[]{"LOC647132,FAM5C"};
        boolean runGCTASNPCond = false;
        try {
            Population popu = new Population();
            int simulationTime = option.permutationTime;
            RConnection rcon = null;
            rcon = new RConnection();
            if (needR) {
                rcon.eval("library(lmtest)");
            }

            rcon.eval("library(NNLM)");
            rcon.eval("library(nnls)");

            double[] overallThreshold = new double[]{0.05, 0.01, 0.001};
            double p = 1;
            GenetAssociationAnalyzer analyer = new GenetAssociationAnalyzer();
            String line;
            Runtime rt = Runtime.getRuntime();
            BufferedWriter chisBw = new BufferedWriter(new FileWriter(option.outputFolder + ".chi"));
            for (int k = 0; k < genePairs.length; k++) {
                File f = new File(option.outputFolder + "." + k + ".p");
                BufferedWriter genePBw = new BufferedWriter(new FileWriter(f.getCanonicalPath()));
                genePBw.write("CombinedEf\tConditionalEff\tLikelihood\tLikelihoodNested\tGCTA\n");
                PValuesAnalyzer pValuesAnalyzer = new PValuesAnalyzer();

                List<AnnotSNP> qtlSnpList = new ArrayList<AnnotSNP>();
                RandomData randGenerator = new RandomDataImpl(new MersenneTwister());

                gpvList1.clear();
                gpvList2.clear();
                gpvList3.clear();

                double p1, p2, p3;
                double[][] genePowerList = new double[3][4];

                DoubleArrayList trats = new DoubleArrayList();
                DoubleArrayList trats1 = new DoubleArrayList();
                IntArrayList varID1 = new IntArrayList();
                IntArrayList varID2 = new IntArrayList();

                double ch1, ch2, ch3, ch4, ch5, ch6;
                for (Map.Entry<String, int[]> m : closePPIPairs.entrySet()) {
                    if (!m.getKey().startsWith(genePairs[k])) {
                        continue;
                    }
                    //System.out.println(m.getKey());
                    int[] poss = m.getValue();
                    if (poss[2] - poss[1] < -1000) {
                        // continue;
                    }
                    snpList.clear();
                    chroName = m.getKey().substring(m.getKey().lastIndexOf(',') + 1);

                    if (plinkDataset.readPlinkBinaryFormatMapByPysic(snpList, chroName, poss) <= 0) {
                        continue;
                        //throw new Exception("No SNP data!");
                    }
                    indList.clear();

                    plinkDataset.readPlinkBinaryFormatPedigreeGenotype(indList, snpList);
                    qc.removeByMAF(snpList, indList, 0.01);
                    OpenIntIntHashMap indexGenotypePosMap = new OpenIntIntHashMap();

                    int snpSize = snpList.size();

                    for (int j = 0; j < snpSize; j++) {
                        indexGenotypePosMap.put(snpList.get(j).getPhysicalPosition(), snpList.get(j).order);
                    }

                    GenotypeBasedLDSparseMatrix gtyLDMatrix = new GenotypeBasedLDSparseMatrix(indList, indexGenotypePosMap);
                    if (gtyLDMatrix == null) {
                        throw new Exception("LD data!");
                    }
                    String info = qc.ldPruning(snpList, gtyLDMatrix, 0.97, true);
                    //System.out.println(info);

                    Collections.sort(snpList, new SNPPosiComparator());
                    gene1SNPNum = 0;

                    if (snpList.size() < 3 || snpList.size() > 1500) {
                        continue;
                    }
                    qc.calculateMAF(snpList, indList);
                    varID1.clear();
                    varID2.clear();
                    for (int i = 0; i < snpList.size(); i++) {
                        if (snpList.get(i).getPhysicalPosition() < poss[1]) {
                            gene1SNPNum++;
                            varID1.add(i);
                        }
                    }

                    // qc.outCorrelation(snpList, gtyLDMatrix, 0, gene1SNPNum, "realcor.txt");
                    if (gene1SNPNum < 5 || (snpList.size() - gene1SNPNum) < 5) {
                        continue;
                    }
                    for (int i = snpList.size() - gene1SNPNum - 1; i >= 0; i--) {
                        varID2.add(i);
                    }
                    //gene1SNPNum+=10;
                    gInf = m.getKey() + "\t" + gene1SNPNum + "\t" + (snpList.size() - gene1SNPNum);
                    System.out.print(gInf);
                    //genePBw.write(gInf);
                    //genePBw.write("\n");
                    snpSize = snpList.size();
                    int indivSize = indList.size();
                    double gtyScore = 0;
                    if (needR) {
                        double[] gtys = new double[indivSize * snpSize];
                        for (int n = 0; n < indivSize; n++) {
                            //assume not missing data
                            for (int t = 0; t < snpSize; t++) {
                                int pos = snpList.get(t).order;
                                gtyScore = 0;
                                if (indList.get(n).markerGtySet.maternalChrom.getQuick(pos)) {
                                    gtyScore++;
                                }
                                if (indList.get(n).markerGtySet.paternalChrom.getQuick(pos)) {
                                    gtyScore++;
                                }
                                gtys[t + n * snpSize] = gtyScore;
                            }
                        }
                        rcon.assign("gtys", gtys);
                        rcon.voidEval("gtys<-matrix(gtys," + indivSize + "," + snpSize + ", byrow=TRUE)");
                    }

                    indexGenotypePosMap.clear();

                    IntArrayList indexPoses = new IntArrayList();
                    IntArrayList indexOrders = new IntArrayList();
                    for (int j = 0; j < snpSize; j++) {
                        indexGenotypePosMap.put(snpList.get(j).getPhysicalPosition(), snpList.get(j).order);
                        indexPoses.add(snpList.get(j).getPhysicalPosition());
                        indexOrders.add(snpList.get(j).order);
                        //System.out.println(snpList.get(j).getAAlleleFreq());
                    }

                    DoubleMatrix2D ldCorr = gtyLDMatrix.subDenseLDMatrix(indexPoses);

                    // System.out.println(ldCorr.toString());
                    // check th
                    int testSNPNum = ldCorr.columns();
                    if (testSNPNum < 2) {
                        throw new Exception("Only one SNP left!");
                    }

                    //select a set of SNPs for simulation, assuming that SNPs are sorted according to their physical postion
                    int indivNum = indList.size();
                    //check the LD patter and
                    // twoDProb = pps.calculate2DProbability(indList, testSNPNum);
                    //  pps.convert2LDIndex(twoDProb);

                    popu.setAllIndiv(indList);
                    //  analyer.readCovariables(option.inputFolder + "PCA_as_covariates_TW_SC.txt", indList);

                    int[] testIndex = new int[testSNPNum];

                    //System.out.println(lowTriangle.zMult( lowTriangle.viewDice(), null));
                    // rcon.eval("library(SNPath)");
                    double[] pvalues = new double[2];

                    //System.out.println("Simulation " + n + "!");
                    for (int i = 0; i < genePowerList.length; i++) {
                        Arrays.fill(genePowerList[i], 0.0);
                    }
                    int s = 0;
                    int selectedIndex;

                    System.out.println();
                    while (s <= simulationTime) {
                        trats.clear();
                        trats1.clear();

                        int selectedNum = 0;
                        qtlSnpList.clear();
                        varID1.shuffle();
                        varID2.shuffle();
                        while (selectedNum < maxQTLNum1) {
                            selectedIndex = varID1.getQuick(selectedNum);

                            AnnotSNP selVar = snpList.get(selectedIndex);
                            qtlSnpList.add(selVar);
                            selectedNum++;
                        }

                        selectedNum = 0;
                        while (selectedNum < maxQTLNum2) {
                            selectedIndex = varID2.getQuick(selectedNum);
                            // selectedIndex = gene1SNPNum + 3 + selectedNum;

                            AnnotSNP selVar = snpList.get(selectedIndex);
                            qtlSnpList.add(selVar);
                            selectedNum++;
                        }

                        int qtlNum = qtlSnpList.size();
                        for (int i = 0; i < indivSize; i++) {
                            Individual mIndivi = indList.get(i);
                            gtyScore = 0;

                            StatusGtySet gtySet = mIndivi.markerGtySet;
                            qtlNum = qtlSnpList.size();
                            for (int snpPos = 0; snpPos < qtlNum; snpPos++) {
                                int pos = qtlSnpList.get(snpPos).order;
                                if (gtySet.existence.getQuick(pos)) {
                                    if (gtySet.paternalChrom.getQuick(pos)) {
                                        gtyScore += 1;
                                    }
                                    if (gtySet.maternalChrom.getQuick(pos)) {
                                        gtyScore += 1;
                                    }
                                }
                            }
                            // mIndivi.setMainTrait(mIndivi.getMainTrait() + gtyScore);
                            indList.get(i).getMainTrait()[0] = gtyScore;
                        }

                        double acculated2PQ = 0;

                        for (int i = 0; i < qtlNum; i++) {
                            acculated2PQ += (2 * qtlSnpList.get(i).getAAlleleFreq() * (1 - qtlSnpList.get(i).getAAlleleFreq()));
                        }

                        trats.clear();
                        trats1.clear();
                        double vg = varPercentage;
                        double alaph = Math.sqrt(vg / acculated2PQ);
                        double ve = Math.sqrt(1 - vg);
                        double ve1;

                        double[] phenos = new double[indivSize];
                        for (int i = 0; i < indivSize; i++) {
                            Individual mIndivi = indList.get(i);
                            ve1 = randGenerator.nextGaussian(0, ve);
                            mIndivi.getMainTrait()[1] = mIndivi.getMainTrait()[0] * alaph + ve1;
                            trats.add(mIndivi.getMainTrait()[1]);
                            trats1.add(ve1);
                            phenos[i] = mIndivi.getMainTrait()[1];
                        }

                        if (needR) {
                            rcon.assign("phenos", phenos);
                        }

                        double meanT = Descriptive.mean(trats);
                        double varT = Descriptive.sampleVariance(trats, meanT);

                        if (Math.abs(varT - 1) > 0.01) {
                            continue;
                        }
                        // System.out.println(meanT + " " + varT);
                        s++;
                        meanT = Descriptive.mean(trats1);
                        varT = Descriptive.sampleVariance(trats1, meanT);
                        // System.out.println(meanT + " " + varT);

                        List<Individual> selectedIndivs = popu.getAllIndiv();

                        //double[] pValues = analyer.allelicAssociationLogisticTestSimple(phenotypeIndivs, snpList);
                        double[] pValues = analyer.allelicAssociationTestQuantitativeTrait(popu.getAllIndiv(), 1, indexOrders);
                        double[] z = analyer.allelicAssociationZTestQuantitativeTrait(popu.getAllIndiv(), 1, indexOrders);

                        double[] copiedPValues = new double[pValues.length];

                        System.arraycopy(pValues, 0, copiedPValues, 0, pValues.length);

                        int startIndex = 0;
                        int breakIndex = gene1SNPNum;

                        double pVCut = 0.05;
                        //pVCut = 0;
                        boolean useOld = true;
                        double[] re1 = new double[2];
                        if (useOld) {
                            p1 = pValuesAnalyzer.combinePValuebyCorrectedChiFisherCombinationTestMXLiEJMLSubset(rcon, copiedPValues, startIndex, breakIndex,
                                    ldCorr.copy(), indivSize, re1);
                        } else {
                            p1 = pValuesAnalyzer.combinePValuebyCorrectedChiFisherCombinationTestMXLiEJMLSubsetSplit(rcon, copiedPValues, startIndex, breakIndex,
                                    ldCorr.copy(), pVCut, indivSize, re1);
                        }
                        if (p1 <= overallThreshold[0]) {
                            genePowerList[0][0] += 1;
                        }
                        if (p1 <= overallThreshold[1]) {
                            genePowerList[1][0] += 1;
                        }
                        if (p1 <= overallThreshold[2]) {
                            genePowerList[2][0] += 1;
                        }
                        //gpvList1.add(p1);

                        ch1 = MultipleTestingMethod.zScore(p1 / 2);
                        ch1 = ch1 * ch1;

                        double[] re2 = new double[2];
                        if (useOld) {
                            p2 = pValuesAnalyzer.combinePValuebyCorrectedChiFisherCombinationTestMXLiEJMLSubset(rcon, copiedPValues, breakIndex,
                                    testSNPNum, ldCorr.copy(), indivSize, re2);
                        } else {
                            p2 = pValuesAnalyzer.combinePValuebyCorrectedChiFisherCombinationTestMXLiEJMLSubsetSplit(rcon, copiedPValues,
                                    breakIndex, testSNPNum, ldCorr.copy(), pVCut, indivSize, re2);
                        }
                        gpvList2.add(p2);
                        ch2 = MultipleTestingMethod.zScore(p2 / 2);
                        ch2 = ch2 * ch2;

                        /*
                     if (p1 <= overallThreshold[0]) {
                     genePowerList[0][1] += 1;
                     }
                     if (p1 <= overallThreshold[1]) {
                     genePowerList[1][1] += 1;
                     }     
                         */
                        // gpvList1.add(p2);
                        double[] re3 = new double[2];
                        //p3 = pValuesAnalyzer.combinePValuebyCorrectedChiFisherCombinationTestMXLiEJMLSubset(pValues, startIndex, testSNPNum, ldCorr.copy(), re3);
                        if (useOld) {
                            p3 = pValuesAnalyzer.combinePValuebyCorrectedChiFisherCombinationTestMXLiEJMLSubset(rcon, copiedPValues, startIndex,
                                    testSNPNum, ldCorr.copy(), indivSize, re3);
                        } else {
                            p3 = pValuesAnalyzer.combinePValuebyCorrectedChiFisherCombinationTestMXLiEJMLSubsetSplit(rcon, copiedPValues, startIndex,
                                    testSNPNum, ldCorr.copy(), pVCut, indivSize, re3);

                            p = pValuesAnalyzer.combinePValuebyQuadraticFormJohnny(z, ldCorr.copy(), rcon);
                            gpvList3.add(p);
                        }
                        ch3 = MultipleTestingMethod.zScore(p3 / 2);
                        ch3 = ch3 * ch3;

                        //chiSquareComplemented( v, x ) = incompleteGammaComplement( v/2.0, x/2.0 )
                        double df = (re3[0] - re1[0]) / 2;
                        // double ds = (re1[1] + re2[1] - re3[1]) / 2; 
                        double cf = (re3[1] - re1[1]) / 2;

                        //gpvList1.add(p1);
                        p1 = Gamma.incompleteGammaComplement(df, cf);

                        gpvList1.add(p1);
                        ch4 = MultipleTestingMethod.zScore(p1 / 2);
                        ch4 = ch4 * ch4;

                        chisBw.write(k + "\t" + ch1 + "\t" + ch2 + "\t" + ch3 + "\t" + ch4 + "\n");

                        if (s % 9 == 0) {
                            // System.out.println(w);
                        }

                        if (needR) {
                            StringBuilder modelStr = new StringBuilder();
//                            modelStr.append("fm1 <- lm(phenos ~ 1);");
//                            modelStr.append("fm2 <- lm(phenos ~ gtys[,1]");
//                            for (int t = 1; t < breakIndex; t++) {
//                                modelStr.append(" + gtys[,");
//                                modelStr.append(t + 1);
//                                modelStr.append("]");
//                            }
//                            modelStr.append("); a<-lrtest(fm2, fm1);");
//                            rcon.voidEval(modelStr.toString());
//                            p = rcon.eval("a$Pr[2]").asDouble();
//
//                            if (p <= overallThreshold[0]) {
//                                genePowerList[0][2] += 1;
//                            }
//                            if (p <= overallThreshold[1]) {
//                                genePowerList[1][2] += 1;
//                            }
//                            if (p <= overallThreshold[2]) {
//                                genePowerList[2][2] += 1;
//                            }
                            
                            // gpvList3.add(p);

                            modelStr.delete(0, modelStr.length());
                            modelStr.append("fm1 <- lm(phenos ~ gtys[,").append(1);
                            modelStr.append("]");

                            for (int t = 1; t < breakIndex; t++) {
                                modelStr.append(" + gtys[,");
                                modelStr.append(t + 1);
                                modelStr.append("]");
                            }
                            modelStr.append("); ");

                            modelStr.append("fm2 <- lm(phenos ~ gtys[,").append(1);
                            modelStr.append("]");

                            for (int t = 1; t < testSNPNum; t++) {
                                modelStr.append(" + gtys[,");
                                modelStr.append(t + 1);
                                modelStr.append("]");
                            }

                            modelStr.append("); a<-lrtest(fm2, fm1);");
                            rcon.voidEval(modelStr.toString());
                            p = rcon.eval("a$Pr[2]").asDouble();

                            if (p <= overallThreshold[0]) {
                                genePowerList[0][3] += 1;
                            }
                            if (p <= overallThreshold[1]) {
                                genePowerList[1][3] += 1;
                            }
                            if (p <= overallThreshold[2]) {
                                genePowerList[2][3] += 1;
                            }
                            gpvList3.add(p);
                        }
                    }

                    int ii = 0;
                    for (int j = 0; j < genePowerList.length; j++) {
                        genePowerList[j][ii] /= simulationTime;
                        genePBw.write(String.valueOf(genePowerList[j][ii]));
                        genePBw.write("\t");
                        //System.out.println("\chrI" + genePowerList[chrI]);                        
                    }
                    ii = 2;
                    for (int j = 0; j < genePowerList.length; j++) {
                        genePowerList[j][ii] /= simulationTime;
                        genePBw.write(String.valueOf(genePowerList[j][ii]));
                        genePBw.write("\t");
                        //System.out.println("\chrI" + genePowerList[chrI]);                        
                    }
                    ii = 1;
                    for (int j = 0; j < genePowerList.length; j++) {
                        genePowerList[j][ii] /= simulationTime;
                        genePBw.write(String.valueOf(genePowerList[j][ii]));
                        genePBw.write("\t");
                        //System.out.println("\chrI" + genePowerList[chrI]);                        
                    }
                    ii = 3;
                    for (int j = 0; j < genePowerList.length; j++) {
                        genePowerList[j][ii] /= simulationTime;
                        genePBw.write(String.valueOf(genePowerList[j][ii]));
                        genePBw.write("\t");
                        //System.out.println("\chrI" + genePowerList[chrI]);                        
                    }
                    genePBw.newLine();
                    genePBw.flush();

                    //genePBw.flush();
                }

                /*
                for (int w = 0; w < gpvList1.size(); w++) {
                    genePBw.write(gpvList1.getQuick(w) + "\t" + gpvList2.getQuick(w) + "\t" + gpvList3.getQuick(w) + "\t" + gpvList4.getQuick(w) + "\n");
                }
                 */
                genePBw.close();

                PValuePainter pvP = new PValuePainter(350, 350);

                List<DoubleArrayList> pvalueList = new ArrayList<DoubleArrayList>();
                List<String> names = new ArrayList<String>();
                gpvList1.quickSort();
                pvalueList.add(gpvList1);
                names.add("Conditional Eff.Chi.");

                gpvList2.quickSort();
                pvalueList.add(gpvList2);
                names.add("Unconditional Eff.Chi.");
                gpvList3.quickSort();
                pvalueList.add(gpvList3);
                names.add("Likelihood-ratio test");

                pvP.drawMultipleQQPlot(pvalueList, names, null, option.outputFolder + k + ".qqplot.png", 1E-20);

            }

            chisBw.close();

            //  break;
        } catch (Exception ex) {
            String infor = "Please open your R and type the following commands to allow kggseq to use it:\npack=\"Rserve\";\n"
                    + "if (!require(pack,character.only = TRUE))   { install.packages(pack,dep=TRUE,repos=\'http://cran.us.r-project.org\');   if(!require(pack,character.only = TRUE)) stop(\"Package not found\")   }\n"
                    + "library(\"Rserve\");\nRserve(debug = FALSE, port = 6311, args = NULL)\n"
                    + "\nOR type this command without openning your R: \nR CMD Rserve";
            // System.out.println(infor);
            ex.printStackTrace();
        }
    }

}
