/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package genetsimulatoredese;

import org.apache.log4j.Logger;

/**
 *
 * @author Miaoxin Li
 */
public class GlobalVariables {

    public static Logger logger = Logger.getLogger("logger");

    public static void addInforLog(String msg) {
        logger.info(msg);
    }
}
